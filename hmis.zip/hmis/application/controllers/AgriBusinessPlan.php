<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * 
 */
class AgriBusinessPlan extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();
		$this->load->model('AgriBusiness_model');
		$this->load->model('Dropdownvalue_model');
		date_default_timezone_set("Asia/Kathmandu");
		if (! $this->session->userdata('loginId')) {
			redirect('Login');
		}
	}

	function index(){
		$tr = "";
		$list = $this->AgriBusiness_model->getAgriBusinessMaster();
		foreach ($list as $s) {
			$tr .='<tr>
				<td width="90">
				<a href="'.base_url("AgriBusinessPlan/getSchemeData/".$s->Id).'"><span class="btn btn-primary btn-sm"> Update Info</span>
				</a>
				</td>
				<td width="70">'. $s->District .'</td>
				<td width="120">'. $s->RM .'</td>
				<td width="30">'. $s->WardNo .'</td>
				<td width="30">'. $s->FY .'</td>
				<td width="200">'. $s->AgriBusinessName .'</td>
				<td width="80">'. $s->BusinessType .'</td>
				<td width="150">'. $s->SupportOrg .'</td>
				<td width="100">'. $s->AffiliationWithCoops .'</td>
				<td width="80">'. $s->CoveragePop .'</td>
				<td width="100">'. $s->CurrentStatus .'</td>
				<td width="120">'. $s->MoUDate .'</td>
				<td width="120">'. $s->CompletedDate .'</td>';
				$tr.='<td width="100">
					<a onclick="getById('.$s->Id.')" href="#" class="btn btn-success btn-sm" title="Edit"> <span class="fa fa-pencil"></span></a>
					<a href="javascript:void(0)" onclick="deleteScheme('.$s->Id.', this)" class="btn btn-danger btn-sm"><span class="fa fa-trash"></span></a>
					</td>';
				$tr.="</tr>";
				}
		$data['schemeList'] = $tr;
		$data['districtList'] = $this->getDistricts();
		$title['page_title'] = 'HMIS: Agri-Business Information';
		$this->load->view('includes/header', $title);
		$this->load->view('agribusiness/index', $data);
		$this->load->view('includes/footer');
	}

	function collectionCenter(){
		$tr = "";
		$list = $this->AgriBusiness_model->getCollectionCenterMaster();
		foreach ($list as $s) {
			$tr .='<tr>
				<td width="90">
				<a href="'.base_url("AgriBusinessPlan/getSchemeData/".$s->Id).'"><span class="btn btn-primary btn-sm"> Update Info</span>
				</a>
				</td>
				<td width="70">'. $s->District .'</td>
				<td width="120">'. $s->RM .'</td>
				<td width="30">'. $s->WardNo .'</td>
				<td width="30">'. $s->FY .'</td>
				<td width="200">'. $s->AgriBusinessName .'</td>
				<td width="100">'. $s->CurrentStatus .'</td>
				<td width="80">'. $s->CollectionCenterCapacity .'</td>
				<td width="120">'. $s->MajorCrops .'</td>
				<td width="80">'. $s->CatchmentArea .'</td>
				<td width="100">'. $s->OperationGuideline .'</td>
				<td width="100">'. $s->OperationDirective .'</td>
				<td width="80">'. $s->Owner .'</td>
				<td width="80">'. $s->OwnerNature .'</td>
				<td width="150">'. $s->SupportOrg .'</td>
				<td width="100">'. $s->AffiliationWithCoops .'</td>
				<td width="80">'. $s->CoveragePop .'</td>
				<td width="120">'. $s->MoUDate .'</td>
				<td width="120">'. $s->CompletedDate .'</td>';
				$tr.='<td width="100">
					<a onclick="getById('.$s->Id.')" href="#" class="btn btn-success btn-sm" title="Edit"> <span class="fa fa-pencil"></span></a>
					<a href="javascript:void(0)" onclick="deleteScheme('.$s->Id.', this)" class="btn btn-danger btn-sm"><span class="fa fa-trash"></span></a>
					</td>';
				$tr.="</tr>";
				}
		$data['schemeList'] = $tr;
		$data['districtList'] = $this->getDistricts();
		$title['page_title'] = 'HMIS: Agri-Business Information';
		$this->load->view('includes/header', $title);
		$this->load->view('agribusiness/collectionCenter', $data);
		$this->load->view('includes/footer');
	}

	function saveData(){
		$id = $this->input->post('id');
		if ($id>0) {
			$data[]=array(
				'Id'=>$this->input->post('id'),
				'agb_cc'=>$this->input->post('type'),
				'District'=>$this->input->post('district'),
				'RM'=>$this->input->post('rmc'),
				'WardNo'=>$this->input->post('ward'),
				'FY'=>$this->input->post('FY'),
				'AgriBusinessName'=>$this->input->post('AgriBusinessName'),
				'SubSector'=>$this->input->post('SubSector'),
				'BusinessType'=>$this->input->post('BusinessType'),
				'Owner'=>$this->input->post('BusinessOwner'),
				'OwnerNature'=>$this->input->post('BusinessOwnerNature'),
				'BusinessPlanPreparation'=>$this->input->post('BusinessPlanPreparation'),
				'SupportOrg'=>$this->input->post('Support_Org'),
				'LinkToValueChain'=>$this->input->post('LinkToValueChain'),
				'AffiliationWithCoops'=>$this->input->post('AffiliationWithCoops'),
				'AffiliatedCoopName'=>$this->input->post('AffiliatedCoopName'),
				'CoveragePop'=>$this->input->post('CoveragePop'),
				'CurrentStatus'=>$this->input->post('CurrentStatus'),
				'MajorCrops'=>$this->input->post('MajorCrops'),
				'CatchmentArea'=>$this->input->post('CatchmentArea'),
				'CollectionCenterCapacity'=>$this->input->post('CollectionCenterCapacity'),
				'OperationGuideline'=>$this->input->post('OperationGuideline'),
				'OperationDirective'=>$this->input->post('OperationDirective'),
				'Other_info'=>$this->input->post('otherInfo'),
				'MoUDate'=>$this->input->post('MoUDate'),
				'Updated_By'=>$this->session->userdata('loginName'),
				'Updated_Date'=>date("d-m-Y h:m:sa")
			);
		}else{
			$data[]=array(
				'Id'=>$this->input->post('id'),
				'agb_cc'=>$this->input->post('type'),
				'District'=>$this->input->post('district'),
				'RM'=>$this->input->post('rmc'),
				'WardNo'=>$this->input->post('ward'),
				'FY'=>$this->input->post('FY'),
				'AgriBusinessName'=>$this->input->post('AgriBusinessName'),
				'SubSector'=>$this->input->post('SubSector'),
				'BusinessType'=>$this->input->post('BusinessType'),
				'Owner'=>$this->input->post('BusinessOwner'),
				'OwnerNature'=>$this->input->post('BusinessOwnerNature'),
				'BusinessPlanPreparation'=>$this->input->post('BusinessPlanPreparation'),
				'SupportOrg'=>$this->input->post('Support_Org'),
				'LinkToValueChain'=>$this->input->post('LinkToValueChain'),
				'AffiliationWithCoops'=>$this->input->post('AffiliationWithCoops'),
				'AffiliatedCoopName'=>$this->input->post('AffiliatedCoopName'),
				'CoveragePop'=>$this->input->post('CoveragePop'),
				'CurrentStatus'=>$this->input->post('CurrentStatus'),
				'MajorCrops'=>$this->input->post('MajorCrops'),
				'CatchmentArea'=>$this->input->post('CatchmentArea'),
				'CollectionCenterCapacity'=>$this->input->post('CollectionCenterCapacity'),
				'OperationGuideline'=>$this->input->post('OperationGuideline'),
				'OperationDirective'=>$this->input->post('OperationDirective'),
				'Other_info'=>$this->input->post('otherInfo'),
				'MoUDate'=>$this->input->post('MoUDate'),
				'Added_By'=>$this->session->userdata('loginName'),
				'Added_Date'=>date("d-m-Y h:m:sa")
			);
		}
		
		$saved = $this->AgriBusiness_model->save('agri_business_master', $data, $id);
    	if ($saved>0) {
    		$this->session->set_flashdata('success', 'Saved');
    		if ($this->input->post('type')=='AGB') {
    			redirect('AgriBusinessPlan');
    		}else{
    			redirect('AgriBusinessPlan/collectionCenter');
    		}
    		
    	}else{
    		$this->session->set_flashdata('success', 'Error');
    		if ($this->input->post('type')=='AGB') {
    			redirect('AgriBusinessPlan');
    		}else{
    			redirect('AgriBusinessPlan/collectionCenter');
    		}
    	}
	}


	function getDistricts(){
		$list = $this->Dropdownvalue_model->getDistrict();
		$option="";
		foreach ($list as $d) {
			$option.="<option>".$d->District."</option>";
		}
		return $option;
	}

	function getById(){
		$id = $this->input->post('id');
		$tbl = $this->input->post('tbl');
		$data = $this->AgriBusiness_model->getById($id, $tbl)->result_array();
		echo json_encode($data);
	}

	function delById(){
		$id = $this->input->post('id');
		$tbl = $this->input->post('tbl');
		$res = $this->AgriBusiness_model->delById($id, $tbl);
		if ($res==1) {
			echo 'deleted';
		}else{
			echo $res;
		}
	}

	function getSchemeData(){
		$id = $this->uri->segment('3');
		$title['page_title'] = 'HMIS: Agri-Business Information';
		$this->load->view('includes/header', $title);
		$schemeinfo=$this->AgriBusiness_model->getById($id, 'agri_business_master')->result();
		foreach ($schemeinfo as $s) {
			$data['Id']=$s->Id;
			$data['schemename']=$s->AgriBusinessName;
			$data['currentstatus']=$s->CurrentStatus;
		}
		$this->load->view('agribusiness/agribusiness-update', $data);
		$this->load->view('includes/footer');
	}

	function saveBeneficiary(){
		$id = $this->input->post('id');
		if ($id==0) {
			$data[] = array(
				'AgriBusinessId'=> $this->input->post('schemeid'),
				'HH_Head_Name'=> $this->input->post('hhName'),
				'Tole_Cluster'=> $this->input->post('cluster'),
				'Caste_Ethnicity'=> $this->input->post('ethnicity'),
				'Ben_Female'=> $this->input->post('female'),
				'Ben_Male'=> $this->input->post('male'),
				'Ben_Total'=> $this->input->post('total'),
				'Added_By'=> $this->session->userdata('loginName'),
				'Added_Date'=> date('d-m-Y h:m:sa')
			);
		}else{
			$data[] = array(
				'Id' => $this->input->post('id'),
				'AgriBusinessId'=> $this->input->post('schemeid'),
				'HH_Head_Name'=> $this->input->post('hhName'),
				'Tole_Cluster'=> $this->input->post('cluster'),
				'Caste_Ethnicity'=> $this->input->post('ethnicity'),
				'Ben_Female'=> $this->input->post('female'),
				'Ben_Male'=> $this->input->post('male'),
				'Ben_Total'=> $this->input->post('total'),
				'Updated_By'=> $this->session->userdata('loginName'),
				'Updated_Date'=> date('d-m-Y h:m:sA')
			);
		}

		$save = $this->AgriBusiness_model->save('business_beneficiary', $data, $id);
		if ($save>0) {
			echo "Saved Successfully";
		}else{
			echo $save;
		}
	}

	function getAllBen(){
		$agriId = $this->input->post('Id');
		$benList = $this->AgriBusiness_model->getBusinessData($agriId, 'business_beneficiary')->result();
		$tr = '';
		foreach ($benList as $b) {
			$tr.='<tr><td width="100" style="text-align:center;"><a title="Edit" onclick="getBenById('.$b->Id.", 'business_beneficiary'".')" href="#" class="btn btn-info btn-sm"> <i class="fa fa-pencil" aria-hidden="true"></i></a>
				<a title="Annual Turnover" onclick="updateTurnOver('.$b->Id.",".$b->AgriBusinessId.')" href="#" class="btn btn-primary btn-sm"> <i class="fa fa-inr" aria-hidden="true"></i></a>
				<a title="Delete" onclick="delBen('."'business_beneficiary'".','.$b->Id.',this)" href="#" class="btn btn-danger btn-sm"> <i class="fa fa-trash-o" aria-hidden="true"></i></a>
				</td>';
			$tr.='<td width="150">'.$b->HH_Head_Name.'</td>';
			$tr.='<td width="120">'.$b->Tole_Cluster.'</td>';
			$tr.='<td width="100">'.$b->Caste_Ethnicity.'</td>';
			$tr.='<td width="90" style="text-align:center;">'.$b->Ben_Female.'</td>';
			$tr.='<td width="90" style="text-align:center;">'.$b->Ben_Male.'</td>';
			$tr.='<td width="70" style="text-align:center;">'.$b->Ben_Total.'</td>';
			$tr.='</tr>';
		}

		echo $tr;
	}

	function getContributions(){
		$agriId = $this->input->post('Id');
		$tr = '<thead>
	            <tr>                                
	                <th width="200">Cost Contributor</th>
	                <th width="170">Contribution Estimated</th>
	                <th width="170">Contribution Actual</th>
	                <th width="100">Actions</th>
	            </tr>
          	</thead>
            <tbody>';
		$contributions = $this->AgriBusiness_model->getBusinessData($agriId, 'business_cost_contribution');
		
		if ($contributions->num_rows()>0) {
			$totalEst=0;
			$totalAct=0;
			foreach ($contributions->result() as $c) {
				$tr.='<tr><td width="200">'.$c->Contributor.'</td>';
				$tr.='<td width="170" style="text-align:right;">'.number_format($c->Contribution_Estimated,3).'</td>';
				$tr.='<td width="170" style="text-align:right;">'.number_format($c->Contribution_Actual,3).'</td>';
				$tr.='<td width="100" style="text-align:center;"><a title="Edit" onclick="getContributionById('.$c->Id.", 'business_cost_contribution'".')" href="#" class="btn btn-primary btn-sm"> <span class="fa fa-pencil"></span> 
					</a></td></tr>';
					$totalEst=$totalEst+$c->Contribution_Estimated;
					$totalAct=$totalAct+$c->Contribution_Actual;
			}
			$tr.='<tr><th width="200">Total</th>';
			$tr.='<th width="170" style="text-align:right;">'.number_format($totalEst,3).'</th>';
			$tr.='<th width="170" style="text-align:right;">'.number_format($totalAct,3).'</th>';
			$tr.='<th width="100" style="text-align:center;"></th></tr>';
			$tr.='</tbody>';

			
		}else{
			$tr = '<thead>
	            <tr>                                
	                <th width="200">Cost Contributor</th>
	                <th width="170">Contribution Estimated</th>
	                <th width="170">Contribution Actual</th>
	            </tr>
          	</thead>
            <tbody>';
			$contributions = $this->AgriBusiness_model->getFormElements('contributors');
			foreach ($contributions as $c) {				
				$tr.='<tr>';
				$tr.='<td width="200"> <input type="text" readonly class="form-control" name="Contributors[]" value="'.$c->Contributors.'" Id="'.$c->txtId.'0"></td>';
				$tr.='<td  width="170"><input type="number" value="0" step="0.01" class="form-control" min="0" name="Contribution_Estimated[]" id="1'.$c->txtId.'"></td>';
				$tr.='<td  width="170"><input type="number" value="0" step="0.01" class="form-control" min="0" name="Contribution_Actual" id="2'.$c->txtId.'"></td> </tr>';
			}
			$tr.="<tr><td colspan='3' style='text-align:center;'><button onclick='saveContribution()' class='btn btn-primary'> Save</button></td></tr>";
		}
		echo $tr;
	}

	function addCostContribution(){
		$id = 0;
		$contributors = $this->input->post('contributors');
		$Estimated = $this->input->post('estimated');
		$Actual = $this->input->post('actual');
		$code = $this->input->post('scode');
		foreach ($contributors as $key => $value) {
			$data[]=array(
				'AgriBusinessId' => $code,
				'Contributor' =>$value,
				'Contribution_Estimated' =>$Estimated[$key],
				'Contribution_Actual' =>$Actual[$key],
				'Updated_By' =>$this->session->userdata('loginName'),
				'Updated_Date'=>date('d-m-Y h:m:sa')
			);
		}
		$saved = $this->AgriBusiness_model->save('business_cost_contribution', $data, $id);
		if ($saved==TRUE) {
			echo "Saved Successfully";
		}else{
			echo $saved;
		}
	}

	function updateCostContribution(){
		$id = $this->input->post('id');
		$data[] =array(
			'Id'=>$this->input->post('id'),
			'AgriBusinessId' => $this->input->post('code'),
			'Contributor' => $this->input->post('contributor'),
			'Contribution_Estimated' => $this->input->post('estimated'),
			'Contribution_Actual' => $this->input->post('actual'),
			'Updated_By' =>$this->session->userdata('loginName'),
			'Updated_Date'=>date('d-m-Y h:m:sa')
		);
		$success = $this->AgriBusiness_model->save('business_cost_contribution', $data, $id);
		if($success==TRUE){
			echo "Saved Successfully";
		}else if($success==0){
			echo "No Change";
		}else{
			echo "Data update error";
		}
	}

	function getContributionById(){
		$id = $this->input->post('Id');
		$tbl = $this->input->post('table');
		
		$contribution = $this->AgriBusiness_model->getById($id, $tbl)->result_array();
		echo json_encode($contribution);
	}

	function ItemCost(){
		$agriId = $this->input->post('scheme');

		$scheme = $this->getItemCosts($agriId);

		if ($scheme=='No Data') {

			$formELe = $this->getFormElements();
			echo $formELe;
		}else{
			echo $scheme;
		}
	}

	function getFormElements(){
		$td = '<thead><tr>
            <th width="170">Item Description</th>
            <th width="110">Estimated Cost</th>
            <th width="110">Actual Cost</th>
        </tr></thead><tbody style="min-height: 733px;">';
        $costHeadings = $this->AgriBusiness_model->getFormElements('cost_headings');
        foreach ($costHeadings as $h) {
        	$td.='<tr><td width="170"><input type="text" readonly class="form-control" name="Descriptions[]" value="'.$h->Headings.'"></td>';
        	$td.='<td width="110"><input required type="number" step="0.01" min="0" value="0.00" class="form-control" name="Estimated_Costs[]"></td>';
        	$td.='<td width="110"><input required type="number" step="0.01" min="0" value="0.00" class="form-control" name="Actual_Costs[]" ></td>';
        	$td.='</tr>';
        }
        $td.='<td colspan="4" style="text-align:center;"><button class="btn btn-sm btn-primary" onclick="saveItemCost()">Save </button></td></tr>';
        $td.='</tbody>';

        return $td;

	}

	function getItemCosts($id){
		//echo $scheme;
		$itemcosts = $this->AgriBusiness_model->getBusinessData($id, 'business_item_cost');
		
		$row = '<thead><tr>
            <th width="150">Item Description</th>
            <th width="110">Estimated Cost</th>
            <th width="110">Actual Cost</th>
            <th width="80">Action</th></tr></thead><tbody style="min-height: 785px;">';
            $totalEstimate=0;
            $totalActual=0;
		if ($itemcosts->num_rows()>0) {
			foreach ($itemcosts->result() as $ic){
				$row .='<tr><td width="150">'.$ic->Description.'</td>';
				$row .='<td width="110" style="text-align:right;">'.number_format($ic->Estimated_Cost,3).'</td>';
				$row .='<td width="110" style="text-align:right;">'.number_format($ic->Actual_Cost,3).'</td>';
				$row .='<td width="80" style="text-align:center;"><a title="Edit" onclick="getCostById('.$ic->Id.", 'business_item_cost'".')" href="javascript:void(0)" class="btn btn-primary btn-sm"> <span class="fa fa-pencil"></span> 
					</a></td></tr>';
				$totalEstimate=$totalEstimate+$ic->Estimated_Cost;
				$totalActual=$totalActual+$ic->Actual_Cost;
			}
			$row .= '<tr>
            <th width="150">Total</th>
            <th width="110" style="text-align:right;">'.number_format($totalEstimate,3).'</th>
            <th width="110" style="text-align:right;">'.number_format($totalActual,3).'</th>
            <th width="80"></th></tr>';

			$row.='</tbody';
			return $row;

		}else{
			return 'No Data';
		}
		
	}

	function addItemCost(){
		$id=0;
		$scheme = $this->input->post('scode');
		$items = $this->input->post('items');
		$estimates = $this->input->post('estimates');
		$actuals = $this->input->post('actuals');
		foreach ($items as $key => $value) {
			$data[]=array(
				'AgriBusinessId'=>$scheme,
				'Description'=>$value,
				'Estimated_Cost'=>$estimates[$key],
				'Actual_Cost'=>$actuals[$key],
				'Updated_By'=>$this->session->userdata('loginName'),
				'Updated_Date'=>date('Y-m-d h:m:sa')
			);
		}

		$saved = $this->AgriBusiness_model->save('business_item_cost', $data, $id);
		if ($saved==TRUE) {
			echo "Saved Successfully";
		}else{
			echo $saved;
		}

	}

	function getItemCostById(){
		$id = $this->input->post('Id');
		$tbl = $this->input->post('table');
		
		$ben = $this->AgriBusiness_model->getById($id, $tbl)->result_array();
		echo json_encode($ben);
	}

	function updateItemCost(){
		$id = $this->input->post('id');
		$data[] =array(
			'Id'=>$this->input->post('id'),
			'AgriBusinessId' => $this->input->post('code'),
			'Description' => $this->input->post('description'),
			'Estimated_Cost' => $this->input->post('Estimated'),
			'Actual_Cost' => $this->input->post('Actual'),
			'Updated_By' =>$this->session->userdata('loginName'),
			'Updated_Date'=>date('d-m-Y h:m:sa')
		);
		$success = $this->AgriBusiness_model->save('business_item_cost', $data, $id);
		if($success==TRUE){
			echo "Saved Successfully";
		}else if($success==0){
			echo "No Change";
		}else{
			echo "Data update error";
		}
	}

	function updateSchemeStatus(){
		$id = $this->input->post('id');
		$data[] = array(
			'Id'=>$this->input->post('id'),
			'CurrentStatus' => $this->input->post('status'),
			'CompletedDate' => $this->input->post('cdate'),
			'Updated_By' => $this->session->userdata('loginName'),
			'Updated_Date' => date("d-m-Y h:m:sa")
		);
		
		$success = $this->AgriBusiness_model->save('agri_business_master', $data, $id);
		
		if($success==TRUE){
			echo "Saved Successfully";
		}else if($success==0){
			echo "No Change";
		}else{
			echo $success;
		}
	}

	function getTurnOver(){
		$benId = $this->input->post('benId');
		$businessId = $this->input->post('businessId');
		$turnOver = $this->AgriBusiness_model->getAnnualTurnOver($benId, $businessId);
		if ($turnOver->num_rows()>0) {
			$tr="";
			foreach ($turnOver->result() as $t) {
				$tr .="<tr><td style='text-align:center;'>".$t->FY."</td><td style='text-align:center;'>".$t->Turnover."</td>";
				$tr .='<td width="120"><a title="Delete" onclick="delTurnOver('."'business_turnover'".','.$t->Id.',this)" href="#" class="btn btn-danger btn-sm"> <i class="fa fa-trash-o" aria-hidden="true"></i></a></td></tr>';
			}
			echo $tr;
		}else{
			echo "<tr><td colspan='3' style='text-align:center;'> No turnover data found</td></tr>";
		}
	}

	function savTurnover(){
		$bName = $this->AgriBusiness_model->getById($this->input->post('businessId'), 'agri_business_master')->row();
		$benName = $this->AgriBusiness_model->getById($this->input->post('benId'), 'business_beneficiary')->row();
		$data[]=array(
			'BusinessId'=>$this->input->post('businessId'),
			'BusinessName'=>$bName->AgriBusinessName,
			'BenId'=>$this->input->post('benId'),
			'BeneficiaryName'=>$benName->HH_Head_Name,
			'FY'=>$this->input->post('fy'),
			'Turnover'=>$this->input->post('turnover')
		);
		$id = 0;
		$res = $this->AgriBusiness_model->save('business_turnover', $data, $id);
		if ($res==TRUE) {
			echo "Saved Successfully";
		}else{
			echo $res;
		}
	}

	function saveManagement(){
		$id = $this->input->post('id');
		$agriId = $this->input->post('abId');
		$bName = $this->AgriBusiness_model->getById($agriId, 'agri_business_master')->row();
		if ($id>0) {
			$data[]=array(
				'Id'=>$id,
				'Position'=>$this->input->post('position'),
				'Ethnicity'=>$this->input->post('ethnicity'),
				'Gender'=>$this->input->post('gender'),
				'NumberofMember'=>$this->input->post('mNumber'),
				'RepresentativeOf'=>$this->input->post('rep')
			);
		}else{
			$data[]=array(
				'AgriBusinessId'=>$agriId,
				'BusinessName'=>$bName->AgriBusinessName,
				'Position'=>$this->input->post('position'),
				'Ethnicity'=>$this->input->post('ethnicity'),
				'Gender'=>$this->input->post('gender'),
				'NumberofMember'=>$this->input->post('mNumber'),
				'RepresentativeOf'=>$this->input->post('rep')
			);
		}
		
		$res = $this->AgriBusiness_model->save('business_management_committee', $data, $id);
		if ($res==TRUE) {
			echo "Saved Successfully";
		}else{
			echo $res;
		}
	}

	function getManagementDetail(){
		$bId = $this->input->post('Id');
		$mgmtList = $this->AgriBusiness_model->getBusinessData($bId, 'business_management_committee')->result();
		$tr = '';
		foreach ($mgmtList as $b) {
			$tr.='<tr><td width="100" style="text-align:center;"><a title="Edit" onclick="getMgmtById('.$b->Id.", 'business_management_committee'".')" href="#" class="btn btn-info btn-sm"> <i class="fa fa-pencil" aria-hidden="true"></i></a>
				<a title="Delete" onclick="delMgmt('."'business_management_committee'".','.$b->Id.',this)" href="#" class="btn btn-danger btn-sm"> <i class="fa fa-trash-o" aria-hidden="true"></i></a>
				</td>';
			$tr.='<td width="150">'.$b->Position.'</td>';
			$tr.='<td width="120">'.$b->Ethnicity.'</td>';
			$tr.='<td width="100">'.$b->Gender.'</td>';
			$tr.='<td width="90" style="text-align:center;">'.$b->NumberOfMember.'</td>';
			$tr.='<td width="90" style="text-align:center;">'.$b->RepresentativeOf.'</td>';
			$tr.='</tr>';
		}

		echo $tr;
	}
}