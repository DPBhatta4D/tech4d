<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class BackupDB extends CI_Controller
{
	Function backup(){
		$fileName = 'hmis_backup_'.date("d-m-Y").'.sql';
		$this->load->dbutil();
		$prefs = array(
			'format' => 'sql',
			'filename' => 'hmis_db.sql'
		);
		$backup = $this->dbutil->backup($prefs);
		$this->load->helper('file');
	    write_file(FCPATH.'/backups/'.$fileName, $backup);
	    $this->load->helper('download');
	    force_download($fileName, $backup);
	}
}