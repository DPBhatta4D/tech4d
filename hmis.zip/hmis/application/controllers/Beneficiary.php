<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * 
 */
class Beneficiary extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();
		$this->load->model('Repository_model');
		if (! $this->session->userdata('loginId')) {
			redirect('Login');
		}
	}

	function addBeneficiary(){
		$id = $this->input->post('id');

		$data = array(
			'Scheme_Code'=> $this->input->post('schemeid'),
			'HH_Head_Name'=> $this->input->post('hhName'),
			'Tole_Cluster'=> $this->input->post('cluster'),
			'Caste_Ethnicity'=> $this->input->post('ethnicity'),
			'Ben_Female'=> $this->input->post('female'),
			'Ben_Male'=> $this->input->post('male'),
			'Ben_Total'=> $this->input->post('total'),
			'IrrigatedLand'=> $this->input->post('ropani'),
			'Remarks'=> $this->input->post('remarks'),
			'Added_By'=> $this->session->userdata('loginName'),
			'Added_Date'=> date('d-m-Y h:m:sa'),
		);

		$save = $this->Repository_model->save('beneficiary', $id, $data);
		if ($save>0) {
			echo "Saved Successfully";
		}else{
			echo $save;
		}
	}

	function getAllBen(){
		$tr = '';
		$scheme = $this->input->post('scheme');
		$ben = $this->Repository_model->getSchemeData('beneficiary', $scheme);
		foreach ($ben as $b) {
			$tr.='<tr><td width="100" style="text-align:center;"><a title="Edit" onclick="getBenById('.$b->Id.", 'beneficiary'".')" href="#" class="btn btn-info btn-sm"> <span class="fa fa-pencil"></span> 
				</a><a title="Delete" onclick="delBen('."'beneficiary'".','.$b->Id.',this)" href="#" class="btn btn-danger btn-sm"> <span class="fa fa-trash-o"></span> 
				</a></td>';
			$tr.='<td width="150">'.$b->HH_Head_Name.'</td>';
			$tr.='<td width="120">'.$b->Tole_Cluster.'</td>';
			$tr.='<td width="100">'.$b->Caste_Ethnicity.'</td>';
			$tr.='<td width="90" style="text-align:center;">'.$b->Ben_Female.'</td>';
			$tr.='<td width="90" style="text-align:center;">'.$b->Ben_Male.'</td>';
			$tr.='<td width="70" style="text-align:center;">'.$b->Ben_Total.'</td>';
			$tr.='<td width="70" style="text-align:center;">'.$b->IrrigatedLand.'</td>';
			$tr.='<td width="120">'.$b->Remarks.'</td></tr>';
		}

		echo $tr;
	}

	function getBenById(){
		$id = $this->input->post('Id');
		$tbl = $this->input->post('table');
		
		$ben = $this->Repository_model->getById($id, $tbl);
		echo json_encode($ben);
	}

}