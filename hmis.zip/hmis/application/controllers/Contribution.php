<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * 
 */
class Contribution extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();
		$this->load->model('Repository_model');
		if (! $this->session->userdata('loginId')) {
			redirect('Login');
		}
	}

	function getContributions(){
		$tr = '<thead>
	            <tr>                                
	                <th width="200">Cost Contributor</th>
	                <th width="170">Contribution Estimated</th>
	                <th width="170">Contribution Actual</th>
	                <th width="80">Actions</th>
	            </tr>
          	</thead>
            <tbody>';
		$scheme = $this->input->post('scheme');
		$contributions = $this->Repository_model->getSchemeData('cost_contribution', $scheme);
		if ($contributions) {
			$totalEst=0;
			$totalAct=0;
			foreach ($contributions as $c) {
				$tr.='<tr><td width="200">'.$c->Contributor.'</td>';
				$tr.='<td width="170" style="text-align:right;">'.number_format($c->Contribution_Estimated,3).'</td>';
				$tr.='<td width="170" style="text-align:right;">'.number_format($c->Contribution_Actual,3).'</td>';
				$tr.='<td width="80" style="text-align:center;"><a title="Edit" onclick="getContributionById('.$c->Id.", 'cost_contribution'".')" href="#" class="btn btn-primary btn-sm"> <span class="fa fa-pencil"></span> 
					</a></td></tr>';
					$totalEst=$totalEst+$c->Contribution_Estimated;
					$totalAct=$totalAct+$c->Contribution_Actual;
			}
			$tr.='<tr><th width="200">Total</th>';
			$tr.='<th width="170" style="text-align:right;">'.number_format($totalEst,3).'</th>';
			$tr.='<th width="170" style="text-align:right;">'.number_format($totalAct,3).'</th>';
			$tr.='<th width="80" style="text-align:center;"></th></tr>';
			$tr.='</tbody>';

			
		}else{
			$tr = '<thead>
	            <tr>                                
	                <th width="200">Cost Contributor</th>
	                <th width="170">Contribution Estimated</th>
	                <th width="170">Contribution Actual</th>
	            </tr>
          	</thead>
            <tbody>';
			$contributions = $this->Repository_model->getFormElements('contributors');
			foreach ($contributions as $c) {				
				$tr.='<tr>';
				$tr.='<td width="200"> <input type="text" readonly class="form-control" name="Contributors[]" value="'.$c->Contributors.'" Id="'.$c->txtId.'0"></td>';
				$tr.='<td  width="170"><input type="number" value="0" step="0.01" class="form-control" min="0" name="Contribution_Estimated[]" id="1'.$c->txtId.'"></td>';
				$tr.='<td  width="170"><input type="number" value="0" step="0.01" class="form-control" min="0" name="Contribution_Actual" id="2'.$c->txtId.'"></td> </tr>';
			}
			$tr.="<tr><td colspan='3' style='text-align:center;'><button onclick='saveContribution()' class='btn btn-primary'> Save</button></td></tr>";
		}
		echo $tr;
			
	}

	function getContributionById(){
		$id = $this->input->post('Id');
		$tbl = $this->input->post('table');
		
		$ben = $this->Repository_model->getById($id, $tbl);
		echo json_encode($ben);
	}

	

	function addCostContribution(){
		$contributors = $this->input->post('contributors');
		$Estimated = $this->input->post('estimated');
		$Actual = $this->input->post('actual');
		$code = $this->input->post('scode');
		foreach ($contributors as $key => $value) {
			$data[]=array(
				'Scheme_Code' => $code,
				'Contributor' =>$value,
				'Contribution_Estimated' =>$Estimated[$key],
				'Contribution_Actual' =>$Actual[$key],
				'Updated_By' =>$this->session->userdata('loginName'),
				'Updated_Date'=>date('d-m-Y h:m:sa')
			);
		}
		$saved = $this->Repository_model->addContribution_ItemCost('cost_contribution', $data);
		if ($saved==TRUE) {
			echo "Saved Successfully";
		}else{
			echo $saved;
		}
	}

	function updateCostContribution(){
		$id = $this->input->post('id');
		$data =array(
			'Scheme_Code' => $this->input->post('code'),
			'Contributor' => $this->input->post('contributor'),
			'Contribution_Estimated' => $this->input->post('estimated'),
			'Contribution_Actual' => $this->input->post('actual'),
			'Updated_By' =>$this->session->userdata('loginName'),
			'Updated_Date'=>date('d-m-Y h:m:sa')
		);
		$success = $this->Repository_model->updateSchemeData('cost_contribution', $id, $data);
		if($success==1){
			echo "Saved Successfully";
		}else if($success==0){
			echo "No Change";
		}else{
			echo "Data update error";
		}
	}
}