<?php defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * 
 */
class Cooperative extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();
		if (! $this->session->userdata('loginId')) {
			redirect('Login');
		}
		$this->load->model('Repository_model');
		$this->load->model('Coop_model');
	}

	function getRM(){
	  	$this->load->model('Dropdownvalue_model');
	  	$district = $this->input->post('district');
	  	$r = $this->input->post('rm');
	  	$rms = $this->Dropdownvalue_model->getRM($district);
	  	$output = '<option value="">गाउँ/नगरपालिका छान्नुहोस्</option>';
	  	foreach ($rms as $rm) {
	  		if ($rm->RM==$r) {
	  			$output .='<option value="'.$rm->RM.'" selected>'.$rm->RM.'</option>';
	  		}else{
	  			$output .='<option>'.$rm->RM.'</option>';
	  		}
	  		
	  	}
	  	echo $output;
	}

	function index(){
		$title['page_title'] = 'HMIS: Cooperative Information';
		$this->load->view('includes/header', $title);
		$this->load->view('coop/index');
		$this->load->view('includes/footer');
	}


	function Save(){
		$coopBusiness='';
		$agriBuss = $this->input->post('agriBusiness');
		$techSupport = $this->input->post('techSupport');
		$ecoSupport = $this->input->post('investment');

		if (strlen($agriBuss)>1 && strlen($techSupport)>1 && strlen($ecoSupport)>1)
			$coopBusiness = $agriBuss.', '.$techSupport.', '.$ecoSupport;
		elseif (strlen($agriBuss)>1 && strlen($techSupport)>1 && strlen($ecoSupport)==1) 
			$coopBusiness =$agriBuss.', '.$techSupport;
		elseif (strlen($agriBuss)>1 && strlen($techSupport)==1 && strlen($ecoSupport)>1) 
			$coopBusiness =$agriBuss.', '.$ecoSupport;
		elseif (strlen($agriBuss)==1 && strlen($techSupport)>1 && strlen($ecoSupport)>1)
			$coopBusiness = $techSupport.', '.$ecoSupport;
		elseif (strlen($agriBuss)==1 && strlen($techSupport)==1 && strlen($ecoSupport)>1)
			$coopBusiness = $ecoSupport;
		elseif ((strlen($agriBuss)>1 && strlen($techSupport)==1 && strlen($ecoSupport)==1))
			$coopBusiness = $agriBuss;
		elseif ((strlen($agriBuss)==1 && strlen($techSupport)>1 && strlen($ecoSupport)==1)) 
			$coopBusiness = $techSupport;


		$data = array(
			'Id' => $this->input->post('id'),
			'District' => $this->input->post('district'),
			'RM' => $this->input->post('rmc'),
			'Ward' => $this->input->post('ward'),
			'Cooperative_Name' => $this->input->post('coopName'),
			'share_member_female' => $this->input->post('femaleMember'),
			'share_member_male' => $this->input->post('maleMember'),
			'share_member_institution' => $this->input->post('instMember'),
			'share_member_dalit' => $this->input->post('dalitMember'),
			'share_member_janajati' => $this->input->post('janajatiMember'),
			'share_member_other' => $this->input->post('otherMember'),
			'total_share_amount' => $this->input->post('totalShare'),
			'total_saving' => $this->input->post('totalSaving'),
			'ws_om_relief_fund' => $this->input->post('omFund'),
			'loan_in_ig' => $this->input->post('incomeSector'),
			'no_of_ig_investment' => $this->input->post('investIncomeNumber'),
			'loan_in_livestock' => $this->input->post('livestockSector'),
			'no_of_livestock_loans' => $this->input->post('investLivestockNumber'),
			'loan_in_business' => $this->input->post('businessSector'),
			'no_of_business_loan' => $this->input->post('investBusinessNumber'),
			'loan_in_foreign_employment' => $this->input->post('foreignJobSector'),
			'no_of_employment_loan' => $this->input->post('investForeignNumber'),
			'loan_in_home_loan' => $this->input->post('hhExp'),
			'no_of_home_loan' => $this->input->post('investHHNumber'),
			'interest_income' => $this->input->post('interestIncome'),
			'other_income' => $this->input->post('otherIncome'),
			'total_income' => $this->input->post('totalIncome'),
			'total_expenditure' => $this->input->post('totalExp'),
			'interest_dues' => $this->input->post('interestReceivable'),
			'interest_over_dues' => $this->input->post('amountOverDue'),
			'oss' => $this->input->post('oss'),
			'affiliated_cos' => $this->input->post('affiliatedCOs'),
			'affiliated_hg_ig' => $this->input->post('affiliatedIGs'),
			'affiliated_dwss_ucs' => $this->input->post('affiliatedWSUCs'),
			'affiliated_irrigation_ucs' => $this->input->post('affiliatedIrrUCs'),
			'affiliated_mus_ucs' => $this->input->post('affiliatedMUSUCs'),
			'affiliated_others' => $this->input->post('affiliatedOthers'),
			'cooperative_business' => $coopBusiness,
			'updated_date' => $this->input->post('dataUpdateDate'),
			'updated_by' => $this->session->userdata('loginName')
		);

		$result = $this->Repository_model->save_data('cooperative_information', $data, $this->input->post('id'));
		if ($result>=1) {
			echo "Saved";
		}else{
			echo $result;
		}
	}

	function getList(){
    $data = $row=array();
    // Fetch IgDataTable's records
    $coops = $this->Coop_model->getRows($_POST);
    
    $i = $_POST['start'];
    foreach($coops->result() as $coop){
      $data[] = array(
        '<a onclick="delFunction('."'cooperative_information'".','.$coop->Id.', this)" href="#"><span class="fa fa-trash btn btn-danger btn-sm" title="Delete Record"></span></a>
        <a onclick="getById('."'cooperative_information'".','. $coop->Id .')" href="#"><span class="fa fa-pencil btn btn-info btn-sm" title="Open Edit Form"></span></a>
        <a href="Reports/getCoopDetail/'.$coop->Id.'")"><i class="btn btn-primary btn-sm fa fa-file-excel-o" aria-hidden="true" title="Get Detail in Excel"></i></a>',
        $coop->District,
        $coop->RM,
        $coop->Ward,
        $coop->Cooperative_Name,
        $coop->share_member_female,
        $coop->share_member_male,
        $coop->share_member_institution,
        $coop->share_member_dalit,
        $coop->share_member_janajati,
        $coop->share_member_other,
        $coop->total_share_amount,
        $coop->total_saving,
        $coop->ws_om_relief_fund,
        $coop->loan_in_ig,
        $coop->no_of_ig_investment,
        $coop->loan_in_livestock,
        $coop->no_of_livestock_loans,
        $coop->loan_in_business,
        $coop->no_of_business_loan,
        $coop->loan_in_foreign_employment,
        $coop->no_of_employment_loan,
        $coop->loan_in_home_loan,
        $coop->no_of_home_loan,
        $coop->interest_income,
        $coop->other_income,
        $coop->total_income,
        $coop->total_expenditure,
        $coop->interest_dues,
        $coop->interest_over_dues,
        $coop->oss,
        $coop->affiliated_cos,
        $coop->affiliated_hg_ig,
        $coop->affiliated_dwss_ucs,
        $coop->affiliated_irrigation_ucs,
        $coop->affiliated_mus_ucs,
        $coop->affiliated_others,
        $coop->cooperative_business
      );
    }
    
    $output = array(
      "draw" => $_POST['draw'],
      "recordsTotal" => $this->Coop_model->countAll(),
      "recordsFiltered" => $this->Coop_model->countFiltered($_POST),
      "data" => $data,
    );    
    // Output to JSON format
    echo json_encode($output);
  }

  function getDetail(){
  	
  }
}