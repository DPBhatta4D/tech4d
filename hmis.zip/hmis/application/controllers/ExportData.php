<?php defined('BASEPATH') OR exit('No direct script access allowed');

require FCPATH . '/vendor/autoload.php';
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
class ExportData extends CI_Controller 
{	
    
    function __construct(){
        parent:: __construct();
        $this->load->model('Repository_model');
    }

    public function getData() {
        $spreadsheet = new Spreadsheet(); // instantiate Spreadsheet
        $sheet = $spreadsheet->getActiveSheet();

        // manually set table data value
        $sheet->setCellValue('A1', 'District'); 
        $sheet->setCellValue('B1', 'R/MC');
        $sheet->setCellValue('C1', 'Ward Number');
        $sheet->setCellValue('D1', 'Cluster Name');
        $sheet->setCellValue('E1', 'Group Name');
        $sheet->setCellValue('F1', 'Group Code');
        $sheet->setCellValue('G1', 'Group Formation Date');
        $sheet->setCellValue('H1', 'Form Fill Up Date');
        $sheet->setCellValue('I1', 'Existence of Saving Fund');
        $sheet->setCellValue('J1', 'Amount in Saving Fund');
        $sheet->setCellValue('K1', 'Contribution per person per month');
        $sheet->setCellValue('L1', 'Meeting Practice');
        $sheet->setCellValue('M1', 'Affiliation to Cooperative');
        $sheet->setCellValue('N1', 'Cooperative Name');
        $sheet->setCellValue('O1', 'Cooperative Address');
        $sheet->setCellValue('P1', 'Is Group Registered ?');
        $sheet->setCellValue('Q1', 'Registered To');
        $sheet->setCellValue('R1', 'Registration No');
        $sheet->setCellValue('S1', 'Registered Date');
        $sheet->setCellValue('T1', 'Scheme Code if Applicable');
        $sheet->setCellValue('U1', 'Other info if any');
         
        // get data from database and fed into excel file
        $data = $this->Repository_model->reportData('homegarden');
        $row=2;
        foreach ($data as $col) {
            $sheet->setCellValue('A' . $row, $col['District']); 
            $sheet->setCellValue('B' . $row, $col['RM']);
            $sheet->setCellValue('C' . $row, $col['Ward_No']);
            $sheet->setCellValue('D' . $row, $col['Cluster_Name']);
            $sheet->setCellValue('E' . $row, $col['Group_Name']);
            $sheet->setCellValue('F' . $row, $col['Group_Code']);
            $sheet->setCellValue('G' . $row, $col['Group_Formated_Date']);
            $sheet->setCellValue('H' . $row, $col['Form_Filled_Date']);
            $sheet->setCellValue('I' . $row, $col['Saving_Fund']);
            $sheet->setCellValue('J' . $row, $col['Fund_Amount']);
            $sheet->setCellValue('K' . $row, $col['fundPerPersonPerPerson']);
            $sheet->setCellValue('L' . $row, $col['Meeting_Day']);
            $sheet->setCellValue('M' . $row, $col['Coop_Affiliation']);
            $sheet->setCellValue('N' . $row, $col['Coop_Name']);
            $sheet->setCellValue('O' . $row, $col['Coop_Address']);
            $sheet->setCellValue('P' . $row, $col['Group_Registration']);
            $sheet->setCellValue('Q' . $row, $col['Registered_To']);
            $sheet->setCellValue('R' . $row, $col['Registration_No']);
            $sheet->setCellValue('S' . $row, $col['Registered_Date']);
            $sheet->setCellValue('T' . $row, $col['Scheme_Code']);            
            $sheet->setCellValue('U' . $row, $col['Others']);
            $row++;
        }
        //$sheet->getActiveSheet()->setTitle('Home_Garden');

        //Adding sheet for IG
        $sheet=$spreadsheet->createSheet();
        $sheet->setCellValue('A1', 'District'); 
        $sheet->setCellValue('B1', 'R/MC');
        $sheet->setCellValue('C1', 'Ward Number');
        $sheet->setCellValue('D1', 'Info Type');
        $sheet->setCellValue('E1', 'Cluster Name');
        $sheet->setCellValue('F1', 'Group/Person Name');
        $sheet->setCellValue('G1', 'Group/Person Code');
        $sheet->setCellValue('H1', 'Business Start Date');
        $sheet->setCellValue('I1', 'Form Fill Up Date');
        $sheet->setCellValue('J1', 'Business Type');
        $sheet->setCellValue('K1', 'Business Sector');
        $sheet->setCellValue('L1', 'Existence of Saving Fund');
        $sheet->setCellValue('M1', 'Amount in Saving Fund');
        $sheet->setCellValue('N1', 'Contribution per person per month');
        $sheet->setCellValue('O1', 'Affiliation to Cooperative');
        $sheet->setCellValue('P1', 'Cooperative Address');
        $sheet->setCellValue('Q1', 'Loan Taken From Cooperative?');
        $sheet->setCellValue('R1', 'Is Group Registered ?');
        $sheet->setCellValue('S1', 'Registered To');
        $sheet->setCellValue('T1', 'Registration No');
        $sheet->setCellValue('U1', 'Registered Date');
        $sheet->setCellValue('V1', 'Scheme Code if Applicable');
        $sheet->setCellValue('W1', 'Other info if any');
        //$spreadsheet->getActiveSheet()->setTitle('IG Data');
        // get data from database and fed into excel file
        $data = $this->Repository_model->reportData('ig_info');
        $row=2;
        foreach ($data as $col) {
            $sheet->setCellValue('A' . $row, $col['District']); 
            $sheet->setCellValue('B' . $row, $col['RM']);
            $sheet->setCellValue('C' . $row, $col['Ward_No']);
            $sheet->setCellValue('C' . $row, $col['IG_Info_Type']);
            $sheet->setCellValue('D' . $row, $col['Cluster_Name']);
            $sheet->setCellValue('E' . $row, $col['Group_Person_Name']);
            $sheet->setCellValue('F' . $row, $col['Group_Person_Code']);
            $sheet->setCellValue('G' . $row, $col['Business_Start_Date']);
            $sheet->setCellValue('H' . $row, $col['Form_Filled_Date']);
            $sheet->setCellValue('J' . $row, $col['Business_Type']);
            $sheet->setCellValue('J' . $row, $col['IG_Sector']);
            $sheet->setCellValue('K' . $row, $col['Saving_Fund']);
            $sheet->setCellValue('L' . $row, $col['Fund_Amount']);
            $sheet->setCellValue('M' . $row, $col['Fund_Per_Person']);
            $sheet->setCellValue('N' . $row, $col['Coop_Affiliation']);
            $sheet->setCellValue('O' . $row, $col['Coop_Name']);
            $sheet->setCellValue('P' . $row, $col['Coop_Address']);
            $sheet->setCellValue('Q' . $row, $col['Loan_From_Coop']);
            $sheet->setCellValue('R' . $row, $col['Group_Registration']);
            $sheet->setCellValue('S' . $row, $col['Registered_To']);
            $sheet->setCellValue('T' . $row, $col['Registration_No']);
            $sheet->setCellValue('U' . $row, $col['Registered_Date']);
            $sheet->setCellValue('V' . $row, $col['Scheme_Code']);            
            $sheet->setCellValue('W' . $row, $col['Others']);
            $row++;
        }
        //Adding Sheet for IG Income
        $sheet=$spreadsheet->createSheet();
        $sheet->setCellValue('A1', 'Group/Person Name'); 
        $sheet->setCellValue('B1', 'Particulars');
        $sheet->setCellValue('C1', 'FY 2074/75');
        $sheet->setCellValue('D1', 'FY 2075/76');
        $sheet->setCellValue('E1', 'FY 2076/77');
        $sheet->setCellValue('F1', 'FY 2077/78');
        $data = $this->Repository_model->getIncomeData();
        $row=2;
        foreach ($data as $col) {
            $sheet->setCellValue('A' . $row, $col['Group_Person_Name']); 
            $sheet->setCellValue('B' . $row, $col['Particulars']);
            $sheet->setCellValue('C' . $row, $col['FY2074_75']);
            $sheet->setCellValue('D' . $row, $col['FY2075_76']);
            $sheet->setCellValue('E' . $row, $col['FY2076_77']);
            $sheet->setCellValue('F' . $row, $col['FY2077_78']);
            $row++;
        }
        

        $writer = new Xlsx($spreadsheet); // instantiate Xlsx 
        $filename = 'Homegarden_Data'; // set filename for excel file to be exported 
        header('Content-Type: application/vnd.ms-excel'); // generate excel file
        header('Content-Disposition: attachment;filename="'. $filename .'.xlsx"'); 
        header('Cache-Control: max-age=0');        
        $writer->save('php://output');	// download file
    }

} 