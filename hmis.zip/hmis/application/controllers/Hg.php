<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * 
 */
class Hg extends CI_Controller
{
	function __construct(){
		parent::__construct();
		$this->load->model('Repository_model');
    $this->load->model('HgDataTable');
		if (! $this->session->userdata('loginId')) {
			redirect('Login');
		}
	}

  function getList(){
    $data = $row=array();
    // Fetch IgDataTable's records
    $groups = $this->HgDataTable->getRows($_POST);
    
    $i = $_POST['start'];
    foreach($groups->result() as $group){
      $data[] = array(
        '<a onclick="addMembers('.$group->Id.')" href="#"><span class="btn btn-info btn-sm">सदस्य</span></a>
        <a onclick="getLF_Income('.$group->Id.')" href="#" class="btn btn-info btn-sm" title="अगुवा कृषक आम्दानी विवरण"><i class="fa fa-inr" aria-hidden="true"></i></a>
        <a onclick="getById('."'homegarden'".','. $group->Id .')" href="#"><span class="fa fa-pencil btn btn-info btn-sm"></span></a>
        <a onclick="delFunction('."'homegarden'".','.$group->Id.', this)" href="#"><span class="fa fa-trash btn btn-danger btn-sm"></span></a>',
        $group->District,
        $group->RM,
        $group->Ward_No,
        $group->Cluster_Name,
        $group->Group_Name,
        $group->Group_Code,
        $group->Group_Formated_Date,
        $group->training_date,
        $group->Form_Filled_Date,
        $group->Saving_Fund,
        $group->Fund_Amount,
        $group->fundPerPersonPerPerson,
        $group->Meeting_Day,
        $group->Coop_Affiliation,
        $group->Coop_Name,
        $group->Coop_Address,
        $group->Group_Registration,
        $group->Registered_To,
        $group->Registration_No,
        $group->Registered_Date,
        $group->Scheme_Code,
        $group->Others,
      );
    }
    
    $output = array(
      "draw" => $_POST['draw'],
      "recordsTotal" => $this->HgDataTable->countAll(),
      "recordsFiltered" => $this->HgDataTable->countFiltered($_POST),
      "data" => $data,
    );    
    // Output to JSON format
    echo json_encode($output);
  }
  
	function index(){
		$title['page_title']= 'HMIS: Home';
		$this->load->view('includes/header', $title);
		$this->load->view('hg-ig/homegarden');
		$this->load->view('includes/footer');
	}

	function saveData(){
    $id = $this->input->post('id');
      $data = array(
        'District' => $this->input->post('district'),
        'RM' => $this->input->post('rmc'),
        'Ward_No' => $this->input->post('ward'),
        'Cluster_Name' => $this->input->post('clusterName'),
        'Group_Name' => $this->input->post('hgName'),
        'Group_Code' => $this->input->post('hgCode'),
        'Group_Formated_Date' => $this->input->post('formatedDate'),
        'training_date' => $this->input->post('trainingDate'),
        'Form_Filled_Date' => $this->input->post('formFilledDate'),
        'Saving_Fund' => $this->input->post('savingFund'),
        'Fund_Amount' => $this->input->post('fundAmount'),
        'fundPerPersonPerPerson' => $this->input->post('fundPerPersonPerPerson'),
        'Meeting_Day' => $this->input->post('meetingDay'),
        'Coop_Affiliation' => $this->input->post('coopAffiliation'),
        'Coop_Name' => $this->input->post('coopName'),
        'Coop_Address' => $this->input->post('coopAddress'),
        'Group_Registration' => $this->input->post('hgRegistration'),
        'Registered_To' => $this->input->post('registeredTo'),
        'Registration_No' => $this->input->post('registrationNo'),
        'Registered_Date' => $this->input->post('registrationDate'),
        'Scheme_Code' => $this->input->post('schemeName'),
        'DF' => $this->input->post('df'),
        'DM' => $this->input->post('dm'),
        'JF' => $this->input->post('jf'),
        'JM' => $this->input->post('jm'),
        'OF' => $this->input->post('of'),
        'OM' => $this->input->post('om'),
        'Others' => $this->input->post('others'),
        'Added_By' => $this->session->userdata('loginName')
      );
		$res = $this->Repository_model->save_data('homegarden', $data, $id);
		if ($res==1) {
			$this->session->set_flashdata('msg','success');
			redirect('Hg');
		}else{
			echo 'Saving Error';
		}
	}


  function addMembers(){
    $hId = $this->input->post('hgId');
    $memName= $this->input->post('memName');
    $df= $this->input->post('dfm');
    $dm= $this->input->post('dmm');
    $jf= $this->input->post('jfm');
    $jm= $this->input->post('jmm');
    $of= $this->input->post('ofm');
    $om= $this->input->post('omm');

    foreach ($memName as $key => $value) {
      $data[] = array(
        'hgId'=>$hId,
        'MemberName' => $value,
        'DF'=>$df[$key],
        'DM'=>$dm[$key],
        'JF'=>$jf[$key],
        'JM'=>$jm[$key],
        'OF'=>$of[$key],
        'OM'=>$om[$key]
      );
    }

    try {
      $this->db->trans_begin();
      $res = $this->db->insert_batch('hgmembers', $data);
      if(!$res) throw new Exception($this->db->_error_message(), $this->db->_error_number());
      $this->db->trans_commit();
      echo 'Saved';
    } catch (Exception $e) {
      $this->db->trans_rollback();
      $e->getMessage();
    }
  }

  function getMembers(){
    $hId = $this->input->post('hid');
    
    $this->db->where('hgId', $hId);
    $members = $this->db->get('hgmembers')->result();
    //echo $this->db->last_query();
    $tr = '';
    foreach ($members as $member) {
      $tr.='<tr><td width="150">'.$member->MemberName.'</td>';
      $tr.='<td>'.$member->DF.'</td>';
      $tr.='<td>'.$member->DM.'</td>';
      $tr.='<td>'.$member->JF.'</td>';
      $tr.='<td>'.$member->JM.'</td>';
      $tr.='<td>'.$member->OF.'</td>';
      $tr.='<td>'.$member->OM.'</td>';
      $tr.='<td width="50"><a onclick="delFunction('."'hgmembers',".$member->Id.', this)" href="#"><span class="fa fa-trash btn btn-danger btn-sm"></span></a></td></tr>';
    }
    echo $tr;
  }
  
  function getMemberIncome(){
    $hId = $this->input->post('hid');    
    $this->db->where('Hg_Id', $hId);
    $members = $this->db->get('hgm_income_info')->result();
    $tr = '';
    foreach ($members as $member) {
      $tr.='<tr><td width="150">'.$member->LF_Name.'</td>';
      $tr.='<td style="text-align:right;">'.$member->FY2074_75.'</td>';
      $tr.='<td style="text-align:right;">'.$member->FY2075_76.'</td>';
      $tr.='<td style="text-align:right;">'.$member->FY2076_77.'</td>';
      $tr.='<td style="text-align:right;">'.$member->FY2077_78.'</td>';
      $tr.='<td style="text-align:right;">'.$member->FY2078_79.'</td>';
      $tr.='<td width="150" style="text-align:right;"><a onclick="editMemberIncome('.$member->Id.', this)" href="#" style="padding-right:10px;"><span class="fa fa-pencil"></span></a>
      <a onclick="delFunction('."'hgm_income_info',".$member->Id.', this)" href="#"><span class="fa fa-trash"></span></a>
      </td></tr>';
    }
    echo $tr;
  }

  function getMembersList(){
    $this->db->distinct();
    $this->db->select('MemberName');
    $this->db->where('hgId', $this->input->post('hid'));
    $members = $this->db->get('hgmembers')->result();
    $opt = '<option></option>';
    foreach ($members as $m) {
      $opt .='<option>'.$m->MemberName.'</option>';
    }
    echo $opt;
  }

  function saveMemberIncome(){

    $id = $this->input->post('iid');
    $hg = $this->input->post('hgid');
    $lf = $this->input->post('lf_name');
    $f74_75 = $this->input->post('fy74_75');
    $f75_76 = $this->input->post('fy75_76');
    $f76_77 = $this->input->post('fy76_77');
    $f77_78 = $this->input->post('fy77_78');
    $f78_79 = $this->input->post('fy78_79');

    foreach ($lf as $key => $value) {
      $data[]=array(
        'Id' => $id,
        'Hg_Id' => $hg,
        'LF_Name' => $value,
        'FY2074_75' => $f74_75[$key],
        'FY2075_76' => $f75_76[$key],
        'FY2076_77' => $f76_77[$key],
        'FY2077_78' => $f77_78[$key],
        'FY2078_79' => $f78_79[$key]
      );
    }

    $saved = $this->Repository_model->saveIncome('hgm_income_info', $id, $data);
    if ($saved==1) {
      echo "Saved Successfully";
    }else{
      echo $saved;
    }
  }

  function getIncomeById(){
    $id = $this->input->post('Id');
    $memberIncome = $this->Repository_model->getMemberIncome($id, 'hgm_income_info');
    echo(json_encode($memberIncome));
  }
}