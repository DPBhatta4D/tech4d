<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * 
 */
class Home extends CI_Controller
{
	function __construct(){
		parent::__construct();
		$this->load->model('Repository_model');
		if (! $this->session->userdata('loginId')) {
			redirect('Login');
		}
	}
  
	function index(){
	   $bens = $this->Repository_model->getRAS();
        $tr="";
        $sn = 1;
        $ben = 0;
        $hh = 0;
        foreach ($bens as $b) {
          if ($b->Activity=='AGB') 
            $act = 'Agribusiness';
          else if ($b->Activity=='CC') 
            $act = 'Collection Center';
          else
            $act = $b->Activity;
    
          $tr .="<tr><td>".$sn."</td>";
          $tr .="<td>".$act."</td>";
          $tr .="<td style='text-align: right;'>".number_format($b->BenHH)."</td>";
          $tr .="<td style='text-align: right;'>".number_format($b->BenPop)."</td></tr>";
          $sn++;
          $ben = $ben+$b->BenPop;
          $hh = $hh+$b->BenHH;
        }
    
        $tr .="<tfoot><tr><th colspan='2'>Total</th><th style='text-align: right;'>".number_format($hh)."</th>";
        $tr .="<th style='text-align: right;'>".number_format($ben)."</th></tr></tfoot>";
        $data['ras']=$tr;
    		$title['page_title']= 'HMIS: Home';
    		$this->load->view('includes/header', $title);
    		$this->load->view('home/welcome', $data);
    		$this->load->view('includes/footer');
	}

	function saveHGData(){		
		$res = $this->Repository_model->save_data('homegarden');
		if ($res==1) {
			$this->session->set_flashdata('msg','success');
			redirect('Home');
		}else{
			echo 'Saving Error';
		}
	}

	function saveIGData(){		
		$res = $this->Repository_model->save_data('ig_info');
		if ($res==1) {
			$this->session->set_flashdata('msg','success');
			redirect('Home');
		}else{
			echo $res; die();
		}
	}
	function saveIncomeData()
	{
		$res=$this->Repository_model->saveIncome();
		if ($res==1) {
			$this->session->set_flashdata('msg','success');
			redirect('Home');
		}else{
			echo $res;
		}
	}
	function getRM()
    {
    	$this->load->model('Dropdownvalue_model');
    	$district = $this->input->post('district');
    	$rms = $this->Dropdownvalue_model->getRM($district);
    	$output = '<option>गाउँ/नगरपालिका छान्नुहोस्</option>';
    	foreach ($rms as $rm) {
    		$output .='<option>'.$rm->RM.'</option>';
    	}
    	echo $output;
    }

    function delete(){
    	$tbl = $this->uri->segment('3');
		$id = $this->uri->segment('4');
		$res = $this->Repository_model->deleteInfo($tbl,$id);
		if ($res==1) {
			echo 'deleted';
		}else{
			echo $res;
		}
	}

  

	function getIncomes(){
		$id = $this->uri->segment('3');
		$data=$this->Repository_model->getById($id,'income_info');
		//print_r($data); die();
		if (!empty($data)) {
			$table = "<table class='table table-bordered table-hover table-striped' id='icTable'><tr><th>Particulars</th><th>FY 2074/75</th><th>FY 2054/76</th><th>FY 2076/77</th><th>FY 2077/78</th><th></th></tr>";
	        foreach ($data as $d) {
	        	
	        	$table.='<tr><td>'.$d->Particulars.'</td>';
	        	$table.='<td>'.$d->FY2074_75.'</td>';
	        	$table.='<td>'.$d->FY2075_76.'</td>';
	        	$table.='<td>'.$d->FY2076_77.'</td>';
	        	$table.='<td>'.$d->FY2077_78.'</td>';
            $table.='<td style="text-align:center;"><a title="Edit" onclick="getIncomeById('.$d->Id.')" href="#" class="btn btn-primary btn-sm"> <span class="fa fa-pencil"></span></a></td></tr>';
	        }
	        $table.='</table>';
	        echo $table;
		}else
		{
			echo '<form id="frmIncome" action="'. base_url("Home/saveIncomeData").'" method="POST">
			<div class="form-group">
			<input type="hidden" value="'.$id.'" name="igId">
            <label class="control-label col-md-3 col-sm-6 col-xs-12">विवरण</label>
            <label class="control-label col-md-2 col-sm-6 col-xs-12">आ.व. २०७४/७५</label>
            <label class="control-label col-md-2 col-sm-6 col-xs-12">आ.व. २०७५/७६</label>
            <label class="control-label col-md-2 col-sm-6 col-xs-12">आ.व. २०७६/७७</label>
            <label class="control-label col-md-2 col-sm-6 col-xs-12">आ.व. २०७७/७८</label>
            <div class="row" style="margin-top: -10px;">
              <div class="col-md-12" >
                <p class="control-label col-md-3">समुहगत वा व्यक्तिगत जम्मा रु.</p>
                <input type="hidden" name="particulars[]" value="Total Income">
                <div class="col-md-2">
                  <input type="text" name="fy74_75[]" class="form-control col-md-2" style="text-align: right;">
                </div>
                <div class="col-md-2">
                  <input type="text" name="fy75_76[]" class="form-control col-md-2" style="text-align: right;">
                </div>
                <div class="col-md-2">
                  <input type="text" name="fy76_77[]" class="form-control col-md-2" style="text-align: right;">
                </div>
                <div class="col-md-2">
                  <input type="text" name="fy77_78[]" class="form-control col-md-2" style="text-align: right;">
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-12">
                <p class="control-label col-md-3 col-sm-6 col-xs-12">प्रति व्यक्ति औषत रु.</p>
                <input type="hidden" name="particulars[]" value="Average Per Person Income">
                <div class="col-md-2">
                  <input type="text" name="fy74_75[]" class="form-control col-md-2" style="text-align: right;">
                </div>
                <div class="col-md-2">
                  <input type="text" name="fy75_76[]" class="form-control col-md-2" style="text-align: right;">
                </div>
                <div class="col-md-2">
                  <input type="text" name="fy76_77[]" class="form-control col-md-2" style="text-align: right;">
                </div>
                <div class="col-md-2">
                  <input type="text" name="fy77_78[]" class="form-control col-md-2" style="text-align: right;">
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-12">
                <p class="control-label col-md-3 col-sm-6 col-xs-12">सबै भन्दा कम आम्दानी गर्ने रु.</p>
                <input type="hidden" name="particulars[]" value="Least Income">
                <div class="col-md-2">
                  <input type="text" name="fy74_75[]" class="form-control col-md-2" style="text-align: right;">
                </div>
                <div class="col-md-2">
                  <input type="text" name="fy75_76[]" class="form-control col-md-2" style="text-align: right;">
                </div>
                <div class="col-md-2">
                  <input type="text" name="fy76_77[]" class="form-control col-md-2" style="text-align: right;">
                </div>
                <div class="col-md-2">
                  <input type="text" name="fy77_78[]" class="form-control col-md-2" style="text-align: right;">
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-12">
                <p class="control-label col-md-3 col-sm-6 col-xs-12">सबै भन्दा बढी आम्दानी गर्ने रु.</p>
                <input type="hidden" name="particulars[]" value="Max Income">
                <div class="col-md-2">
                  <input type="text" name="fy74_75[]" class="form-control col-md-2" style="text-align: right;">
                </div>
                <div class="col-md-2">
                  <input type="text" name="fy75_76[]" class="form-control col-md-2" style="text-align: right;">
                </div>
                <div class="col-md-2">
                  <input type="text" name="fy76_77[]" class="form-control col-md-2" style="text-align: right;">
                </div>
                <div class="col-md-2">
                  <input type="text" name="fy77_78[]" class="form-control col-md-2" style="text-align: right;">
                </div>
              </div>
            </div>
        </div>
        <div class="ln_solid"></div>
        	<div class="form-group">
	            <div class="col-md-12 col-md-offset-10">
	              <button type="submit" id="submit" class="btn btn-success">Submit</button>
	            </div>
          </div>
        </form>';
		}
        
	}

	function getById(){
		$tbl = $this->uri->segment('3');
		$id = $this->uri->segment('4');
		$data=$this->Repository_model->getById($id,$tbl);
        echo json_encode($data);
	}

  function addMembers(){
    $hId = $this->input->post('hgId');
    $memName= $this->input->post('memName');
    $df= $this->input->post('dfm');
    $dm= $this->input->post('dmm');
    $jf= $this->input->post('jfm');
    $jm= $this->input->post('jmm');
    $of= $this->input->post('ofm');
    $om= $this->input->post('omm');

    foreach ($memName as $key => $value) {
      $data[] = array(
        'hgId'=>$hId,
        'MemberName' => $value,
        'DF'=>$df[$key],
        'DM'=>$dm[$key],
        'JF'=>$jf[$key],
        'JM'=>$jm[$key],
        'OF'=>$of[$key],
        'OM'=>$om[$key]
      );
    }

    try {
      $this->db->trans_begin();
      $res = $this->db->insert_batch('hgmembers', $data);
      if(!$res) throw new Exception($this->db->_error_message(), $this->db->_error_number());
      $this->db->trans_commit();
      echo 'Saved';
    } catch (Exception $e) {
      $this->db->trans_rollback();
      $e->getMessage();
    }
  }

  function getMembers(){
    $hId = $this->input->post('hid');
    
    $this->db->where('hgId', $hId);
    $members = $this->db->get('hgmembers')->result();
    //echo $this->db->last_query();
    $tr = '';
    foreach ($members as $member) {
      $tr.='<tr><td>'.$member->MemberName.'</td>';
      $tr.='<td>'.$member->DF.'</td>';
      $tr.='<td>'.$member->DM.'</td>';
      $tr.='<td>'.$member->JF.'</td>';
      $tr.='<td>'.$member->JM.'</td>';
      $tr.='<td>'.$member->OF.'</td>';
      $tr.='<td>'.$member->OM.'</td><td></td></tr>';
    }
    echo $tr;
  }
  //====================================================================

  function getIncomeById(){
    $id = $this->input->post('id');
    $income = $this->Repository_model->getRowById($id, 'income_info');

    $tr ='<tr><td><input type="text" id="particulars" class="form-control col-md-2" style="text-align: right;" value="'.$income->Particulars.'" readonly></td>';
    $tr .='<td><input type="text" id="fy74_75" class="form-control col-md-2" style="text-align: right;" value="'.$income->FY2074_75.'"></td>';
    $tr .='<td><input type="text" id="fy75_76" class="form-control col-md-2" style="text-align: right;" value="'.$income->FY2075_76.'"></td>';
    $tr .='<td><input type="text" id="fy76_77" class="form-control col-md-2" style="text-align: right;" value="'.$income->FY2076_77.'"></td>';
    $tr .='<td><input type="text" id="fy77_78" class="form-control col-md-2" style="text-align: right;" value="'.$income->FY2077_78.'"></td>';
    $tr .='<td><a title="Edit" onclick="updateIncomeById()" href="#" class="btn btn-success btn-sm"> <span class="fa fa-floppy-o"></span></a><a title="Edit" onclick="cancelEdit(this)" href="#" class="btn btn-danger btn-sm"> <span class="fa fa-trash"></span></a></td></tr>';
    $tr .='<input type="hidden" id ="editId" value="'.$income->Id.'">';
    $tr .='<input type="hidden" id ="editIgId" value="'.$income->IG_Id.'">';

    echo $tr;
  }

  function updateIncome(){
    $data=array(
      'Particulars'=> $this->input->post('particular'),
      'FY2074_75'=> $this->input->post('f7475'),
      'FY2075_76'=> $this->input->post('f7576'),
      'FY2076_77'=> $this->input->post('f7677'),
      'FY2077_78'=> $this->input->post('f7778')
    );

    $id = $this->input->post('id');
    $success = $this->Repository_model->updateIncomeData('income_info', $id, $data);
    if($success==1){
      echo "Saved Successfully";
    }else if($success==0){
      echo "No Change";
    }else{
      echo "Data update error";
    }
  }
	
}