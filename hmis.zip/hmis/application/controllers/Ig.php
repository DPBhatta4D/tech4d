<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * 
 */
class Ig extends CI_Controller
{
  function __construct(){
    parent::__construct();
    $this->load->model('Repository_model');
    $this->load->model('IgDataTables_model');
    if (! $this->session->userdata('loginId')) {
      redirect('Login');
    }
  }

  function getList(){
    $data = $row=array();
    // Fetch IgDataTable's records
    $igData = $this->IgDataTables_model->getRows($_POST);
    
    $i = $_POST['start'];
    foreach($igData->result() as $ig){
      $data[] = array(
        '<a onclick="delFunction('."'ig_info'".','.$ig->Id.', this)" href="#"><span class="fa fa-trash btn btn-danger btn-sm"></span></a>
        <a onclick="getById('."'ig_info'".','. $ig->Id .')" href="#"><span class="fa fa-pencil btn btn-info btn-sm"></span></a>
        <a onclick="getIncome('.$ig->Id.')" href="#"><span class="btn btn-info btn-sm">आम्दानी</span>
        </a>', 
        $ig->IG_Info_Type,
        $ig->District,
        $ig->RM,
        $ig->Ward_No,
        $ig->Cluster_Name,
        $ig->Group_Person_Name,
        $ig->Group_Person_Code,
        $ig->Business_Start_Date,
        $ig->Form_Filled_Date,
        $ig->Business_Type,
        $ig->IG_Sector,
        $ig->Saving_Fund,
        $ig->Fund_Amount,
        $ig->Fund_Per_Person,
        $ig->Coop_Affiliation,
        $ig->Coop_Name,
        $ig->Coop_Address,
        $ig->Loan_From_Coop,
        $ig->Group_Registration,
        $ig->Registered_To,
        $ig->Registration_No,
        $ig->Registered_Date,
        $ig->Scheme_Code,
        $ig->Others
      );
    }
    
    $output = array(
        "draw" => $_POST['draw'],
        "recordsTotal" => $this->IgDataTables_model->countAll(),
        "recordsFiltered" => $this->IgDataTables_model->countFiltered($_POST),
        "data" => $data,
    );
    
    // Output to JSON format
    echo json_encode($output);
  }

  function index(){
    // $data['igs']=$this->Repository_model->getAll_Data('ig_info');
    $title['page_title']= 'HMIS: Home';
    $this->load->view('includes/header', $title);
    $this->load->view('hg-ig/income-generation');
    $this->load->view('includes/footer');
  }

  function saveIGData(){
    $id = $this->input->post('IG_id');
      $data = array(
        'District' => $this->input->post('IG_district'),
        'RM' => $this->input->post('IG_rmc'),
        'Ward_No' => $this->input->post('IG_ward'),
        'IG_Info_Type' => $this->input->post('IG_Info_Type'),
        'Cluster_Name' => $this->input->post('IG_clusterName'),
        'Group_Person_Name' => $this->input->post('Group_Person_Name'),
        'Group_Person_Code' => $this->input->post('Group_Person_Code'),
        'Business_Start_Date' => $this->input->post('Business_Start_Date'),
        'Form_Filled_Date' => $this->input->post('ig_formFilledDate'),
        'Business_Type' => $this->input->post('Business_Type'),
        'IG_Sector' => $this->input->post('IG_Sector'),
        'Saving_Fund' => $this->input->post('ig_savingFund'),
        'Fund_Amount' => $this->input->post('ig_fundAmount'),
        'Fund_Per_Person' => $this->input->post('Fund_Per_Person'),
        'Coop_Affiliation' => $this->input->post('ig_coopAffiliation'),
        'Coop_Name' => $this->input->post('ig_coopName'),
        'Coop_Address' => $this->input->post('ig_coopAddress'),
        'Loan_From_Coop' => $this->input->post('Loan_From_Coop'),
        'Group_Registration' => $this->input->post('ig_Registration'),
        'Registered_To' => $this->input->post('ig_registeredTo'),
        'Registration_No' => $this->input->post('ig_registrationNo'),
        'Registered_Date' => $this->input->post('Registered_Date'),
        'Scheme_Code' => $this->input->post('Scheme_Code'),
        'DF' => $this->input->post('df'),
        'DM' => $this->input->post('dm'),
        'JF' => $this->input->post('jf'),
        'JM' => $this->input->post('jm'),
        'OF' => $this->input->post('of'),
        'OM' => $this->input->post('om'),
        'Others' => $this->input->post('ig_others'),
        'Added_By' => $this->session->userdata('loginName')
      );
    $res = $this->Repository_model->save_data('ig_info', $data, $id);
    if ($res==1) {
      $this->session->set_flashdata('msg','success');
      redirect('Ig');
    }else{
      echo $res; die();
    }
  }

  function saveIncomeData()
  {
    $id = $this->input->post('income_id');
    $igId = $this->input->post('hgId_income');
    $member = $this->input->post('MembersName');
    $hn = $this->input->post('HH_No');
    $caste = $this->input->post('CasteEthnicity');
    $male = $this->input->post('Male');
    $female = $this->input->post('Female');
    $f7475 = $this->input->post('2074_2075');
    $f7576 = $this->input->post('2075_2076');
    $f7677 = $this->input->post('2076_2077');
    $f7778 = $this->input->post('2077_2078');
    $f7879 = $this->input->post('2078_2079');

    foreach ($member as $key => $value) {
      $data[]=array(
        'Id'=>$id,
        'IgId'=>$igId,
        'MembersName'=>$value,
        'HH_No'=>$hn[$key],
        'CasteEthnicity'=>$caste[$key],
        'Male'=>$male[$key],
        'Female'=>$female[$key],
        'FY_2074_2075'=>$f7475[$key],
        'FY_2075_2076'=>$f7576[$key],
        'FY_2076_2077'=>$f7677[$key],
        'FY_2077_2078'=>$f7778[$key],
        'FY_2078_2079'=>$f7879[$key]
      );
    }

    $res =$this->Repository_model->saveIncome('ig_members', $id, $data);
    if ($res==1) {
      $this->session->set_flashdata('msg','success');
      echo "Saved";
    }else{
      echo $res;
    }
  }
  
  function getIncomes(){
    $id = $this->uri->segment('3');
    $data=$this->Repository_model->getIncomesById($id,'ig_members');
    $table = "";
    if (!empty($data)) {
      foreach ($data as $d) {            
        $table.='<tr><td>'.$d['MembersName'].'</td>';
        $table.='<td>'.$d['HH_No'].'</td>';
        $table.='<td>'.$d['CasteEthnicity'].'</td>';
        $table.='<td>'.$d['Male'].'</td>';
        $table.='<td>'.$d['Female'].'</td>';
        $table.='<td>'.$d['FY_2074_2075'].'</td>';
        $table.='<td>'.$d['FY_2075_2076'].'</td>';
        $table.='<td>'.$d['FY_2076_2077'].'</td>';
        $table.='<td>'.$d['FY_2077_2078'].'</td>';
        $table.='<td>'.$d['FY_2078_2079'].'</td>';
        $table.='<td style="text-align:center;"><a title="Edit" onclick="getMemberIncome('.$d['Id'].', this)" href="#"> <span class="fa fa-pencil"></span></a>&nbsp;&nbsp;&nbsp;
        <a title="Delete" onclick="delFunction('."'ig_members'".','.$d['Id'].', this)" href="#"> <span class="fa fa-trash-o"></span></a>
        </td></tr>';
      }
      
      echo $table;
    }else{
      $table.='<tr><td><input type="text" name="MembersName[]" id="MembersName" class="form-control" required></td>';
      $table.='<td width="80"><input type="number" min="0" name="HH_No[]" id="HH_No" class="form-control" required></td>';
      $table.='<td width="100"><select type="text" name="CasteEthnicity[]" id="CasteEthnicity" class="form-control" required><option>Dalit</option><option>Janajati</option><option>Others</option></select></td>';
      $table.='<td width="80"><input type="number" min="0" name="Male[]" id="Male" class="form-control" required></td>';
      $table.='<td width="80"><input type="number" min="0" name="Female[]" id="Female" class="form-control" required></td>';
      $table.='<td width="110"><input type="number" min="0" name="2074_2075[]" id="2074_2075" class="form-control" required></td>';
      $table.='<td width="110"><input type="number" min="0" name="2075_2076[]" id="2075_2076" class="form-control" required></td>';
      $table.='<td width="110"><input type="number" min="0" name="2076_2077[]" id="2076_2077" class="form-control" required></td>';
      $table.='<td width="110"><input type="number" min="0" name="2077_2078[]" id="2077_2078" class="form-control" required></td>';
      $table.='<td width="110"><input type="number" min="0" name="2078_2079[]" id="2078_2079" class="form-control" required></td>';
      $table.='<td><a href="javascript:void(0)" class="btn btn-sm btn-danger" onclick="cancelEdit(this)"><i class="fa fa-minus"></i></a></td></tr>';
      echo $table;
    }
        
  }

  //====================================================================

  function getIncomeById(){
    $id = $this->input->post('Id');
    $memberIncome = $this->Repository_model->getMemberIncome($id, 'ig_members');
    echo(json_encode($memberIncome));
  }
  
}