<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * 
 */
class ItemCost extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();
		$this->load->model('Repository_model');
		if (! $this->session->userdata('loginId')) {
			redirect('Login');
		}
	}

	function index(){
		$sCode = $this->input->post('scheme');

		$scheme = $this->getItemCosts($sCode);

		if ($scheme=='No Data') {

			$formELe = $this->getFormElements();
			echo $formELe;
		}else{
			echo $scheme;
		}
		
	}

	function addItemCost(){
		$scheme = $this->input->post('scode');
		$items = $this->input->post('items');
		$estimates = $this->input->post('estimates');
		$actuals = $this->input->post('actuals');
		$remarks = $this->input->post('remarks');
		foreach ($items as $key => $value) {
			$data[]=array(
				'Scheme_Code'=>$scheme,
				'Description'=>$value,
				'Estimated_Cost'=>$estimates[$key],
				'Actual_Cost'=>$actuals[$key],
				'Remarks'=>$remarks[$key],
				'Updated_By'=>$this->session->userdata('loginName'),
				'Updated_Date'=>date('Y-m-d h:m:sa')
			);
		}

		$saved = $this->Repository_model->addContribution_ItemCost('item_cost', $data);
		if ($saved==TRUE) {
			echo "Saved Successfully";
		}else{
			echo $saved;
		}

	}

	function getItemCostById(){
		$id = $this->input->post('Id');
		$tbl = $this->input->post('table');
		
		$ben = $this->Repository_model->getById($id, $tbl);
		echo json_encode($ben);
	}

	function updateItemCost(){
		$id = $this->input->post('id');
		$data =array(
			'Scheme_Code' => $this->input->post('code'),
			'Description' => $this->input->post('description'),
			'Estimated_Cost' => $this->input->post('Estimated'),
			'Actual_Cost' => $this->input->post('Actual'),
			'Remarks' => $this->input->post('Remarks'),
			'Updated_By' =>$this->session->userdata('loginName'),
			'Updated_Date'=>date('d-m-Y h:m:sa')
		);
		$success = $this->Repository_model->updateSchemeData('item_cost', $id, $data);
		if($success==1){
			echo "Saved Successfully";
		}else if($success==0){
			echo "No Change";
		}else{
			echo "Data update error";
		}
	}

	function getFormElements(){
		$td = '<thead><tr>
            <th width="170">Item Description</th>
            <th width="110">Estimated Cost</th>
            <th width="110">Actual Cost</th>
            <th width="150">Remarks</th>
        </tr></thead><tbody>';
        $costHeadings = $this->Repository_model->getFormElements('cost_headings');
        foreach ($costHeadings as $h) {
        	$td.='<tr><td width="170"><input type="text" readonly class="form-control" name="Descriptions[]" value="'.$h->Headings.'"></td>';
        	$td.='<td width="110"><input required type="number" step="0.01" min="0" value="0.00" class="form-control" name="Estimated_Costs[]"></td>';
        	$td.='<td width="110"><input required type="number" step="0.01" min="0" value="0.00" class="form-control" name="Actual_Costs[]" ></td>';
        	$td.='<td width="150"><input type="text" class="form-control" name="Remarks[]"></td></tr>';
        }
        $td.='<td colspan="4" style="text-align:center;"><button class="btn btn-sm btn-primary" onclick="saveItemCost()">Save </button></td></tr>';
        $td.='</tbody>';

        return $td;

	}

	function getItemCosts($scheme){
		echo $scheme;
		$itemcosts = $this->Repository_model->getSchemeData('item_cost', $scheme);
		
		$row = '<thead><tr>
            <th width="150">Item Description</th>
            <th width="110">Estimated Cost</th>
            <th width="110">Actual Cost</th>
            <th width="150">Remarks</th>
            <th width="80">Action</th></tr></thead><tbody>';
            $totalEstimate=0;
            $totalActual=0;
		if ($itemcosts) {
			foreach ($itemcosts as $ic){
				$row .='<tr><td width="150">'.$ic->Description.'</td>';
				$row .='<td width="110" style="text-align:right;">'.number_format($ic->Estimated_Cost,3).'</td>';
				$row .='<td width="110" style="text-align:right;">'.number_format($ic->Actual_Cost,3).'</td>';
				$row .='<td width="150">'.$ic->Remarks.'</td>';
				$row .='<td width="80" style="text-align:center;"><a title="Edit" onclick="getCostById('.$ic->Id.", 'item_cost'".')" href="#" class="btn btn-primary btn-sm"> <span class="fa fa-pencil"></span> 
					</a></td></tr>';
				$totalEstimate=$totalEstimate+$ic->Estimated_Cost;
				$totalActual=$totalActual+$ic->Actual_Cost;
			}
			$row .= '<tr>
            <th width="150">Total</th>
            <th width="110" style="text-align:right;">'.number_format($totalEstimate,3).'</th>
            <th width="110" style="text-align:right;">'.number_format($totalActual,3).'</th>
            <th width="150"></th>
            <th width="80"></th></tr>';

			$row.='</tbody';
			return $row;

		}else{
			return 'No Data';
		}
		
	}
}