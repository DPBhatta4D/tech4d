<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {
	function __construct()
	{
		parent::__construct();
		$this->load->model('users_model');
		if($this->session->userdata('loginId')){
			redirect('Home');
		}
	}
	public function index()
	{		
		$this->load->view('user/login');
	}
	function checkLogin()
	{			
		$row=$this->users_model->login();
		if(isset($row)){
			$this->session->set_userdata('loginId', $row->Id);
			$this->session->set_userdata('loginType', $row->UserType);
			$this->session->set_userdata('loginDistrict', $row->District);
			$this->session->set_userdata('loginRM', $row->RM);
			$this->session->set_userdata('loginName', $row->FullName);
			$this->session->set_userdata('fy', $this->fySelector());
			echo "success";
		}else
		{
			echo "error";
		}
	}

	function fySelector()
	{
		$month = date("m");
		$year = date("Y");
		$day = date("d");

		switch($month){
			case 7:
				if(($year==2018 && $day>15) || ($year==2019 && $day<=15))
					return "075/76";
				elseif(($year==2019 && $day>15) || ($year==2020 && $day<=15))
					return "076/77";
				elseif(($year==2020 && $day>15) || ($year==2021 && $day<=15))
					return "077/78";
				elseif(($year==2021 && $day>15) || ($year==2022 && $day<=15))
					return "078/79";
				elseif(($year==2022 && $day>15) || ($year==2023 && $day<=15))
					return "079/80";
				elseif(($year==2023 && $day>15) || ($year==2024 && $day<=15))
					return "080/81";
				elseif(($year==2024 && $day>15) || ($year==2025 && $day<=15))
					return "081/82";
				break;
			default:
				if(($year==2018 && $month>=8) || ($year==2019 && $month<=6))
					return "075/76";
				elseif(($year==2019 && $month>=8) || ($year==2020 && $month<=6))
					return "076/77";
				elseif(($year==2020 && $month>=8) || ($year==2021 && $month<=6))
					return "077/78";
				elseif(($year==2021 && $month>=8) || ($year==2022 && $month<=6))
					return "078/79";
				elseif(($year==2022 && $month>=8) || ($year==2023 && $month<=6))
					return "079/80";
				elseif(($year==2023 && $month>=8) || ($year==2024 && $month<=6))
					return "080/81";
				elseif(($year==2024 && $month>=8) || ($year==2025 && $month<=6))
					return "081/82";
		}		
	}	
}