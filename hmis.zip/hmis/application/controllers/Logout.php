<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Logout extends CI_Controller
{
	function index()
	{
		$this->session->unset_userdata('loginId');
		$this->session->unset_userdata('loginType');
		$this->session->unset_userdata('loginName');
		$this->session->unset_userdata('loginDistrict');
		$this->session->unset_userdata('loginRM');
		$this->session->unset_userdata('setting');
		$this->session->sess_destroy();
		redirect('Login');
	}
}