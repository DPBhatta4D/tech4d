<?php defined('BASEPATH') OR exit('No direct script access allowed');

require FCPATH . '/vendor/autoload.php';
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

class Reports extends CI_Controller 
{	
    
    function __construct(){
        parent:: __construct();
        $this->load->model('Repository_model');
    }

    
    public function HG_Data() {
        $spreadsheet = new Spreadsheet(); // instantiate Spreadsheet
        $sheet = $spreadsheet->getActiveSheet();

        // manually set table data value
        $sheet->setCellValue('A1', 'District'); 
        $sheet->setCellValue('B1', 'R/MC');
        $sheet->setCellValue('C1', 'Ward Number');
        $sheet->setCellValue('D1', 'Cluster Name');
        $sheet->setCellValue('E1', 'Group Name');
        $sheet->setCellValue('F1', 'Group Code');
        $sheet->setCellValue('G1', 'Group Formation Date');
        $sheet->setCellValue('H1', 'Form Fill Up Date');
        $sheet->setCellValue('I1', 'Existence of Saving Fund');
        $sheet->setCellValue('J1', 'Amount in Saving Fund');
        $sheet->setCellValue('K1', 'Contribution per person per month');
        $sheet->setCellValue('L1', 'Meeting Practice');
        $sheet->setCellValue('M1', 'Affiliation to Cooperative');
        $sheet->setCellValue('N1', 'Cooperative Name');
        $sheet->setCellValue('O1', 'Cooperative Address');
        $sheet->setCellValue('P1', 'Is Group Registered ?');
        $sheet->setCellValue('Q1', 'Registered To');
        $sheet->setCellValue('R1', 'Registration No');
        $sheet->setCellValue('S1', 'Registered Date');
        $sheet->setCellValue('T1', 'Scheme Code if Applicable');
        $sheet->setCellValue('U1', 'Dalit Female');
        $sheet->setCellValue('V1', 'Dalit Male');
        $sheet->setCellValue('W1', 'Janajati Female');
        $sheet->setCellValue('X1', 'Janajati Male');
        $sheet->setCellValue('Y1', 'Other Female');
        $sheet->setCellValue('Z1', 'Other Male');
        $sheet->setCellValue('AA1', 'Other info if any');
         
        // get data from database and fed into excel file
        $data = $this->Repository_model->reportData('homegarden');
        $row=2;
        foreach ($data as $col) {
            $sheet->setCellValue('A' . $row, $col['District']); 
            $sheet->setCellValue('B' . $row, $col['RM']);
            $sheet->setCellValue('C' . $row, $col['Ward_No']);
            $sheet->setCellValue('D' . $row, $col['Cluster_Name']);
            $sheet->setCellValue('E' . $row, $col['Group_Name']);
            $sheet->setCellValue('F' . $row, $col['Group_Code']);
            $sheet->setCellValue('G' . $row, $col['Group_Formated_Date']);
            $sheet->setCellValue('H' . $row, $col['Form_Filled_Date']);
            $sheet->setCellValue('I' . $row, $col['Saving_Fund']);
            $sheet->setCellValue('J' . $row, $col['Fund_Amount']);
            $sheet->setCellValue('K' . $row, $col['fundPerPersonPerPerson']);
            $sheet->setCellValue('L' . $row, $col['Meeting_Day']);
            $sheet->setCellValue('M' . $row, $col['Coop_Affiliation']);
            $sheet->setCellValue('N' . $row, $col['Coop_Name']);
            $sheet->setCellValue('O' . $row, $col['Coop_Address']);
            $sheet->setCellValue('P' . $row, $col['Group_Registration']);
            $sheet->setCellValue('Q' . $row, $col['Registered_To']);
            $sheet->setCellValue('R' . $row, $col['Registration_No']);
            $sheet->setCellValue('S' . $row, $col['Registered_Date']);
            $sheet->setCellValue('T' . $row, $col['Scheme_Code']);
            $sheet->setCellValue('U' . $row, $col['DF']);
            $sheet->setCellValue('V' . $row, $col['DM']);
            $sheet->setCellValue('W' . $row, $col['JF']);
            $sheet->setCellValue('X' . $row, $col['JM']);
            $sheet->setCellValue('Y' . $row, $col['OF']);
            $sheet->setCellValue('Z' . $row, $col['OM']);           
            $sheet->setCellValue('AA' . $row, $col['Others']);
            $row++;
        }

        $sheet->setTitle('Home_Garden');

        //Adding sheet for IG
        $sheet=$spreadsheet->createSheet();
        $sheet->setCellValue('A1', 'Id'); 
        $sheet->setCellValue('B1', 'HG Name');
        $sheet->setCellValue('C1', 'Member Name');
        $sheet->setCellValue('D1', 'DF');
        $sheet->setCellValue('E1', 'DM');
        $sheet->setCellValue('F1', 'JF');
        $sheet->setCellValue('G1', 'JM');
        $sheet->setCellValue('H1', 'OF');
        $sheet->setCellValue('I1', 'OM');

        $members = $this->Repository_model->getHgMembers();
        $row=2;
        foreach ($members as $col) {
            $sheet->setCellValue('A' . $row, $col['Id']); 
            $sheet->setCellValue('B' . $row, $col['Group_Name']);
            $sheet->setCellValue('C' . $row, $col['MemberName']);
            $sheet->setCellValue('D' . $row, $col['DF']);
            $sheet->setCellValue('E' . $row, $col['DM']);
            $sheet->setCellValue('F' . $row, $col['JF']);
            $sheet->setCellValue('G' . $row, $col['JM']);
            $sheet->setCellValue('H' . $row, $col['OF']);
            $sheet->setCellValue('I' . $row, $col['OM']);
            $row++;
        }
        $sheet->setTitle('HG_Members');

        $sheet = $spreadsheet->createSheet();
        $sheet->setTitle('Member_Incomes');
        $sheet->setCellValue('A1', 'Id'); 
        $sheet->setCellValue('B1', 'HG Name');
        $sheet->setCellValue('C1', 'Member Name');
        $sheet->setCellValue('D1', 'Income in FY 2074-75');
        $sheet->setCellValue('E1', 'Income in FY 2075-76');
        $sheet->setCellValue('F1', 'Income in FY 2076-77');
        $sheet->setCellValue('G1', 'Income in FY 2077-78');
        $sheet->setCellValue('H1', 'Income in FY 2078-79');
        
        $incomeData = $this->Repository_model->getHgMemberIncomes();
        $row=2;
        foreach ($incomeData as $col) {
            $sheet->setCellValue('A' . $row, $col['Id']); 
            $sheet->setCellValue('B' . $row, $col['Group_Name']);
            $sheet->setCellValue('C' . $row, $col['MemberName']);
            $sheet->setCellValue('D' . $row, $col['FY2074_75']);
            $sheet->setCellValue('E' . $row, $col['FY2075_76']);
            $sheet->setCellValue('F' . $row, $col['FY2076_77']);
            $sheet->setCellValue('G' . $row, $col['FY2077_78']);
            $sheet->setCellValue('H' . $row, $col['FY2078_79']);
            $row++;
        }

        
        $writer = new Xlsx($spreadsheet); // instantiate Xlsx 
        $filename = 'Homegarden_Data'; // set filename for excel file to be exported 
        header('Content-Type: application/vnd.ms-excel'); // generate excel file
        header('Content-Disposition: attachment;filename="'. $filename .'.xlsx"'); 
        header('Cache-Control: max-age=0');        
        $writer->save('php://output');	// download file
    }

    public function IG_Data() {
        $spreadsheet = new Spreadsheet(); // instantiate Spreadsheet
        $sheet = $spreadsheet->getActiveSheet();

        // manually set table data value
        $sheet->setCellValue('A1', 'District'); 
        $sheet->setCellValue('B1', 'R/MC');
        $sheet->setCellValue('C1', 'Ward Number');
        $sheet->setCellValue('D1', 'IG Info Type');
        $sheet->setCellValue('E1', 'Cluster Name');
        $sheet->setCellValue('F1', 'Group/Person Name');
        $sheet->setCellValue('G1', 'Code');
        $sheet->setCellValue('H1', 'Business Start Date');
        $sheet->setCellValue('I1', 'Form_Filled_Date');
        $sheet->setCellValue('J1', 'Business Type');
        $sheet->setCellValue('K1', 'IG Sector');
        $sheet->setCellValue('L1', 'Saving Fund');
        $sheet->setCellValue('M1', 'Fund Amount');
        $sheet->setCellValue('N1', 'Fund per person');
        $sheet->setCellValue('O1', 'Affiliated with Cooperative');
        $sheet->setCellValue('P1', 'Cooperative Name');
        $sheet->setCellValue('Q1', 'Loan from Cooperative');
        $sheet->setCellValue('R1', 'Group Registered');
        $sheet->setCellValue('S1', 'Registered To');
        $sheet->setCellValue('T1', 'Registration No');
        $sheet->setCellValue('U1', 'Registered Date');
        $sheet->setCellValue('V1', 'Scheme Code');
        $sheet->setCellValue('W1', 'Dalit Female');
        $sheet->setCellValue('X1', 'Dalit Male');
        $sheet->setCellValue('Y1', 'Janajati Female');
        $sheet->setCellValue('Z1', 'Janajati Male');
        $sheet->setCellValue('AA1', 'Other Female');
        $sheet->setCellValue('AB1', 'Other Male');
        $sheet->setCellValue('AC1', 'Other info if any');
         
        // get data from database and fed into excel file
        $data = $this->Repository_model->reportData('ig_info');
        $row=2;
        foreach ($data as $col) {
            $sheet->setCellValue('A' . $row, $col['District']); 
            $sheet->setCellValue('B' . $row, $col['RM']);
            $sheet->setCellValue('C' . $row, $col['Ward_No']);
            $sheet->setCellValue('D' . $row, $col['IG_Info_Type']);
            $sheet->setCellValue('E' . $row, $col['Cluster_Name']);
            $sheet->setCellValue('F' . $row, $col['Group_Person_Name']);
            $sheet->setCellValue('G' . $row, $col['Group_Person_Code']);
            $sheet->setCellValue('H' . $row, $col['Business_Start_Date']);
            $sheet->setCellValue('I' . $row, $col['Form_Filled_Date']);
            $sheet->setCellValue('J' . $row, $col['Business_Type']);
            $sheet->setCellValue('K' . $row, $col['IG_Sector']);
            $sheet->setCellValue('L' . $row, $col['Saving_Fund']);
            $sheet->setCellValue('M' . $row, $col['Fund_Amount']);
            $sheet->setCellValue('N' . $row, $col['Fund_Per_Person']);
            $sheet->setCellValue('O' . $row, $col['Coop_Affiliation']);
            $sheet->setCellValue('P' . $row, $col['Coop_Name']);
            $sheet->setCellValue('Q' . $row, $col['Loan_From_Coop']);
            $sheet->setCellValue('R' . $row, $col['Group_Registration']);
            $sheet->setCellValue('S' . $row, $col['Registered_To']);
            $sheet->setCellValue('T' . $row, $col['Registration_No']);
            $sheet->setCellValue('U' . $row, $col['Registered_Date']);
            $sheet->setCellValue('V' . $row, $col['Scheme_Code']);
            $sheet->setCellValue('W' . $row, $col['DF']);
            $sheet->setCellValue('X' . $row, $col['DM']);
            $sheet->setCellValue('Y' . $row, $col['JF']);
            $sheet->setCellValue('Z' . $row, $col['JM']);
            $sheet->setCellValue('AA' . $row, $col['OF']);
            $sheet->setCellValue('AB' . $row, $col['OM']);           
            $sheet->setCellValue('AC' . $row, $col['Others']);
            $row++;
        }
        $sheet->setTitle('IG Information');

        //Adding sheet for IG
        $sheet=$spreadsheet->createSheet();
        $sheet->setCellValue('A1', 'Id'); 
        $sheet->setCellValue('B1', 'Gruop Person Name');
        $sheet->setCellValue('C1', 'Member Name');
        $sheet->setCellValue('D1', 'Caste/Ethnicity');
        $sheet->setCellValue('E1', 'Female');
        $sheet->setCellValue('F1', 'Male');
        $sheet->setCellValue('G1', 'Income in 2074/075');
        $sheet->setCellValue('H1', 'Income in 2075/076');
        $sheet->setCellValue('I1', 'Income in 2076/077');
        $sheet->setCellValue('J1', 'Income in 2077/078');
        $sheet->setCellValue('K1', 'Income in 2078/079');

        $members = $this->Repository_model->getIgMembers();
        $row=2;
        foreach ($members as $col) {
            $sheet->setCellValue('A' . $row, $col['Id']); 
            $sheet->setCellValue('B' . $row, $col['Group_Person_Name']);
            $sheet->setCellValue('C' . $row, $col['MembersName']);
            $sheet->setCellValue('D' . $row, $col['CasteEthnicity']);
            $sheet->setCellValue('E' . $row, $col['Female']);
            $sheet->setCellValue('F' . $row, $col['Male']);
            $sheet->setCellValue('G' . $row, $col['FY_2074_2075']);
            $sheet->setCellValue('H' . $row, $col['FY_2075_2076']);
            $sheet->setCellValue('I' . $row, $col['FY_2076_2077']);
            $sheet->setCellValue('J' . $row, $col['FY_2077_2078']);
            $sheet->setCellValue('K' . $row, $col['FY_2078_2079']);
            $row++;
        }
        $sheet->setTitle('Member and Income');
        
        $writer = new Xlsx($spreadsheet); // instantiate Xlsx 
        $filename = 'Income Gen_Data'; // set filename for excel file to be exported 
        header('Content-Type: application/vnd.ms-excel'); // generate excel file
        header('Content-Disposition: attachment;filename="'. $filename .'.xlsx"'); 
        header('Cache-Control: max-age=0');        
        $writer->save('php://output');  // download file
    }

    public function getCoopDetail(){
        $this->load->model("Coop_model");
        $id = $this->uri->segment(3);
        $this->db->where('Id', $id);
        $coopDetail = $this->db->get('cooperative_information')->row();
        $spreadsheet = new Spreadsheet(); // instantiate Spreadsheet
        $sheet = $spreadsheet->getActiveSheet();

        $t = $this->Coop_model->getAffiliationDetail();

    }

    public function get_PolyhouseData(){
        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();
        $sheet->setTitle('Polyhouse Schemes');

        $sheet->setCellValue('A1', 'District'); 
        $sheet->setCellValue('B1', 'R/MC');
        $sheet->setCellValue('C1', 'Ward Number');
        $sheet->setCellValue('D1', 'Fiscal Year');
        $sheet->setCellValue('E1', 'Scheme Name');
        $sheet->setCellValue('F1', 'Scheme Code');
        $sheet->setCellValue('G1', 'Support Organization');
        $sheet->setCellValue('H1', 'Tunnel Type');
        $sheet->setCellValue('I1', 'No of Tunnels');
        $sheet->setCellValue('J1', 'Current Status');
        $sheet->setCellValue('K1', 'Scheme Start Date');
        $sheet->setCellValue('L1', 'Scheme Completed Date');
        $row =2;
        $data = $this->Repository_model->reportData('schememaster');
        foreach ($data as $col) {
            $sheet->setCellValue('A' . $row, $col['District']); 
            $sheet->setCellValue('B' . $row, $col['RM']);
            $sheet->setCellValue('C' . $row, $col['Ward_No']);
            $sheet->setCellValue('D' . $row, $col['FY']);
            $sheet->setCellValue('E' . $row, $col['Scheme_Name']);
            $sheet->setCellValue('F' . $row, $col['Scheme_Code']);
            $sheet->setCellValue('G' . $row, $col['Support_Org']);
            $sheet->setCellValue('H' . $row, $col['Tunnel_Type']);
            $sheet->setCellValue('I' . $row, $col['No_of_Tunnel']);
            $sheet->setCellValue('J' . $row, $col['Current_Status']);
            $sheet->setCellValue('K' . $row, $col['Scheme_Start_Date']);
            $sheet->setCellValue('L' . $row, $col['Scheme_Completed_Date']);

            $row++;
        }

        $sheet=$spreadsheet->createSheet();
        $sheet->setTitle('Beneficiaries');

        $sheet->setCellValue('A1', 'Scheme Code'); 
        $sheet->setCellValue('B1', 'HH Head Name');
        $sheet->setCellValue('C1', 'Tole / Cluster');
        $sheet->setCellValue('D1', 'Caste Ethnicity');
        $sheet->setCellValue('E1', 'Female');
        $sheet->setCellValue('F1', 'Male');
        $sheet->setCellValue('G1', 'Total Beneficiaries');
        $sheet->setCellValue('H1', 'Irrigated Land (Ropani)');
        $row=2;
        $bens = $this->Repository_model->reportData('beneficiary');
        foreach ($bens as $col) {
            $sheet->setCellValue('A' . $row, $col['Scheme_Code']); 
            $sheet->setCellValue('B' . $row, $col['HH_Head_Name']);
            $sheet->setCellValue('C' . $row, $col['Tole_Cluster']);
            $sheet->setCellValue('D' . $row, $col['Caste_Ethnicity']);
            $sheet->setCellValue('E' . $row, $col['Ben_Female']);
            $sheet->setCellValue('F' . $row, $col['Ben_Male']);
            $sheet->setCellValue('G' . $row, $col['Ben_Total']);
            $sheet->setCellValue('H' . $row, $col['IrrigatedLand']);
            $row++;
        }

        $sheet=$spreadsheet->createSheet();
        $sheet->setTitle('Cost Contribution');

        $sheet->setCellValue('A1', 'Scheme Code'); 
        $sheet->setCellValue('B1', 'Contributor');
        $sheet->setCellValue('C1', 'Contribution Estimated');
        $sheet->setCellValue('D1', 'Contribution Actual');
        $sheet->setCellValue('E1', 'Last Updated Date');
        $row=2;
        $bens = $this->Repository_model->reportData('cost_contribution');
        foreach ($bens as $col) {
            $sheet->setCellValue('A' . $row, $col['Scheme_Code']); 
            $sheet->setCellValue('B' . $row, $col['Contributor']);
            $sheet->setCellValue('C' . $row, $col['Contribution_Estimated']);
            $sheet->setCellValue('D' . $row, $col['Contribution_Actual']);
            $sheet->setCellValue('E' . $row, $col['Updated_Date']);
            $row++;
        }

        $sheet=$spreadsheet->createSheet();
        $sheet->setTitle('Item Cost');

        $sheet->setCellValue('A1', 'Scheme Code'); 
        $sheet->setCellValue('B1', 'Description');
        $sheet->setCellValue('C1', 'Estimated Cost');
        $sheet->setCellValue('D1', 'Actual Cost');
        $sheet->setCellValue('E1', 'Last Updated Date');
        $row=2;
        $bens = $this->Repository_model->reportData('item_cost');
        foreach ($bens as $col) {
            $sheet->setCellValue('A' . $row, $col['Scheme_Code']); 
            $sheet->setCellValue('B' . $row, $col['Description']);
            $sheet->setCellValue('C' . $row, $col['Estimated_Cost']);
            $sheet->setCellValue('D' . $row, $col['Actual_Cost']);
            $sheet->setCellValue('E' . $row, $col['Updated_Date']);
            $row++;
        }

        $writer = new Xlsx($spreadsheet); // instantiate Xlsx 
        $filename = 'Polyhose Scheme List'; // set filename for excel file to be exported 
        header('Content-Type: application/vnd.ms-excel'); // generate excel file
        header('Content-Disposition: attachment;filename="'. $filename .'.xlsx"'); 
        header('Cache-Control: max-age=0');        
        $writer->save('php://output');  // download file

    }

    public function get_AgriBusinessData(){
        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();
        $sheet->setTitle('Agribusiness Data');

        $sheet->setCellValue('A1', 'District'); 
        $sheet->setCellValue('B1', 'R/MC');
        $sheet->setCellValue('C1', 'Ward Number');
        $sheet->setCellValue('D1', 'Fiscal Year');
        $sheet->setCellValue('E1', 'Agri Business Name');
        $sheet->setCellValue('F1', 'Sub Sector');
        $sheet->setCellValue('G1', 'Business Type');
        $sheet->setCellValue('H1', 'Business Owner');
        $sheet->setCellValue('I1', 'Business Owner Nature');
        $sheet->setCellValue('J1', 'Business Preparation Plan');
        $sheet->setCellValue('K1', 'Support Organization');
        $sheet->setCellValue('L1', 'MoU Date');
        $sheet->setCellValue('M1', 'Linkage to Value Chain');
        $sheet->setCellValue('N1', 'Affiliation with Cooperative');
        $sheet->setCellValue('O1', 'Affiliated Cooperative Name');
        $sheet->setCellValue('P1', 'Business Covrage Population');
        $sheet->setCellValue('Q1', 'Completed Date');
        $sheet->setCellValue('R1', 'Current Status');

        $row =2;
        $data = $this->Repository_model->getAgriBusinessData('AGB');
        foreach ($data as $col) {
            $sheet->setCellValue('A' . $row, $col['District']); 
            $sheet->setCellValue('B' . $row, $col['RM']);
            $sheet->setCellValue('C' . $row, $col['WardNo']);
            $sheet->setCellValue('D' . $row, $col['FY']);
            $sheet->setCellValue('E' . $row, $col['AgriBusinessName']);
            $sheet->setCellValue('F' . $row, $col['SubSector']);
            $sheet->setCellValue('G' . $row, $col['BusinessType']);
            $sheet->setCellValue('H' . $row, $col['Owner']);
            $sheet->setCellValue('I' . $row, $col['OwnerNature']);
            $sheet->setCellValue('J' . $row, $col['BusinessPlanPreparation']);
            $sheet->setCellValue('K' . $row, $col['SupportOrg']);
            $sheet->setCellValue('L' . $row, $col['MoUDate']);
            $sheet->setCellValue('M' . $row, $col['LinkToValueChain']);
            $sheet->setCellValue('N' . $row, $col['AffiliationWithCoops']);
            $sheet->setCellValue('O' . $row, $col['AffiliatedCoopName']);
            $sheet->setCellValue('P' . $row, $col['CoveragePop']);
            $sheet->setCellValue('Q' . $row, $col['CompletedDate']);
            $sheet->setCellValue('R' . $row, $col['CurrentStatus']);

            $row++;
        }

        $sheet=$spreadsheet->createSheet();
        $sheet->setTitle('Beneficiaries');

        $sheet->setCellValue('A1', 'Business Name'); 
        $sheet->setCellValue('B1', 'HH Head Name');
        $sheet->setCellValue('C1', 'Tole / Cluster');
        $sheet->setCellValue('D1', 'Caste Ethnicity');
        $sheet->setCellValue('E1', 'Female');
        $sheet->setCellValue('F1', 'Male');
        $sheet->setCellValue('G1', 'Total Beneficiaries');
        $row=2;
        $bens = $this->Repository_model->getAgriBusinessBeneficies('AGB');
        foreach ($bens as $col) {
            $sheet->setCellValue('A' . $row, $col['AgriBusinessName']); 
            $sheet->setCellValue('B' . $row, $col['HH_Head_Name']);
            $sheet->setCellValue('C' . $row, $col['Tole_Cluster']);
            $sheet->setCellValue('D' . $row, $col['Caste_Ethnicity']);
            $sheet->setCellValue('E' . $row, $col['Ben_Female']);
            $sheet->setCellValue('F' . $row, $col['Ben_Male']);
            $sheet->setCellValue('G' . $row, $col['Ben_Total']);
            $row++;
        }

        $sheet=$spreadsheet->createSheet();
        $sheet->setTitle('Cost Contribution');

        $sheet->setCellValue('A1', 'Business Name'); 
        $sheet->setCellValue('B1', 'Contributor');
        $sheet->setCellValue('C1', 'Contribution Estimated');
        $sheet->setCellValue('D1', 'Contribution Actual');
        $sheet->setCellValue('E1', 'Last Updated Date');
        $row=2;
        $bens = $this->Repository_model->getAgriBusinessCostContribution('AGB');
        foreach ($bens as $col) {
            $sheet->setCellValue('A' . $row, $col['AgriBusinessName']); 
            $sheet->setCellValue('B' . $row, $col['Contributor']);
            $sheet->setCellValue('C' . $row, $col['Contribution_Estimated']);
            $sheet->setCellValue('D' . $row, $col['Contribution_Actual']);
            $sheet->setCellValue('E' . $row, $col['Updated_Date']);
            $row++;
        }

        $sheet=$spreadsheet->createSheet();
        $sheet->setTitle('Item Cost');

        $sheet->setCellValue('A1', 'Business Name'); 
        $sheet->setCellValue('B1', 'Description');
        $sheet->setCellValue('C1', 'Estimated Cost');
        $sheet->setCellValue('D1', 'Actual Cost');
        $sheet->setCellValue('E1', 'Last Updated Date');
        $row=2;
        $bens = $this->Repository_model->getAgriBusinessItemCost('AGB');
        foreach ($bens as $col) {
            $sheet->setCellValue('A' . $row, $col['AgriBusinessName']); 
            $sheet->setCellValue('B' . $row, $col['Description']);
            $sheet->setCellValue('C' . $row, $col['Estimated_Cost']);
            $sheet->setCellValue('D' . $row, $col['Actual_Cost']);
            $sheet->setCellValue('E' . $row, $col['Updated_Date']);
            $row++;
        }

        $sheet=$spreadsheet->createSheet();
        $sheet->setTitle('Management Committee');

        $sheet->setCellValue('A1', 'Business Name'); 
        $sheet->setCellValue('B1', 'Position');
        $sheet->setCellValue('C1', 'Ethnicity');
        $sheet->setCellValue('D1', 'Gender');
        $sheet->setCellValue('E1', 'Name of Member');
        $sheet->setCellValue('E1', 'Representative of');
        $row=2;
        $bens = $this->Repository_model->getAgriBusinessMgmtCommittee('AGB');
        foreach ($bens as $col) {
            $sheet->setCellValue('A' . $row, $col['AgriBusinessName']); 
            $sheet->setCellValue('B' . $row, $col['Position']);
            $sheet->setCellValue('C' . $row, $col['Ethnicity']);
            $sheet->setCellValue('D' . $row, $col['Gender']);
            $sheet->setCellValue('E' . $row, $col['NumberOfMember']);
            $sheet->setCellValue('E' . $row, $col['RepresentativeOf']);
            $row++;
        }

        $writer = new Xlsx($spreadsheet); // instantiate Xlsx 
        $filename = 'Agribusiness Data'; // set filename for excel file to be exported 
        header('Content-Type: application/vnd.ms-excel'); // generate excel file
        header('Content-Disposition: attachment;filename="'. $filename .'.xlsx"'); 
        header('Cache-Control: max-age=0');        
        $writer->save('php://output');  // download file

    }

    public function get_CollectionCenterData(){
        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();
        $sheet->setTitle('Collection Center Data');

        $sheet->setCellValue('A1', 'District'); 
        $sheet->setCellValue('B1', 'R/MC');
        $sheet->setCellValue('C1', 'Ward Number');
        $sheet->setCellValue('D1', 'Fiscal Year');
        $sheet->setCellValue('E1', 'Agri Business Name');
        $sheet->setCellValue('F1', 'Sub Sector');
        $sheet->setCellValue('G1', 'Business Type');
        $sheet->setCellValue('H1', 'Business Owner');
        $sheet->setCellValue('I1', 'Business Owner Nature');
        $sheet->setCellValue('J1', 'Business Preparation Plan');
        $sheet->setCellValue('K1', 'Support Organization');
        $sheet->setCellValue('L1', 'MoU Date');
        $sheet->setCellValue('M1', 'Linkage to Value Chain');
        $sheet->setCellValue('N1', 'Affiliation with Cooperative');
        $sheet->setCellValue('O1', 'Affiliated Cooperative Name');
        $sheet->setCellValue('P1', 'Business Covrage Population');
        $sheet->setCellValue('Q1', 'Completed Date');
        $sheet->setCellValue('R1', 'Current Status');

        $row =2;
        $data = $this->Repository_model->getAgriBusinessData('CC');
        foreach ($data as $col) {
            $sheet->setCellValue('A' . $row, $col['District']); 
            $sheet->setCellValue('B' . $row, $col['RM']);
            $sheet->setCellValue('C' . $row, $col['WardNo']);
            $sheet->setCellValue('D' . $row, $col['FY']);
            $sheet->setCellValue('E' . $row, $col['AgriBusinessName']);
            $sheet->setCellValue('F' . $row, $col['SubSector']);
            $sheet->setCellValue('G' . $row, $col['BusinessType']);
            $sheet->setCellValue('H' . $row, $col['Owner']);
            $sheet->setCellValue('I' . $row, $col['OwnerNature']);
            $sheet->setCellValue('J' . $row, $col['BusinessPlanPreparation']);
            $sheet->setCellValue('K' . $row, $col['SupportOrg']);
            $sheet->setCellValue('L' . $row, $col['MoUDate']);
            $sheet->setCellValue('M' . $row, $col['LinkToValueChain']);
            $sheet->setCellValue('N' . $row, $col['AffiliationWithCoops']);
            $sheet->setCellValue('O' . $row, $col['AffiliatedCoopName']);
            $sheet->setCellValue('P' . $row, $col['CoveragePop']);
            $sheet->setCellValue('Q' . $row, $col['CompletedDate']);
            $sheet->setCellValue('R' . $row, $col['CurrentStatus']);

            $row++;
        }

        $sheet=$spreadsheet->createSheet();
        $sheet->setTitle('Beneficiaries');

        $sheet->setCellValue('A1', 'Business Name'); 
        $sheet->setCellValue('B1', 'HH Head Name');
        $sheet->setCellValue('C1', 'Tole / Cluster');
        $sheet->setCellValue('D1', 'Caste Ethnicity');
        $sheet->setCellValue('E1', 'Female');
        $sheet->setCellValue('F1', 'Male');
        $sheet->setCellValue('G1', 'Total Beneficiaries');
        $row=2;
        $bens = $this->Repository_model->getAgriBusinessBeneficies('CC');
        foreach ($bens as $col) {
            $sheet->setCellValue('A' . $row, $col['AgriBusinessName']); 
            $sheet->setCellValue('B' . $row, $col['HH_Head_Name']);
            $sheet->setCellValue('C' . $row, $col['Tole_Cluster']);
            $sheet->setCellValue('D' . $row, $col['Caste_Ethnicity']);
            $sheet->setCellValue('E' . $row, $col['Ben_Female']);
            $sheet->setCellValue('F' . $row, $col['Ben_Male']);
            $sheet->setCellValue('G' . $row, $col['Ben_Total']);
            $row++;
        }

        $sheet=$spreadsheet->createSheet();
        $sheet->setTitle('Cost Contribution');

        $sheet->setCellValue('A1', 'Business Name'); 
        $sheet->setCellValue('B1', 'Contributor');
        $sheet->setCellValue('C1', 'Contribution Estimated');
        $sheet->setCellValue('D1', 'Contribution Actual');
        $sheet->setCellValue('E1', 'Last Updated Date');
        $row=2;
        $bens = $this->Repository_model->getAgriBusinessCostContribution('CC');
        foreach ($bens as $col) {
            $sheet->setCellValue('A' . $row, $col['AgriBusinessName']); 
            $sheet->setCellValue('B' . $row, $col['Contributor']);
            $sheet->setCellValue('C' . $row, $col['Contribution_Estimated']);
            $sheet->setCellValue('D' . $row, $col['Contribution_Actual']);
            $sheet->setCellValue('E' . $row, $col['Updated_Date']);
            $row++;
        }

        $sheet=$spreadsheet->createSheet();
        $sheet->setTitle('Item Cost');

        $sheet->setCellValue('A1', 'Business Name'); 
        $sheet->setCellValue('B1', 'Description');
        $sheet->setCellValue('C1', 'Estimated Cost');
        $sheet->setCellValue('D1', 'Actual Cost');
        $sheet->setCellValue('E1', 'Last Updated Date');
        $row=2;
        $bens = $this->Repository_model->getAgriBusinessItemCost('CC');
        foreach ($bens as $col) {
            $sheet->setCellValue('A' . $row, $col['AgriBusinessName']); 
            $sheet->setCellValue('B' . $row, $col['Description']);
            $sheet->setCellValue('C' . $row, $col['Estimated_Cost']);
            $sheet->setCellValue('D' . $row, $col['Actual_Cost']);
            $sheet->setCellValue('E' . $row, $col['Updated_Date']);
            $row++;
        }

        $sheet=$spreadsheet->createSheet();
        $sheet->setTitle('Management Committee');

        $sheet->setCellValue('A1', 'Business Name'); 
        $sheet->setCellValue('B1', 'Position');
        $sheet->setCellValue('C1', 'Ethnicity');
        $sheet->setCellValue('D1', 'Gender');
        $sheet->setCellValue('E1', 'Name of Member');
        $sheet->setCellValue('E1', 'Representative of');
        $row=2;
        $bens = $this->Repository_model->getAgriBusinessMgmtCommittee('CC');
        foreach ($bens as $col) {
            $sheet->setCellValue('A' . $row, $col['AgriBusinessName']); 
            $sheet->setCellValue('B' . $row, $col['Position']);
            $sheet->setCellValue('C' . $row, $col['Ethnicity']);
            $sheet->setCellValue('D' . $row, $col['Gender']);
            $sheet->setCellValue('E' . $row, $col['NumberOfMember']);
            $sheet->setCellValue('E' . $row, $col['RepresentativeOf']);
            $row++;
        }

        $writer = new Xlsx($spreadsheet); // instantiate Xlsx 
        $filename = 'Collection Center Data'; // set filename for excel file to be exported 
        header('Content-Type: application/vnd.ms-excel'); // generate excel file
        header('Content-Disposition: attachment;filename="'. $filename .'.xlsx"'); 
        header('Cache-Control: max-age=0');        
        $writer->save('php://output');  // download file

    }

} 