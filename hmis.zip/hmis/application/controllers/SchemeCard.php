<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * 
 */
class SchemeCard extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();
		$this->load->model('Repository_model');
		if (! $this->session->userdata('loginId')) {
			redirect('Login');
		}
	}

	function index(){
		$tr = "";
		$list = $this->Repository_model->getAll_Data('schememaster');
		foreach ($list as $s) {
			$tr .='<tr>
				<td width="90">
				<a href="'.base_url("SchemeCard/getSchemeData/".$s->Id).'"><span class="btn btn-primary btn-sm"> Update Info</span>
				</a>
				</td>
				<td width="70">'. $s->District .'</td>
				<td width="120">'. $s->RM .'</td>
				<td width="30">'. $s->Ward_No .'</td>
				<td width="30">'. $s->FY .'</td>
				<td width="200">'. $s->Scheme_Name .'</td>
				<td width="80">'. $s->Scheme_Code .'</td>
				<td width="150">'. $s->Support_Org .'</td>
				<td width="100">'. $s->Tunnel_Type .'</td>
				<td width="80">'. $s->No_of_Tunnel .'</td>
				<td width="100">'. $s->Current_Status .'</td>
				<td width="120">'. $s->Scheme_Start_Date .'</td>
				<td width="120">'. $s->Scheme_Completed_Date .'</td>';
				$tr.='<td width="100">
					<a onclick="getById('.$s->Id.')" href="#" class="btn btn-success btn-sm" title="Edit"> <span class="fa fa-pencil"></span></a>
					<a href="javascript:void(0)" onclick="deleteScheme('.$s->Id.', this)" class="btn btn-danger btn-sm"><span class="fa fa-trash"></span></a>
					</td>';
				$tr.="</tr>";
				}
		$data['schemeList'] = $tr;


		$data['page_title'] = 'HMIS: Scheme Information';
		$this->load->view('includes/header', $data);
		$this->load->view('scheme/index', $data);
		$this->load->view('includes/footer');
	}

	function deleteScheme(){
		$id = $this->input->post('id');
		$res = $this->Repository_model->deleteInfo('schememaster',$id);
		if ($res==1) {
			echo 'deleted';
		}else{
			echo $res;
		}
	}

	function getRMs()
    {
    	$this->load->model('Dropdownvalue_model');
    	$district = $this->input->post('district');
    	$rmc = $this->input->post('rm');
    	$rms = $this->Dropdownvalue_model->getRM($district);
    	$output = '<option> -- Select RM -- </option>';
    	foreach ($rms as $rm) {
    		if ($rmc) {
    			if ($rm->RM == $rmc) {
    				$output .='<option selected>'.$rm->RM.'</option>';
    			}else{
	    			$output .='<option>'.$rm->RM.'</option>';
	    		}
    		}
    		else{
    			$output .='<option>'.$rm->RM.'</option>';
    		}
    	}
    	echo $output;
    }

    function getCode(){
    	$rmc = $this->input->post('rm');
    	//$rmc = 'Chaurpati';
    	$rmc_code = $this->Repository_model->getCode($rmc);
    	$sList = $this->Repository_model->getSchemeListInRM($rmc);
    	$temp = 0;
    	$max = 0;
    	if ($sList->num_rows()>0) {
    		foreach ($sList->result() as $sl) {
    			$temp = substr($sl->Scheme_Code, 7);
    			if ($temp>$max) {
    				$max = (int)$temp;
    			}
    		}
    		if ($max<10)
    			echo $rmc_code.'PH0'.(((int)$max) + 1);
    		else
    			echo $rmc_code.'PH'.((int)$max);
    	}else{
    		echo $rmc_code.'PH'.'01';
    	}
    }

    function saveSchemeData(){
    	$id = $this->input->post('id');

    	$data = array(
    		"District"=>$this->input->post("district"),
    		"RM"=>$this->input->post("rmc"),
    		"Ward_No"=>$this->input->post("ward"),
    		"FY"=>$this->input->post("FY"),
    		"Scheme_Name"=>$this->input->post("Scheme_Name"),
    		"Scheme_Code"=>$this->input->post("Scheme_Code"),
    		"Support_Org"=>$this->input->post("Support_Org"),
    		"Tunnel_Type"=>$this->input->post("Tunnel_Type"),
    		"No_of_Tunnel"=>$this->input->post("No_of_Tunnel"),
    		"Current_Status"=>$this->input->post("Current_Status"),
    		"Scheme_Start_Date"=>$this->input->post("Scheme_Start_Date"),
    		"Added_By"=>$this->session->userdata('loginName'),
    		"Added_Date"=>date("d-m-Y h:m:sa")
    	);
    	$saved = $this->Repository_model->save('schememaster', $id, $data);
    	if ($saved>0) {
    		$this->session->set_flashdata('success', 'Saved');
    		redirect('SchemeCard');
    	}else{
    		$this->session->set_flashdata('success', 'Error');
    		redirect('SchemeCard');
    	}
    }

	function getSchemeData(){
		$id = $this->uri->segment('3');		
		$data['page_title'] = 'HMIS: Scheme Information';
		$this->load->view('includes/header', $data);
		$schemeinfo=$this->Repository_model->getById($id,'schememaster');
		foreach ($schemeinfo as $s) {
			$data['Id']=$s->Id;
			$data['schemename']=$s->Scheme_Name;
			$data['schemecode']=$s->Scheme_Code;
			$data['currentstatus']=$s->Current_Status;
		}
		$this->load->view('scheme/scheme-update', $data);
		$this->load->view('includes/footer');
	}

	function updateSchemeStatus(){
		$id = $this->input->post('id');
		$data = array(
			'Current_Status' => $this->input->post('status'),
			'Scheme_Completed_Date' => $this->input->post('cdate'),
			'Updated_By' => $this->session->userdata('loginName'),
			'Updated_Date' => date("d-m-Y h:m:sa")
		);

		
		$success = $this->Repository_model->updateSchemeData('schememaster', $id, $data);
		
		if($success==1){
			echo "Saved Successfully";
		}else if($success==0){
			echo "No Change";
		}else{
			echo $success;
		}
	}

	function getSchemeById(){
		$id = $this->input->post('id');
		$schemeinfo=$this->Repository_model->getDataById($id,'schememaster');
		echo json_encode($schemeinfo);
	}
}