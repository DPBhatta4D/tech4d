<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * 
 */
class Sustainability extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();
		$this->load->library('encrypt');
		$this->load->model('Sustainability_model');
		if (! $this->session->userdata('loginId')) {
			redirect('Login');
		}
	}
	function index(){
		$data['page_title']= 'APRS: Scheme Sustainability';
		$this->load->view('includes/header', $data);
		$tr='';
		$urlText ='';
		$rn=1;
		$mus_schemes = $this->Sustainability_model->getSchemeList('MUS');
		foreach ($mus_schemes->result() as $scheme) {			
			$sus_Data = $this->Sustainability_model->getSustainData($scheme->Scheme_Code, 'MUS');
			if (isset($sus_Data)) {
				$date1=date_create($sus_Data->data_collected_date);
				$date2=date_create(date("Y-m-d"));
				$diff=date_diff($date1,$date2);
				$days = $diff->format("%a");
				if ($days<=180) {
					$tr.='<tr><td width="40">'.$rn.'</td>';
					$tr .='<td width="100">'.$scheme->District.'</td>';
					$tr .='<td width="250">'.$scheme->Scheme_Name.'</td>';
					$tr.='<td width="120">'.$scheme->Scheme_Code.'</td>';			
					$tr.='<td  width="140">'.$sus_Data->type_technology.'</td>';
					$tr.='<td  width="100">'.$sus_Data->type_ownership.'</td>';
					$tr.='<td width="120">'.$sus_Data->completion_testing_commissioning_date.'</td>';
					$tr.='<td width="100">'.$sus_Data->functional_status.'</td>';
					$tr.='<td width="150">'.$sus_Data->SWM_VMW_caretaker_operator_appointment_mobilization.'</td>';
					$tr.='<td width="150">'.$sus_Data->SWM_VMW_caretaker_operator_remuneration.'</td>';
					$tr.='<td width="110">'.$sus_Data->implementation_OM_regulation.'</td>';
					$tr.='<td width="110">'.$sus_Data->implementation_WSP.'</td>';
					$tr.='<td width="110">'.$sus_Data->reviewing_OM_WSP.'</td>';
					$tr.='<td width="110">'.$sus_Data->management_spare_parts_tools.'</td>';
					$tr.='<td width="160">'.$sus_Data->existence_OM_regular_tariff.'</td>';
					$tr.='<td width="95">'.$sus_Data->mode_tariff.'</td>';
					$tr.='<td width="85">'.$sus_Data->tariff_rate_per_month.'</td>';
					$tr.='<td width="95">'.$sus_Data->annual_repair_maintenance_cost.'</td>';
					$tr.='<td width="85">'.$sus_Data->OM_locally_mobilized.'</td>';
					$tr.='<td width="85">'.$sus_Data->OM_cash.'</td>';
					$tr.='<td width="85">'.$sus_Data->OM_bank.'</td>';
					$tr.='<td width="85">'.$sus_Data->OM_cooperative.'</td>';
					$tr.='<td width="100">'.$sus_Data->affiliation_coop.'</td>';
					$tr.='<td width="110">'.$sus_Data->UC_registration_renewing.'</td>';
					$tr.='<td width="80">'.$sus_Data->UC_regular_meeting.'</td>';
					$tr.='<td width="100">'.$sus_Data->UC_fulfilled_members.'</td>';
					$tr.='<td width="110">'.$sus_Data->PA_general_assembly_reporting_RM.'</td>';
					$tr.='<td width="110">'.$sus_Data->book_keeping_documentation.'</td>';
					$tr.='<td width="85">'.$sus_Data->QARQ_quantity.'</td>';
					$tr.='<td width="90">'.$sus_Data->QARQ_accessibility.'</td>';
					$tr.='<td width="85">'.$sus_Data->QARQ_reliability.'</td>';
					$tr.='<td width="85">'.$sus_Data->QARQ_quality.'</td>';
					$tr.='<td width="85">'.$sus_Data->QARQ_overall_status.'</td>';
					$tr.='<td width="130">'.$sus_Data->maximum_energy_produced.'</td>';
					$tr.='<td width="110">'.$sus_Data->energy_utilized.'</td>';
					$tr.='<td width="110">'.$sus_Data->utilization_energy_produced.'</td>';
					$tr.='<td width="110">'.$sus_Data->maintaining_log_book.'</td>';
					$tr.='<td width="130">'.$sus_Data->service_contract_with_company.'</td>';
					$tr.='<td width="110">'.$sus_Data->no_shareholders.'</td>';
					$tr.='<td width="110">'.$sus_Data->share_capital.'</td>';
					$tr.='<td width="110">'.$sus_Data->no_enduse_promotion_activities.'</td>';
					$tr.='<td width="110">'.$sus_Data->total_energy_consumed_enduse.'</td>';
					$tr.='<td width="110">'.$sus_Data->measurement_water_flow.'</td>';
					$tr.='<td width="100">'.$sus_Data->maintaining_service_level.'</td>';
					$tr.='<td width="100">'.$sus_Data->Remarks.'</td>';
				}
				else
				{
					$tr.='<tr style="background-color: #ff9d5a; color: white;">
					<td width="40">'.$rn.'</td>';
					$tr .='<td width="100">'.$scheme->District.'</td>';				
					$tr .='<td width="250"><a href="'.base_url().'Sustainability/add_mus/'.rawurlencode($scheme->Scheme_Name).'/'.$scheme->Scheme_Code.'/'.rawurlencode($scheme->Scheme_type).'">'.$scheme->Scheme_Name.'</a></td>';
					$tr.='<td width="120">'.$scheme->Scheme_Code.'</td>';
					$tr.='<td colspan="27">Data validity expired. Please re-enter sustainability information. Click on scheme name to get entry form.</td>';
				}
			}
			else
			{
				$tr.='<tr style="background-color: #ff9d5a; color: white;">
				<td width="40">'.$rn.'</td>';
				$tr .='<td width="100">'.$scheme->District.'</td>';				
				$tr .='<td width="250"><a href="'.base_url().'Sustainability/add_mus/'.rawurlencode($scheme->Scheme_Name).'/'.$scheme->Scheme_Code.'/'.rawurlencode($scheme->Scheme_type).'">'.$scheme->Scheme_Name.'</a></td>';
				$tr.='<td width="120">'.$scheme->Scheme_Code.'</td>';
				$tr.='<td colspan="27"> Sustainability information not found !! Click on scheme name to get entry form.</td>';
			}		
			$tr.='<td width="100"></td></tr>';
			$rn++;
		}
		$data['mustableRow'] = $tr;
		//==================Water Supply Schemes====================
		$ws_schemes = $this->Sustainability_model->getSchemeList('WATER SUPPLY');
		$tr='';
		$rn=1;
		foreach ($ws_schemes->result() as $scheme) {			
			$sus_Data = $this->Sustainability_model->getSustainData($scheme->Scheme_Code, 'WS');
			if (isset($sus_Data)) {
				$date1=date_create($sus_Data->data_collected_date);
				$date2=date_create(date("Y-m-d"));
				$diff=date_diff($date1,$date2);
				$days = $diff->format("%a");
				if ($days<=180) {
					$tr.='<tr><td width="40">'.$rn.'</td>';
					$tr .='<td width="100">'.$scheme->District.'</td>';
					$tr .='<td width="250">'.$scheme->Scheme_Name.'</td>';
					$tr.='<td width="120">'.$scheme->Scheme_Code.'</td>';			
					$tr.='<td  width="140">'.$sus_Data->functional_status.'</td>';
					$tr.='<td  width="160">'.$sus_Data->SMW_VMW_app_mobl.'</td>';
					$tr.='<td width="160">'.$sus_Data->SMW_VMW_remuneration.'</td>';
					$tr.='<td width="160">'.$sus_Data->Impl_OM_regulation.'</td>';
					$tr.='<td width="160">'.$sus_Data->Impl_WSP.'</td>';
					$tr.='<td width="160">'.$sus_Data->Reviewing_annual_OM_plan_WSP.'</td>';
					$tr.='<td width="160">'.$sus_Data->Manage_spare_parts_tools.'</td>';
					$tr.='<td width="160">'.$sus_Data->Existence_OM_regular_WT.'</td>';
					$tr.='<td width="110">'.$sus_Data->Mode_WT.'</td>';
					$tr.='<td width="160">'.$sus_Data->WT_per_month.'</td>';
					$tr.='<td width="160">'.$sus_Data->Annual_repair_maintain.'</td>';
					$tr.='<td width="85">'.$sus_Data->OM_locally_mobilized.'</td>';
					$tr.='<td width="85">'.$sus_Data->OM_cash.'</td>';
					$tr.='<td width="85">'.$sus_Data->OM_Bank.'</td>';
					$tr.='<td width="85">'.$sus_Data->OM_coop.'</td>';
					$tr.='<td width="130">'.$sus_Data->Affiliation_coop.'</td>';
					$tr.='<td width="130">'.$sus_Data->UC_registration_renewing.'</td>';
					$tr.='<td width="60">'.$sus_Data->UC_regular_meeting.'</td>';
					$tr.='<td width="130">'.$sus_Data->UC_fulfilled_members.'</td>';
					$tr.='<td width="170">'.$sus_Data->Annual_general_assembly_reporting_RM.'</td>';
					$tr.='<td width="110">'.$sus_Data->Book_keeping_documentation.'</td>';
					$tr.='<td width="85">'.$sus_Data->QARQ_Quantity.'</td>';
					$tr.='<td width="90">'.$sus_Data->QARQ_Accessibility.'</td>';
					$tr.='<td width="85">'.$sus_Data->QARQ_Reliability.'</td>';
					$tr.='<td width="85">'.$sus_Data->QARQ_Quality.'</td>';
					$tr.='<td width="85">'.$sus_Data->QARQ_Overall_Status.'</td>';
					$tr.='<td width="100">'.$sus_Data->Remarks.'</td>';
				}else{
					$tr.='<tr style="background-color: #ff9d5a; color: white;">
					<td width="40">'.$rn.'</td>';
					$tr .='<td width="100">'.$scheme->District.'</td>';				
					$tr .='<td width="250"><a href="'.base_url().'Sustainability/add_ws/'.rawurlencode($scheme->Scheme_Name).'/'.$scheme->Scheme_Code.'">'.$scheme->Scheme_Name.'</a></td>';
					$tr.='<td width="120">'.$scheme->Scheme_Code.'</td>';
					$tr.='<td colspan="27">Data validity expired. Please re-enter sustainability information. Click on scheme name to get entry form.</td>';
				}
			}
			else
			{
				$tr.='<tr style="background-color: #ff9d5a; color: white;">
				<td width="40">'.$rn.'</td>';
				$tr .='<td width="100">'.$scheme->District.'</td>';				
				$tr .='<td width="250"><a href="'.base_url().'Sustainability/add_ws/'.rawurlencode($scheme->Scheme_Name).'/'.$scheme->Scheme_Code.'">'.$scheme->Scheme_Name.'</a></td>';
				$tr.='<td width="120">'.$scheme->Scheme_Code.'</td>';
				$tr.='<td colspan="27"> Sustainability information not found !! Click on scheme name to get entry form.</td>';
			}		
			$tr.='<td width="100"></td></tr>';
			$rn++;
		}
		$data['wstableRow'] = $tr;
		//=================Irrigation Scheme=======================
		$ws_schemes = $this->Sustainability_model->getSchemeList('IRRIGATION');
		$tr='';
		$rn=1;
		foreach ($ws_schemes->result() as $scheme) {			
			$sus_Data = $this->Sustainability_model->getSustainData($scheme->Scheme_Code, 'Irrigation');
			if (isset($sus_Data)) {
				$date1=date_create($sus_Data->data_collected_date);
				$date2=date_create(date("Y-m-d"));
				$diff=date_diff($date1,$date2);
				$days = $diff->format("%a");
				if ($days<=180) {
					$tr.='<tr><td width="40">'.$rn.'</td>';
					$tr .='<td width="100">'.$scheme->District.'</td>';
					$tr .='<td width="250">'.$scheme->Scheme_Name.'</td>';
					$tr.='<td width="120">'.$scheme->Scheme_Code.'</td>';			
					$tr.='<td  width="140">'.$sus_Data->functional_status.'</td>';
					$tr.='<td  width="150">'.$sus_Data->care_taker_management_mobilization.'</td>';
					$tr.='<td width="150">'.$sus_Data->care_taker_remuneration.'</td>';
					$tr.='<td width="110">'.$sus_Data->Impl_OM_regulation.'</td>';
					$tr.='<td width="160">'.$sus_Data->Existenxe_OM_regular_IT_collection.'</td>';
					$tr.='<td width="95">'.$sus_Data->Mode_IT.'</td>';
					$tr.='<td width="85">'.$sus_Data->IT_rate_per_month.'</td>';
					$tr.='<td width="95">'.$sus_Data->Annual_repair_maintain.'</td>';
					$tr.='<td width="85">'.$sus_Data->OM_locally_mobilized.'</td>';
					$tr.='<td width="85">'.$sus_Data->OM_cash.'</td>';
					$tr.='<td width="85">'.$sus_Data->OM_Bank.'</td>';
					$tr.='<td width="85">'.$sus_Data->OM_coop.'</td>';
					$tr.='<td width="100">'.$sus_Data->Affiliation_coop.'</td>';
					$tr.='<td width="110">'.$sus_Data->UC_registration_renewing.'</td>';
					$tr.='<td width="80">'.$sus_Data->UC_regular_meeting.'</td>';
					$tr.='<td width="100">'.$sus_Data->UC_fulfilled_members.'</td>';
					$tr.='<td width="110">'.$sus_Data->Annual_general_assembly_reporting_RM.'</td>';
					$tr.='<td width="110">'.$sus_Data->Book_keeping_documentation.'</td>';
					$tr.='<td width="100">'.$sus_Data->Remarks.'</td>';

				}else{
					$tr.='<tr style="background-color: #ff9d5a; color: white;">
					<td width="40">'.$rn.'</td>';
					$tr .='<td width="100">'.$scheme->District.'</td>';				
					$tr .='<td width="250"><a href="'.base_url().'Sustainability/add_irrigation/'.rawurlencode($scheme->Scheme_Name).'/'.$scheme->Scheme_Code.'/'.$scheme->Scheme_type.'">'.$scheme->Scheme_Name.'</a></td>';
					$tr.='<td width="120">'.$scheme->Scheme_Code.'</td>';
					$tr.='<td colspan="19">Data validity expired. Please re-enter sustainability information. Click on scheme name to get entry form.</td>';
				}
			}
			else
			{
				$tr.='<tr style="background-color: #ff9d5a; color: white;">
				<td width="40">'.$rn.'</td>';
				$tr .='<td width="100">'.$scheme->District.'</td>';				
				$tr .='<td width="250"><a href="'.base_url().'Sustainability/add_irrigation/'. rawurlencode($scheme->Scheme_Name).'/'.$scheme->Scheme_Code.'/'.$scheme->Scheme_type.'">'.$scheme->Scheme_Name.'</a></td>';
				$tr.='<td width="120">'.$scheme->Scheme_Code.'</td>';
				$tr.='<td colspan="19"> Sustainability information not found !! Click on scheme name to get entry form.</td>';
			}		
			$tr.='<td width="100"></td></tr>';
			$rn++;
		}
		$data['irrTableRow'] = $tr;
		//=================IWM Schemes=============================

		//=================MHP Schemes=============================
		$this->load->view('sustainability/index', $data);
		$this->load->view('includes/footer');
	}
	function add_ws(){
		$data['page_title']= 'Sustainability Info';
		$this->load->view('includes/header', $data);

		$data['schemeName']=urldecode($this->uri->segment(3));
		$data['schemeCode']=urldecode($this->uri->segment(4));
		$this->load->view('sustainability/add_ws', $data);
		$this->load->view('includes/footer');
	}

	function add_irrigation(){
		$data['page_title']= 'Sustainability Info';
		$this->load->view('includes/header', $data);

		$data['schemeName']=urldecode($this->uri->segment(3));
		$data['schemeCode']=urldecode($this->uri->segment(4));
		$data['schemeType']=urldecode($this->uri->segment(5));
		$this->load->view('sustainability/add_irrigation', $data);
		$this->load->view('includes/footer');
	}

	function add_mus(){
		$data['page_title']= 'Sustainability Info';
		$this->load->view('includes/header', $data);
		$data['schemeName']=urldecode($this->uri->segment(3));
		$data['schemeCode']=urldecode($this->uri->segment(4));
		$data['schemeType']= urldecode($this->uri->segment(5));
		
		$this->load->view('sustainability/add_mus', $data);
		$this->load->view('includes/footer');
	}

	function saveData(){
		$schemeType = $this->input->post('schemetype');
		// echo $schemeType;die();
		// $msg="";
		if ($schemeType=="WS") {
			$msg = $this->Sustainability_model->save_ws();
		} elseif ($schemeType=='MUS') {
			$msg = $this->Sustainability_model->save_mus();
		}elseif ($schemeType=='IRRIGATION') {
			$msg = $this->Sustainability_model->save_irr();
		}
		if ($msg==1) {
			$data['page_title']= 'Sustainability Info';
			$this->load->view('includes/header', $data);
			$this->load->view('sustainability/success_msg');
			$this->load->view('includes/footer');
		}
	}
}