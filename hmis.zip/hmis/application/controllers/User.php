<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller 
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('users_model');
		if(! $this->session->userdata('loginId')){
			redirect('Login');
		}elseif ($this->session->userdata('loginType')!='Admin') {
			redirect('Home');
		}
	}

	public function login(){
		$this->load->view('user/login');
	}

	public function index()
	{
		$data['page_title']= 'APRS: Users';
		$this->load->view('includes/header', $data);
		$this->load->view('user/index');
		$this->load->view('includes/footer');
	}

	public function userdata(){
		$usersList = $this->users_model->getAll();
		$sn=0;
		$trows='';
		foreach ($usersList as $user) {
			$sn++;
			$trows .="<tr><td width='30'>" . $sn . "</td>";
			$trows .="<td width='130'>" . $user->UserType . "</td>";
			$trows .="<td width='200'>" . $user->FullName . "</td>";
			$trows .="<td width='300'>" . $user->Username . "</td>";
			$trows .='<td  width="100"><a onclick="delFunction('. $user->Id.', this)" href="#">
	              <span class="fa fa-trash btn btn-danger btn-sm"></span> 
	          </a>
	          <a onclick="getById('. $user->Id.')" href="#"><span class="fa fa-pencil btn btn-info btn-sm"></span> 
	          </a></td></tr>';
        }
		// $trows .='';
		echo $trows;
	}
	function getRM()
    {
    	$this->load->model('Dropdownvalue_model');
    	$district = $this->input->post('district');
    	$rms = $this->Dropdownvalue_model->getRM($district);
    	$output = '<option></option>';
    	foreach ($rms as $rm) {
    		$output .='<option>'.$rm->RM.'</option>';
    	}
    	$output .= '<option>RVWRMP</option>';
    	echo $output;
    }
    function addUser(){
    	$msg = $this->users_model->add();
    	if ($msg=='success') {
    		echo "User added successfully";
    	}else {
    		echo $msg;
    	}
    }
    function delUser(){
		$id = $this->input->get('id');
		$this->users_model->delete($id);
	}

    function getSingleUser(){
    	$id = $this->input->get('id');
        $data=$this->users_model->getById($id);
        echo json_encode($data);
    }
 
    function updateUser(){
        $msg = $this->users_model->update_user();
    	if ($msg=='success') {
    		echo "User updated successfully";
    	}else {
    		echo $msg;
    	}
    } 
}
