<?php defined('BASEPATH') OR exit('No direct script access allowed');

class AgriBusiness_model extends CI_Model
{
	function save($tbl, $data, $id){
		if ($id>0) {
			try {
				// $this->db->where('Id', $id);
				$res = $this->db->update_batch($tbl, $data, 'Id');
				if(!$res) throw new Exception($this->db->_error_message(), $this->db->_error_number());
				return TRUE;
			} catch (Exception $e) {
				return $e->getMessage();
			}
		}else{
			try {
				$res = $this->db->insert_batch($tbl, $data);
				if(!$res) throw new Exception($this->db->_error_message(), $this->db->_error_number());
				return TRUE;
			} catch (Exception $e) {
				return $e->getMessage();
			}
		}
	}

	function getAgriBusinessMaster(){
		if ($this->session->userdata('loginType')=='District') {
			$this->db->where('District', $this->session->userdata('loginDistrict'));
		}elseif ($this->session->userdata('loginType')=='RM') {
			$this->db->where('RM', $this->session->userdata('loginRM'));
		}
		$this->db->where('agb_cc', 'AGB');
		$this->db->order_by("Id", "asc");
		return $this->db->get('agri_business_master')->result();
	}

	function getCollectionCenterMaster(){
		if ($this->session->userdata('loginType')=='District') {
			$this->db->where('District', $this->session->userdata('loginDistrict'));
		}elseif ($this->session->userdata('loginType')=='RM') {
			$this->db->where('RM', $this->session->userdata('loginRM'));
		}
		$this->db->where('agb_cc', 'CC');
		$this->db->order_by("Id", "asc");
		return $this->db->get('agri_business_master')->result();
	}

	function getAllData($tbl){
		if ($this->session->userdata('loginType')=='District') {
			$this->db->where('District', $this->session->userdata('loginDistrict'));
		}elseif ($this->session->userdata('loginType')=='RM') {
			$this->db->where('RM', $this->session->userdata('loginRM'));
		}
		$this->db->order_by("Id", "asc");
		return $this->db->get($tbl)->result();
	}

	function getBusinessData($id, $tbl){
		$this->db->where('AgriBusinessId', $id);
		return $this->db->get($tbl);
	}

	function getById($id, $tbl){
		$this->db->where('Id', $id);
		return $this->db->get($tbl);		
	}

	function delById($id, $tbl){
		$this->db->trans_start();
		if ($tbl==='agri_business_master'){
			$this->db->where('Id', $id);
			$this->db->delete($tbl);
			
			$this->db->where('AgriBusinessId', $id);
			$this->db->delete('business_beneficiary');
			
			$this->db->where('AgriBusinessId', $id);
			$this->db->delete('business_cost_contribution');

			$this->db->where('AgriBusinessId', $id);
			$this->db->delete('business_item_cost');

			$this->db->where('BusinessId', $id);
			$this->db->delete('business_turnover');

			if ($this->db->trans_status() === FALSE)
			{
			    $this->db->trans_rollback();
			    return $this->db->error();
			}else{
				$this->db->trans_commit();
			    return 1;
			}
		}else{
			$this->db->where('id',$id);
			$this->db->delete($tbl);
			if($this->db->trans_status()===FALSE){
				$this->db->trans_rollback();
		    	return $this->db->error();
			}else{
				$this->db->trans_commit();
		    	return 1;
			}
		}
	}

	function getFormElements($tbl){
		if ($tbl=='cost_headings') {
			$this->db->where('relates', 'both');
			$this->db->or_where('relates', 'bp');
		}
		return $this->db->get($tbl)->result();
	}

	function getAnnualTurnOver($benId, $businessId){
		$this->db->where('businessId', $businessId);
		$this->db->where('BenId', $benId);
		return $this->db->get('business_turnover');
	}
}