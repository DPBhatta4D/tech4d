<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Coop_model extends CI_Model
{
	
	function __construct() {
        // Set table name
        $this->table = 'cooperative_information';
        $this->column_search = array('District','RM');
    }

    public function getRows($postData){
        $this->_get_datatables_query($postData);
        if($postData['length'] != -1){
            $this->db->limit($postData['length'], $postData['start']);
        }
        $query = $this->db->get();
        return $query;
    }
    
    
    public function countAll(){
        $this->db->from($this->table);
        return $this->db->count_all_results();
    }
    
    
    public function countFiltered($postData){
        $this->_get_datatables_query($postData);
        $query = $this->db->get();
        return $query->num_rows();
    }
    
    private function _get_datatables_query($postData){
        $search = $postData['search'];
        $search = $search['value'];
        $this->db->from($this->table);
        if ($this->session->userdata('loginType')=='District') {
            $this->db->where('District', $this->session->userdata('loginDistrict'));
        }elseif ($this->session->userdata('loginType')=='RM') {
            $this->db->where('RM', $this->session->userdata('loginRM'));
        }
        $this->db->order_by('Id', 'desc');
        $i = 0;
        // loop searchable columns 
        foreach($this->column_search as $item){
            // if datatable send POST for search
            if($postData['search']['value']){
                // first loop
                if($i===0){
                    // open bracket
                    $this->db->group_start();
                    $this->db->like($item, $postData['search']['value']);
                }else{
                    $this->db->or_like($item, $postData['search']['value']);
                }                
                // last loop
                if(count($this->column_search) - 1 == $i){
                    // close bracket
                    $this->db->group_end();
                }
            }
            $i++;
        }
         
        if(isset($postData['order'])){
            $this->db->order_by($this->column_order[$postData['order']['0']['column']], $postData['order']['0']['dir']);
        }else if(isset($this->order)){
            $order = $this->order;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }

    function getMembersDetail(){
        $q = " District, COUNT(Cooperative_Name) AS TotalCoops, SUM(share_member_female) AS FemaleMember, SUM(share_member_male) AS MaleMember, SUM(share_member_institution) AS InstitutionalMember, SUM(share_member_dalit) AS DalitMember, SUM(share_member_janajati) AS JanajatiMembers, SUM(share_member_other) AS OtheMembers, SUM(share_member_female+share_member_male+share_member_institution) AS TotalMembers FROM cooperative_information GROUP BY District";
        $this->db->select($q);
        $m = $this->db->get()->result();

        echo "<pre>";
        print_r($m);
        echo "</pre>";
    }

    function getAffiliationDetail(){
        $q = " District, COUNT(Cooperative_Name) AS TotalCoops, SUM(affiliated_cos) AffiliatedCOs, SUM(affiliated_hg_ig) AffiliatedHgIg, SUM(affiliated_others) AffiliatedOthers, SUM(affiliated_dwss_ucs+affiliated_irrigation_ucs+affiliated_mus_ucs) AffiliatedUCs FROM cooperative_information GROUP BY District";
        $this->db->select($q);
        $a = $this->db->get()->result();

        echo "<pre>";
        print_r($a);
        echo "</pre>";
    }

    function getShareDetail(){
        $q = " District, COUNT(Cooperative_Name) AS TotalCoops, SUM(total_share_amount) TotalShareCapital, SUM(total_saving) TotalSavings, SUM(ws_om_relief_fund) OmReliefFund, SUM(loan_in_ig+loan_in_livestock + loan_in_business + loan_in_foreign_employment + loan_in_home_loan) TotalInvestment FROM cooperative_information GROUP BY District";
        $this->db->select($q);
        $a = $this->db->get()->result();

        echo "<pre>";
        print_r($a);
        echo "</pre>";
    }

}