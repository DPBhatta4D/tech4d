<?php defined('BASEPATH') OR exit('No direct script access allowed');
class dropdownvalue_model extends CI_Model
{	
	function getDistrict()
	{
		$loginType = $this->session->userdata('loginType');
		$loginDistrict = $this->session->userdata('loginDistrict');
		$loginRM = $this->session->userdata('loginRM');

		if ($loginType =='Admin' ) {
			$this->db->select('District');
			$this->db->distinct();
			return $this->db->get('district_rm')->result();
		}
		elseif($loginType=='District')
		{
			$this->db->select('District');
			$this->db->distinct();
			$this->db->where('District', $loginDistrict);
			return $this->db->get('district_rm')->result();
		}
		elseif($loginType=='Super User')
		{
			$this->db->select('District');
			$this->db->distinct();			
			return $this->db->get('district_rm')->result();
		}
		else
		{
			$this->db->select('District');
			$this->db->distinct();
			$this->db->where('RM', $loginRM);
			return $this->db->get('district_rm')->result();
		}
	}

	function getRM($district)
	{	
		$loginType = $this->session->userdata('loginType');
		$loginRM = $this->session->userdata('loginRM');
		$this->db->select('RM');
		$this->db->distinct();
		$this->db->where('District', $district);
		if ($loginType==='RM') {
					$this->db->where('RM', $loginRM);
				}		
		return $this->db->get('district_rm')->result();
	}	
}