<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class IgDataTables_model extends CI_Model{
    
    function __construct() {
        // Set table name
        $this->table = 'ig_info';
        $this->column_search = array('District','RM','IG_Info_Type','Cluster_Name','Group_Person_Name','Business_Type','IG_Sector', 'Scheme_Code');
    }

    public function getRows($postData){
        $this->_get_datatables_query($postData);
        if($postData['length'] != -1){
            $this->db->limit($postData['length'], $postData['start']);
        }
        $query = $this->db->get();
        return $query;
    }
    
    
    public function countAll(){
        $this->db->from($this->table);
        return $this->db->count_all_results();
    }
    
    
    public function countFiltered($postData){
        $this->_get_datatables_query($postData);
        $query = $this->db->get();
        return $query->num_rows();
    }
    
    private function _get_datatables_query($postData){
        $search = $postData['search'];
        $search = $search['value'];
        $this->db->from($this->table);
        if ($this->session->userdata('loginType')=='District') {
			$this->db->where('District', $this->session->userdata('loginDistrict'));
		}elseif ($this->session->userdata('loginType')=='RM') {
			$this->db->where('RM', $this->session->userdata('loginRM'));
		}
        $this->db->order_by('Id', 'desc');
        $i = 0;
        // loop searchable columns 
        foreach($this->column_search as $item){
            // if datatable send POST for search
            if($postData['search']['value']){
                // first loop
                if($i===0){
                    // open bracket
                    $this->db->group_start();
                    $this->db->like($item, $postData['search']['value']);
                }else{
                    $this->db->or_like($item, $postData['search']['value']);
                }                
                // last loop
                if(count($this->column_search) - 1 == $i){
                    // close bracket
                    $this->db->group_end();
                }
            }
            $i++;
        }
         
        if(isset($postData['order'])){
            $this->db->order_by($this->column_order[$postData['order']['0']['column']], $postData['order']['0']['dir']);
        }else if(isset($this->order)){
            $order = $this->order;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }

}