<?php defined('BASEPATH') OR exit('No direct script access allowed');

class repository_model extends CI_Model
{
	function save_data($tblName,$data,$id){
		if ($id>0) {
			$this->db->where('id', $id);
			if($this->db->update($tblName,$data))
			{
				return $this->db->affected_rows();
			}else{
				$this->db->_error_message();
			}
		}else{
			if($this->db->insert($tblName,$data))
			{
				return $this->db->affected_rows();
			}else{
				$this->db->_error_message();
			}
		}
	}

	function getAll_Data($tblName){
		if ($this->session->userdata('loginType')=='District') {
			$this->db->where('District', $this->session->userdata('loginDistrict'));
		}elseif ($this->session->userdata('loginType')=='RM') {
			$this->db->where('RM', $this->session->userdata('loginRM'));
		}
		$this->db->order_by("Id", "asc");
		// $tt = $this->db->get($tblName)->result();
		// echo $this->db->last_query();
		// die();
		return $this->db->get($tblName)->result();
	}

	function getSchemeData($tblName, $Scheme_Code){
		$this->db->where('Scheme_Code', $Scheme_Code);
		$this->db->order_by("Id", "asc");
		return $this->db->get($tblName)->result();
	}

	function deleteInfo($tblName, $id){
		$this->db->trans_start();
		if ($tblName==='homegarden') {
			$this->db->where('Id', $id);
			$this->db->delete($tblName);
			if ($this->db->trans_status() === FALSE)
			{
			    $this->db->trans_rollback();
			    return $this->db->error();
			}else{
				$this->db->where('hgId', $id);
				$this->db->delete('hgmembers');
				if($this->db->trans_status()===FALSE){
					$this->db->trans_rollback();
			    	return $this->db->error();
				}else{
					$this->db->trans_commit();
			    	return 1;
				}
			}
		}else if ($tblName==='ig_info'){
			$this->db->where('Id', $id);
			$this->db->delete($tblName);
			if ($this->db->trans_status() === FALSE)
			{
			    $this->db->trans_rollback();
			    return $this->db->error();
			}else{
				$this->db->where('IgId', $id);
				$this->db->delete('ig_members');
				if($this->db->trans_status()===FALSE){
					$this->db->trans_rollback();
			    	return $this->db->error();
				}else{
					$this->db->trans_commit();
			    	return 1;
				}
			}
		}else if ($tblName==='schememaster'){
			$this->db->select('Scheme_Code');
			$this->db->where('Id', $id);
			$code = $this->db->get('schememaster')->row();
			$this->db->where('Id', $id);
			$this->db->delete($tblName);
			if ($this->db->trans_status() === FALSE)
			{
			    $this->db->trans_rollback();
			    return $this->db->error();
			}else{
				$this->db->where('Scheme_Code', $code->Scheme_Code);
				$this->db->delete('beneficiary');
				$this->db->where('Scheme_Code', $code->Scheme_Code);
				$this->db->delete('cost_contribution');
				$this->db->where('Scheme_Code', $code->Scheme_Code);
				$this->db->delete('item_cost');
				if($this->db->trans_status()===FALSE){
					$this->db->trans_rollback();
			    	return $this->db->error();
				}else{
					$this->db->trans_commit();
			    	return 1;
				}
			}
		}else if ($tblName==='agri_business_master'){
			$this->db->where('Id', $id);
			$this->db->delete($tblName);

			$this->db->where('AgriBusinessId', $id);
			$this->db->delete('business_beneficiary');
			
			$this->db->where('AgriBusinessId', $id);
			$this->db->delete('business_cost_contribution');

			$this->db->where('AgriBusinessId', $id);
			$this->db->delete('business_item_cost');

			$this->db->where('AgriBusinessId', $id);
			$this->db->delete('business_turnover');

			$this->db->where('AgriBusinessId', $id);
			$this->db->delete('collection_center_turnover');

			if ($this->db->trans_status() === FALSE)
			{
			    $this->db->trans_rollback();
			    return $this->db->error();
			}else{
				$this->db->trans_commit();
			    return 1;
			}
		}else{
			$this->db->where('id',$id);
			$this->db->delete($tblName);
			if($this->db->trans_status()===FALSE){
				$this->db->trans_rollback();
		    	return $this->db->error();
			}else{
				$this->db->trans_commit();
		    	return 1;
			}
		}
	}

	function getSchemeList(){
		$sis = $this->load->database('scheme_info', TRUE);
		$sectors = array('WATER SUPPLY', 'MUS', 'IRRIGATION');
		$district = $this->input->post('district');
		$rmc = $this->input->post('rm');
		$sis->distinct();
		$sis->select('Scheme_Code, Scheme_Name');
		$sis->from('scheme_info');
		$sis->where('District', $district);
		$sis->like('local_government', $rmc);
		//$sis->like('Fiscal_Year', $fy);
		$sis->where_in('Sector', $sectors);	
		$query=$sis->get();
		return $query->result();
	}


	function getById($id, $tbl){
		if ($tbl=='ig_members') {
			$this->db->where('IgId', $id);
		}else{
			$this->db->where('Id', $id);
		}
		return $this->db->get($tbl)->result();
	}

	function getIncomesById($id, $tbl){
		$this->db->where('IgId', $id);
		return $this->db->get($tbl)->result_array();
	}

	function getMemberIncome($id, $tbl){
		$this->db->where('Id', $id);
		return $this->db->get($tbl)->result_array();
	}

	function reportData($tbl){
		if ($this->session->userdata('loginType')=='District') {
			$this->db->where('District', $this->session->userdata('loginDistrict'));
		}elseif ($this->session->userdata('loginType')=='RM') {
			$this->db->where('RM', $this->session->userdata('loginRM'));
		}
		return $this->db->get($tbl)->result_array();
	}

	function getIncomeData(){

		$query='`Particulars`, `FY2074_75`, `FY2075_76`, `FY2076_77`, `FY2077_78`,(select `Group_Person_Name` from ig_info where Id=IG_Id) as Group_Person_Name FROM `income_info`';
		$this->db->select($query);	
		return $this->db->get()->result_array();
		
	}
	
	function saveIncome($tbl, $id, $data){
		$this->db->trans_start();
		if ($id>0) {
			$this->db->update_batch($tbl, $data, 'Id');
			if ($this->db->trans_status() === FALSE)
			{
			    $this->db->trans_rollback();
			    return $this->db->error();
			}
			else
			{
			    $this->db->trans_commit();
			    return 1;
			}
		}else{
			$this->db->insert_batch($tbl, $data);
			if ($this->db->trans_status() === FALSE)
			{
			    $this->db->trans_rollback();
			    return $this->db->error();
			}
			else
			{
			    $this->db->trans_commit();
			    return 1;
			}
		}
		
	}

	function save($tbl, $id, $data){
		if ($id>0) {
			try {
				$this->db->where('Id', $id);
				$this->db->update($tbl, $data);
				return $this->db->affected_rows();
			} catch (Exception $e) {
				return $e->getMessage();
			}
		}else{
			try {
				$this->db->insert($tbl, $data);
				return $this->db->insert_id();
				
			} catch (Exception $e) {
				return $e->getMessage();
			}
		}
		
	}

	function updateSchemeData($tbl, $id, $data){
		try {
			if ($tbl==='cost_contribution' || $tbl==='item_cost') {
				$this->db->where("Id", $id);
			}
			else{
				$this->db->where("Scheme_Code", $id);
			}
			$this->db->update($tbl,$data);
			//return $this->db->last_query();
			return $this->db->affected_rows();
			
		} catch (Exception $e) {
			return $e->getMessage();
		}
	}


	function getDataById($id, $tbl){
		$this->db->where('Id', $id);
		return $this->db->get($tbl)->result_array();
	}

	function getFormElements($tbl, $for=null){
		if ($for==='scheme') {
			$this->db->where('relates', 'both');
			$this->db->or_where('relates', 'scheme');
		}
		return $this->db->get($tbl)->result();
	}

	function addContribution_ItemCost($tbl, $data){
		try {
			$res = $this->db->insert_batch($tbl, $data);
			if(!$res) throw new Exception($this->db->_error_message(), $this->db->_error_number());
			return TRUE;
		} catch (Exception $e) {
			return $e->getMessage();
		}
	}

	function getSchemeListInRM($rmc){
		$this->db->where('RM', $rmc);
		$schemes= $this->db->get('schememaster');
		return $schemes;		
	}

	function getCode($rmc){
		$this->db->where('RM', $rmc);
		$row= $this->db->get('district_rm')->row();
		return $row->code;
	}

	//=========================================================
	function getRowById($id, $tbl){
		$this->db->where('Id', $id);
		return $this->db->get($tbl)->row();
	}

	//============================
	function updateIncomeData($tbl, $id, $data){
		try {
			$this->db->where("Id", $id);
			$this->db->update($tbl,$data);
			//return $this->db->last_query();
			return $this->db->affected_rows();
			
		} catch (Exception $e) {
			return $e->getMessage();
		}
	}

	function getHgMembers(){
		$this->db->select('hgmembers.*, homegarden.Group_Name');
		$this->db->from('hgmembers');
		if ($this->session->userdata('loginType')=='District') {
			$this->db->where('District', $this->session->userdata('loginDistrict'));
		}elseif ($this->session->userdata('loginType')=='RM') {
			$this->db->where('RM', $this->session->userdata('loginRM'));
		}
		$this->db->join('homegarden', 'hgmembers.hgId = homegarden.Id', 'left');
		return $this->db->get()->result_array();
	}

	function getIgMembers(){
		$this->db->select('ig_members.*, ig_info.Group_Person_Name');
		$this->db->from('ig_members');
		if ($this->session->userdata('loginType')=='District') {
			$this->db->where('District', $this->session->userdata('loginDistrict'));
		}elseif ($this->session->userdata('loginType')=='RM') {
			$this->db->where('RM', $this->session->userdata('loginRM'));
		}
		$this->db->join('ig_info', 'ig_members.IgId = ig_info.Id', 'left');
		return $this->db->get()->result_array();
	}

	function getHgMemberIncomes(){
	    $this->db->select('hgm_income_info.*, homegarden.Group_Name' );
	    $this->db->from('hgm_income_info');
	    $this->db->join('homegarden', 'hgm_income_info.Hg_Id = homegarden.Id', 'left');
		return $this->db->get()->result_array();
	}

	function getAgriBusinessData($businessType){
		$this->db->where('agb_cc', $businessType);
		if ($this->session->userdata('loginType')=='District') {
			$this->db->where('District', $this->session->userdata('loginDistrict'));
		}elseif ($this->session->userdata('loginType')=='RM') {
			$this->db->where('RM', $this->session->userdata('loginRM'));
		}
		return $this->db->get('agri_business_master')->result_array();
	}

	function getAgriBusinessBeneficies($businessType){
		$this->db->select('business_beneficiary.*, agri_business_master.AgriBusinessName');
		$this->db->from('business_beneficiary');
		$this->db->join('agri_business_master', 'business_beneficiary.AgriBusinessId=agri_business_master.Id', 'right');
		if ($this->session->userdata('loginType')=='District') {
			$this->db->where('agri_business_master.District', $this->session->userdata('loginDistrict'));
		}elseif ($this->session->userdata('loginType')=='RM') {
			$this->db->where('agri_business_master.RM', $this->session->userdata('loginRM'));
		}
		$this->db->where('agri_business_master.agb_cc', $businessType);

		return $this->db->get()->result_array();
	}

	function getAgriBusinessCostContribution($businessType){
		$this->db->select('business_cost_contribution.*, agri_business_master.AgriBusinessName');
		$this->db->from('business_cost_contribution');
		$this->db->join('agri_business_master', 'business_cost_contribution.AgriBusinessId=agri_business_master.Id', 'left');
		if ($this->session->userdata('loginType')=='District') {
			$this->db->where('agri_business_master.District', $this->session->userdata('loginDistrict'));
		}elseif ($this->session->userdata('loginType')=='RM') {
			$this->db->where('agri_business_master.RM', $this->session->userdata('loginRM'));
		}
		$this->db->where('agri_business_master.agb_cc', $businessType);

		return $this->db->get()->result_array();
	}

	function getAgriBusinessItemCost($businessType){
		$this->db->select('business_item_cost.*, agri_business_master.AgriBusinessName');
		$this->db->from('business_item_cost');
		$this->db->join('agri_business_master', 'business_item_cost.AgriBusinessId=agri_business_master.Id', 'left');
		if ($this->session->userdata('loginType')=='District') {
			$this->db->where('agri_business_master.District', $this->session->userdata('loginDistrict'));
		}elseif ($this->session->userdata('loginType')=='RM') {
			$this->db->where('agri_business_master.RM', $this->session->userdata('loginRM'));
		}
		$this->db->where('agri_business_master.agb_cc', $businessType);

		return $this->db->get()->result_array();
	}

	function getAgriBusinessMgmtCommittee($businessType){
		$this->db->select('business_management_committee.*, agri_business_master.AgriBusinessName');
		$this->db->from('business_management_committee');
		$this->db->join('agri_business_master', 'business_management_committee.AgriBusinessId=agri_business_master.Id', 'left');
		if ($this->session->userdata('loginType')=='District') {
			$this->db->where('agri_business_master.District', $this->session->userdata('loginDistrict'));
		}elseif ($this->session->userdata('loginType')=='RM') {
			$this->db->where('agri_business_master.RM', $this->session->userdata('loginRM'));
		}
		$this->db->where('agri_business_master.agb_cc', $businessType);

		return $this->db->get()->result_array();
	}

	function getRAS(){
		$this->db->select(' "Homegarden" AS Activity, (SELECT SUM(a.`DF`+a.dm+a.`JF`+a.`JM`+a.`OF`+a.`OM`) hg FROM homegarden a) AS BenHH, (SELECT SUM(hgmembers.DF+hgmembers.DM+hgmembers.JF+hgmembers.JM+hgmembers.OF+hgmembers.OM) ben FROM hgmembers) AS BenPop UNION SELECT "Income Generation" AS Activity, (SELECT SUM(a.DF+a.DM+a.JF+a.JM+a.OF+a.OM) BenHH FROM ig_info a) AS HH, (SELECT SUM(ig_members.Male+ig_members.Female) ben FROM ig_members) AS BenHH UNION SELECT "Polyhouse" AS Activity, COUNT(b.HH_Head_Name) AS BenHH, SUM(b.Ben_Total) AS BenPop FROM beneficiary b LEFT JOIN schememaster a ON b.Scheme_Code = a.Scheme_Code UNION SELECT a.agb_cc AS Activity, COUNT(bb.HH_Head_Name) AS BenHH, SUM(bb.Ben_Total) AS BenPop FROM business_beneficiary bb INNER JOIN agri_business_master a ON bb.AgriBusinessId = a.Id GROUP BY a.agb_cc');
		return $this->db->get()->result();
	}

	
}