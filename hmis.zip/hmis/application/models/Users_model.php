<?php defined('BASEPATH') OR exit('No direct script access allowed');
class users_model extends CI_Model{
	public function login()
	{
		$arr['Username']= $this->input->post('username');
		$arr['Password']= md5($this->input->post('password'));
		$arr['status']=1;
		return $this->db->get_where('users', $arr)->row();//result
	}

	public function add()
	{		
		$data = array(
			'District' => $this->input->post('district'),
			'RM' => $this->input->post('rmc'),
			'UserType' => $this->input->post('usertype'),
			'FullName' => $this->input->post('fullname'),
			'Username' => $this->input->post('email'),
			'Password' => md5($this->input->post('password'))
		);
		if($this->db->insert('users',$data)){
			return 'success';
		}
		else{
			return $this->db->_error_message();
		}
	}

	public function getAll()
	{
		$this->db->order_by("Id", "asc");
		return $this->db->get('users')->result();
	}

	public function getById($id){
		$this->db->where('Id', $id);
		$q= $this->db->get('users');
		return $q->result_array();
	}

	public function delete($id){
		$this->db->where('id',$id);
		if($this->db->delete('users'))
		{
			return $this->db->affected_rows();
		}else{
			$this->db->_error_message();
		}
	}
	
    function update_user(){
        $data = array(
			'District' => $this->input->post('district'),
			'RM' => $this->input->post('rmc'),
			'UserType' => $this->input->post('usertype'),
			'FullName' => $this->input->post('fullname'),
			'Username' => $this->input->post('email'),
			'Password' => md5($this->input->post('password'))
		); 
        $this->db->where('Username', $this->input->post('email'));
        $this->db->update('users', $data);
        if ($this->db->affected_rows()>0) {
        	return 'success';
        }
        else{
        	return 'Nothing updated';
        	//$this->db->_error_message();
        }
    }

}