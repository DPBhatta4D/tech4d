<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<link href="<?php echo base_url(); ?>assets/build/css/scheme_info_update.css" rel="stylesheet">
<div class="right_col" role="main" style="min-height: 770px;">
    <div class="" style="margin-top: 40px;">
		<div class="clearfix"></div>
		<div class="row">
			<div class="col-md-12 col-sm-12 col-xs-12">
			    <div class="x_panel">
			      <div class="x_title">
			        <h2 style="line-height: 25px;">Update Agri-Business Information</h2><br>
			        <div class="clearfix"></div>
			      </div>
			      <div class="x_content">
			      	<div class="row">
			      		<div class="col-md-8"><br>
			      			<table class="table" style="border-bottom: solid thin lightgrey;">
			  					<tr>
			  						<td style="text-align: right;"><b>Scheme Name</b></td>
			  						<td><?php echo $schemename ?></td>
			  						<td style="text-align: right;"><b>Current Status</b></td>
			  						<td id="sts"><?php echo $currentstatus ?></td>
			  					</tr>
			      			</table>
			      		</div>
			      		<div class="col-md-6">
			      			<div class="alert alert-danger alert-dismissible" role="alert" id="warning">
								<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
								<p id="msg"></p>
							</div>
							<div class="alert alert-success alert-dismissible" role="alert" id="success">
								<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
								<p id="msg1"></p>
							</div>
			      		</div>              		
			      	</div>
			        <div class="" role="tabpanel" data-example-id="togglable-tabs">
			          <ul id="myTab" class="nav nav-tabs bar_tabs" role="tablist">
			            <li role="presentation" class="active"><a href="#tab_content1" role="tab" data-toggle="tab" aria-expanded="false">Beneficiary</a>
			            </li>
			            <li role="presentation" class=""><a href="#tab_content2" role="tab" data-toggle="tab" aria-expanded="false">Cost Contribution</a>
			            </li>
			            <li role="presentation" class=""><a href="#tab_content3" role="tab" id="profile-tab" data-toggle="tab" aria-expanded="false">Item Cost</a>
			            </li>
			            <li role="presentation" class=""><a href="#tab_content4" role="tab" id="profile-tab" data-toggle="tab" aria-expanded="false">Management Committee</a>
			            </li>
			          	<li role="presentation" class=""><a href="#tab_content0" role="tab" data-toggle="tab" aria-expanded="false">Scheme Status</a>
			            </li>
			          </ul>
			          <div id="myTabContent" class="tab-content">
			          	<div role="tabpanel" class="tab-pane fade " id="tab_content0" aria-labelledby="home-tab">
			              <div class="x_panel">
			                <div class="x_content" style="overflow-y: hidden; overflow-x: auto;">
			                  	<br>
			                  	
			                  	<form class="form-horizontal form-label-right">
			                  		<input type="hidden" name="sId" id="sId" value="<?php echo $Id; ?>">
			                  		<input type="hidden" name="id" id="id" value="0">
			                  		<div class="item form-group">
			                      		<label for="Current_Status" class="control-label col-md-3 col-xs-3">
			                      			Change Current Status:
			                      		</label>
			                      		<div class="col-md-3">
			                      			<select id="Current_Status" name="Current_Status" class="form-control col-md-7 col-xs-3" required="required">
												<option value=""></option>
												<option>PPO</option>
												<option>PPC</option>
												<option>IPO</option>
												<option>IPC*</option>
												<option>IPC</option>
											</select>
			                      		</div>
			                      		<div class="col-md-9">
			                      		</div>
			                      	</div>
			                  		<div class="item form-group" id="dateDiv">
							            <label for="Scheme_Completed_Date" class="control-label col-md-3 col-sm-3 col-xs-12">Scheme Completed Date </label>
							            <div class="col-md-2 col-sm-3 col-xs-6">
							              <select name = "year" id = "yearformated" class="form-control">
							                <option value="">Year</option>
							                <?php for ($i=2074; $i < 2081; $i++) {
							                  echo '<option>'.$i.'</option>';
							                } ?>
							              </select>
							            </div>
							            <div class="col-md-2 col-sm-3 col-xs-6">
							              <select name = "month" id = "monthformated" class="form-control">
							                <option value="">Month</option>
							                <?php for ($i=1; $i < 13; $i++) {
							                  if ($i<10) {
							                    echo '<option>0'.$i.'</option>';
							                  }else
							                    echo '<option>'.$i.'</option>';
							                } ?>                  
							              </select>
							            </div>
							            <div class="col-md-2 col-sm-3 col-xs-6">
							              <select name = "day" id = "dayformated" class="form-control">
							                <option value="">Day</option>
							                <?php for ($i=1; $i < 33; $i++) { 
							                  if ($i<10) {
							                    echo '<option>0'.$i.'</option>';
							                  }else
							                    echo '<option>'.$i.'</option>';
							                } ?>                  
							              </select>
							            </div>
							            <div class="col-md-3 col-sm-3 col-xs-6">
							              <input type = "text" id="Scheme_Completed_Date" class="form-control" name = "Scheme_Completed_Date" readonly placeholder="DD/MM/YYYY" required>
							            </div>
							        </div>
							        <div class="ln_solid"></div>
									<div class="form-group">
										<div class="col-md-6 col-md-offset-3">
										  <button type="button" id="submit_Status" class="btn btn-success">Save</button>
										</div>
									</div>
							    </form>
			                </div>
			              </div>
			            </div>
			            <div role="tabpanel" class="tab-pane fade active in" id="tab_content1" aria-labelledby="home-tab">
			              <div class="x_panel">
			                <div class="x_content" style="overflow-y: hidden; overflow-x: auto;">
			                  <br>
			                  <table class="table table-bordered table-hover table-striped" id="tblBen">
			                    <thead>
			                      <tr>
			                        <th width="100">
			                          <button type="button" id="btnAddBen" class="btn btn-default" onclick="addBenRow()"><span class="fa fa-plus"></span></button>
			                        </th>
			                        <th width="150">HH Head Name</th>
			                        <th width="120">Tole/Cluster</th>
			                        <th width="100">Ethnicity</th>
			                        <th width="90">Female Beneficiary</th>
			                        <th width="90">Male Beneficiary</th>
			                        <th width="70">Total</th>
			                      </tr>
			                  </thead>
			                    <tbody>
			                    	
			                    </tbody>
			                  </table>
			                </div>
			              </div>
			            </div>
			            <div role="tabpanel" class="tab-pane fade" id="tab_content2" aria-labelledby="home-tab">
			              	<div class="x_panel">
			                    <div class="x_content" style="overflow-y: hidden; overflow-x: auto;">
									<br>
									<table id="costContribution" class="table table-bordered table-hover table-striped" style="width: 70%;">

									</table>
			                    </div>
			              	</div>
			            </div>
			            <div role="tabpanel" class="tab-pane fade" id="tab_content3" aria-labelledby="home-tab">
							<div class="x_panel">
								<div class="x_content" style="overflow-y: hidden; overflow-x: auto;">
									<br>
									<table id="itemCost" style="width: 60%;" class="table table-bordered table-hover table-striped">

									</table>
								</div>
							</div>
			            </div>
			            <div role="tabpanel" class="tab-pane fade" id="tab_content4" aria-labelledby="home-tab">
							<div class="x_panel">
								<div class="x_content" style="overflow-y: hidden; overflow-x: auto;">
									<br>
									<table class="table table-bordered table-hover table-striped" id="tblManagement">
					                    <thead>
					                      <tr>
					                        <th width="100">
					                          <button type="button" id="btnAddBen" class="btn btn-default" onclick="addManagementRow()"><span class="fa fa-plus"></span></button>
					                        </th>
					                        <th width="150">Position</th>
					                        <th width="120">Ethnicity</th>
					                        <th width="100">Gender</th>
					                        <th width="90">Member Name</th>
					                        <th width="90">Representative From</th>
					                      </tr>
					                  	</thead>
					                    <tbody>
					                    	
					                    </tbody>
					                  </table>
								</div>
							</div>
			            </div>
			          </div>
			        </div>
			      </div>
			    </div>
		  	</div>
		</div>
    </div>
</div>
<form id="frmTurnover" class="form-horizontal form-label-left" action="<?php echo base_url();?>AgriBusinessPlan/getAnnualTurnoverData" method="POST">
  <div class="modal fade bs-example-modal-md" id="mdlTurnover" tabindex="-1" role="dialog" aria-hidden="true" style="display: none;">
    <div class="modal-dialog modal-md">
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title" id="myModalLabel2">Annual Turnover</h4>
        </div>
        <div class="modal-body">
        	<input type="hidden" name="tId" id="tId" value="0">
        	<a class="btn btn-success" onclick="addTurnOverRow()"><i class="fa fa-plus"></i> Add New</a><br><br>
        	<table class="table table-bordered table-hover" id="turnover">
        		<thead>
        			<tr>
        				<th>FY</th><th>Turnover</th><th width='120'></th>
        			</tr>
        		</thead>
        		<tbody>
        			
        		</tbody>
        	</table>
        </div>
        <div class="ln_solid"></div>
          <div class="form-group">
            <div class="col-md-6 col-md-offset-10">
              <button type="button" id="close" class="btn btn-default">Close</button>
            </div>
          </div>
      </div>
    </div>
  </div>          
</form>
<script src="<?php echo base_url(); ?>assets/build/js/agri_business_ben.js"></script>
<script src="<?php echo base_url(); ?>assets/build/js/business_cost_contribution.js"></script>
<script src="<?php echo base_url(); ?>assets/build/js/business_item_cost.js"></script>
<script src="<?php echo base_url(); ?>assets/build/js/agri_management.js"></script> 
<script type="text/javascript">
  	var ben = 0;
  	// Formation Date
	$('#yearformated').change(function(){
		$('#Scheme_Completed_Date').val($('#dayformated').val()+'/'+$('#monthformated').val()+'/'+$('#yearformated').val());
		$('#warning').hide();
	});
	$('#dayformated').change(function(){
		$('#Scheme_Completed_Date').val($('#dayformated').val()+'/'+$('#monthformated').val()+'/'+$('#yearformated').val());
		$('#warning').hide();
	});
	$('#monthformated').change(function(){
		$('#Scheme_Completed_Date').val($('#dayformated').val()+'/'+$('#monthformated').val()+'/'+$('#yearformated').val());
		$('#warning').hide();
	});
	//Date div
	$("#dateDiv").hide();
	$('#warning').hide();
	$('#success').hide();
	$('#Current_Status').change(function(){
		$('#warning').hide();
		if ($('#Current_Status').val()=='IPC') {
			$("#dateDiv").show();
		}else{
			$("#dateDiv").hide();
		}
	});

	$('#submit_Status').click(function(){
		if ($('#Current_Status').val()=="") {
			$('#msg').html('Please Change Current Status');
			$('#warning').show();
		}else if($('#Scheme_Completed_Date').val()=="" && $('#Current_Status').val()=="IPC"){
			$('#msg').html('Please Enter Completed Date');
			$('#warning').show();
		}else{
			$.ajax({
				url:'<?php echo base_url('AgriBusinessPlan/updateSchemeStatus'); ?>',
				method:'POST',
				data:{id:$('#sId').val(), status:$('#Current_Status').val(), cdate: $('#Scheme_Completed_Date').val()},
				success: function(data){
					if (data=='Saved Successfully' || data=='No Change') {
						$('#msg1').html(data);
						$('#success').show();
						$('#sts').html($('#Current_Status').val());
						window.setTimeout(function() {
					    $(".alert").slideUp(500, function(){
					        	$(this).remove('dismiss'); 
						    });
						}, 2000);
						
					}else{
						$('#msg').html(data);
						$('#warning').show();
					}
				}
			})
		}
	})

	function removeRow(e){
		var row = e.parentNode.parentNode;
		row.parentNode.removeChild(row);
		ben=0;
	}
	var benId, businessId = 0;

	function updateTurnOver(benId1, businessId1){
		benId = benId1;
		businessId = businessId1;
		loadTurnover(benId, businessId);
		$('#mdlTurnover').modal('show');
	}

	function loadTurnover(benId, businessId){
		$.ajax({
			url:'<?php echo base_url('AgriBusinessPlan/getTurnOver'); ?>',
			method:'POST',
			data:{benId:benId, businessId:businessId},
			success: function(data){
				$('#turnover tbody').html(data);
			}
		})
	}

	$('#close').on('click', function(){
      $('#submit').html('Submit');
      $('#frmTurnover').trigger("reset");
      $('#mdlTurnover').modal('hide');
      ben=0;
    });

    function addTurnOverRow(){
    	if (ben>0) {
    		alert('Please save data first');
    	}else{
	    	var tr="<tr><td><select class='form-control' id='fy'>";
	    	tr+="<option>2075/076</option>";
	    	tr+="<option>2076/077</option>";
	    	tr+="<option>2077/078</option>";
	    	tr+="<option>2078/079</option></select></td>";
	    	tr+="<td><input type='number' min='0' id='turnovern' class='form-control'></td>";
	    	tr+="<td width='120'><a class='btn btn-danger btn-sm' onclick='removeRow(this)'><i class='fa fa-minus'></i></a><a class='btn btn-success btn-sm' onclick='saveTurnOver()'><i class='fa fa-floppy-o'></i></a></td></tr>";

	    	$('#turnover tbody').append(tr);
	    	ben=1;
	    }
    }

    function saveTurnOver(){
    	$.ajax({
    		url:'<?php echo base_url('AgriBusinessPlan/savTurnover') ?>',
    		method:"POST",
    		data:{benId:benId, businessId:businessId, fy:$('#fy').val(), turnover: $("#turnovern").val()},
    		success: function(data){
    			if (data=='Saved Successfully' || data=='No Change') {
						loadTurnover(benId, businessId);
						ben=0;
					}else{
						alert(data);
					}
    		}
    	})
    }

    function delTurnOver(tbl,id,o){
        var urltext = '<?php echo base_url('AgriBusinessPlan/delById')?>';
        var p=o.parentNode.parentNode;
        var c=confirm('Are you sure');
        if(c==true){
            $.ajax({
                url: urltext,
                type: 'POST',
                data:{id:id, tbl:tbl},
                error: function(data){
                  alert(data);
                },
                success: function(data){
                        if (data=='deleted') {
                            alert("Record deleted successfull");            
                            p.parentNode.removeChild(p);
                        }else{
                            alert(data);
                        }
                  
                }
            });
        }        
	}

	
</script>