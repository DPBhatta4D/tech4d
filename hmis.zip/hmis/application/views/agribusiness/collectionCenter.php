<?php defined('BASEPATH') OR exit('No direct script access allowed'); 

?>

<link href="//cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css" rel="stylesheet">
<style type="text/css">
  th {
      background-color: #31bc86; /* #31bc86   */
      font-weight: bold;
      color: #fff;
      vertical-align: middle;
      text-align: center; 
  }
  .header > th {
      background-color: #31bc86; /* #31bc86   */
      font-weight: bold;
      color: #fff;
      vertical-align: middle;  
  }
  #myTable_wrapper{
    margin-top: -15px;
  }
</style>
  <!-- page content -->
  <div class="right_col" role="main" style="min-height: 770px;">
    <div class="" style="margin-top: 40px;">
      <div class="clearfix"></div>
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel">
              <div class="x_title">
                <h2 style="line-height: 25px;">Collection Center Information</h2>
                  <ul class="nav navbar-right panel_toolbox">
                    <li class="dropdown">
                      <a href="<?php echo base_url('Reports/get_CollectionCenterData') ?>" role="button" aria-expanded="false">Download Data <i class="fa fa-cloud-download"></i></a>
                    </li>
                  </ul>             
                <div class="clearfix"></div>
              </div>
              <div class="x_content">
                <div role="tabpanel" class="tab-pane fade  active in" id="tab_content1" aria-labelledby="home-tab">
                  <div class="x_panel">
                    <div class="x_content" style="overflow-y: hidden; overflow-x: auto;">
                      <br>
                      <div class="col-md-6">
                        <?php if ($this->session->flashdata('success')=='Saved') { ?>
                          <div class="alert alert-success alert-dismissible" role="alert" id="success">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            <p id="msg1">Save Successfully !!</p>
                          </div>
                        <?php } elseif($this->session->flashdata('success')=='error'){ ?>
                          <div class="alert alert-danger alert-dismissible" role="alert" id="success">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            <p id="msg1">Save Successfully !!</p>
                          </div>                          
                        <?php } ?>                      
                      </div>
                      <table class="table table-bordered table-hover table-striped" id="myTable">
                        <thead>
                          <tr>
                            <th width="90">
                              <button type="button" class="btn btn-default" data-toggle="modal" data-target="#mdlScheme"> Add New</button>
                            </th>
                            <th width="70">District</th>
                            <th width="120">RM</th>
                            <th width="30">Ward No.</th>
                            <th width="30">FY</th>
                            <th width="200">Collection Center Name</th>
                            <th width="120">Current Status</th>
                            <th width="80">Capacity</th>
                            <th width="120">Major Crops</th>
                            <th width="80">Catchment Area</th>
                            <th width="100">Operation Guideline</th>
                            <th width="100">Operation Directive</th>
                            <th width="80">Owner</th>
                            <th width="80">Owner Nature</th>
                            <th width="150">Support Organization</th>
                            <th width="100">Affiliation With Coop</th>
                            <th width="100">Population Coverage</th>                      
                            <th width="120">MoU Date</th>
                            <th width="120">Scheme Completed Date</th>
                            <th width="100">Action</th>
                          </tr>
                          
                        <tbody>
                          <?php echo $schemeList ?>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
      </div>
    </div>
  </div>
<form id="frmScheme" class="form-horizontal form-label-left" action="<?php echo base_url();?>AgriBusinessPlan/saveData" method="POST">
  <div class="modal fade bs-example-modal-lg" id="mdlScheme" tabindex="-1" role="dialog" aria-hidden="true" style="display: none;">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          
          <h4 class="modal-title" id="myModalLabel2">New Collection Center Information</h4>
        </div>
        <div class="modal-body">
          <div class="form-group">
            <label class="control-label col-md-3 col-sm-3 col-xs-12 col-sm-3 col-xs-12" for="district">District <span class="required">*</span>
            </label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input type="hidden" name="id" value="0" id="id">
              <select class="form-control col-md-7 col-xs-12" required="required" name="district" id="district">
                <option></option>
                <?php echo $districtList; ?>
              </select>
            </div>

            <label class="control-label col-md-3 col-sm-3 col-xs-12 col-sm-3 col-xs-12" for="rmc">RM Name <span class="required">*</span>
            </label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <select class="form-control col-md-7 col-xs-12" required="required" name="rmc" id="rmc">
                <option></option>
              </select>
            </div>
          </div>
          <div class="item form-group">
            <label class="control-label col-md-3 col-sm-3 col-xs-12 col-sm-3 col-xs-6" for="ward">Ward No. <span class="required">*</span>
            </label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input id="ward" min="1" max="15" class="form-control col-md-7 col-xs-12" name="ward" required="required" type="number">
            </div>
            <label class="control-label col-md-3 col-sm-3 col-xs-12 col-sm-3 col-xs-12" for="FY">FY <span class="required">*</span>
            </label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <select class="form-control col-md-7 col-xs-12" name="FY" id="FY" required>
                <option value=""></option>
                <?php for ($i=2070; $i < 2081; $i++) { 
                  ?>
                  <option><?php echo $i.'/'.($i+1); ?></option>
                <?php } ?>
              </select>
            </div>
          </div>
          <div class="item form-group">
            <label for="AgriBusinessName" class="control-label col-md-3 col-sm-3 col-xs-12">Collection Center Name <span class="required">*</span></label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input id="AgriBusinessName" type="text" name="AgriBusinessName" class="form-control col-md-7 col-xs-12" required="required">
            </div>
            <label for="BusinessOwner" class="control-label col-md-3 col-sm-3 col-xs-12">Owner <span class="required">*</span></label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input id="BusinessOwner" type="text" name="BusinessOwner" class="form-control col-md-7 col-xs-12" required="required">
            </div>
          </div>
          <div class="item form-group">
            <label for="BusinessOwnerNature" class="control-label col-md-3 col-sm-3 col-xs-12">Owner Nature <span class="required">*</span></label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <Select id="BusinessOwnerNature" name="BusinessOwnerNature" class="form-control col-md-7 col-xs-12" required="required">
                <option value="">---Select---</option>
                <option>Group</option>
                <option>Cooperative</option>
                <option>Community</option>
              </Select>
            </div>
            <label for="BusinessPlanPreparation" class="control-label col-md-3 col-sm-3 col-xs-12">Business Plan <span class="required">*</span></label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <Select id="BusinessPlanPreparation" name="BusinessPlanPreparation" class="form-control col-md-7 col-xs-12" required="required">
                <option value="">---Select---</option>
                <option>No Plan</option>
                <option>Plan prepared and implemented</option>
                <option>Plan prepared but not implemented</option>
              </Select>
            </div>
          </div>
          <div class="item form-group">
            <label for="Support_Org" class="control-label col-md-3 col-sm-3 col-xs-12">Support Organization <span class="required">*</span></label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input id="Support_Org" type="text" name="Support_Org" class="form-control col-md-7 col-xs-12" required="required">
            </div>
            <label for="LinkToValueChain" class="control-label col-md-3 col-sm-3 col-xs-12">Link to value chain <span class="required">*</span></label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <select class="form-control col-md-7 col-xs-12" required id="LinkToValueChain" name="LinkToValueChain">
                <option value=""></option>
                <option>Yes</option>
                <option>No</option>
              </select>
            </div>
          </div>
          <div class="item form-group">
            <label for="AffiliationWithCoops" class="control-label col-md-3 col-sm-3 col-xs-12">Affiliation with Coop <span class="required">*</span></label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <select class="form-control col-md-7 col-xs-12" required id="AffiliationWithCoops" name="AffiliationWithCoops">
                <option value=""></option>
                <option>Yes</option>
                <option>No</option>
              </select>
            </div>
            <label for="AffiliatedCoopName" class="control-label col-md-3 col-sm-3 col-xs-12">Cooperative Name <span class="required">*</span></label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input id="AffiliatedCoopName" type="text" name="AffiliatedCoopName" class="form-control col-md-7 col-xs-12" required="required">
            </div>
          </div>
          <div class="item form-group">
            <label for="CoveragePop" class="control-label col-md-3 col-sm-3 col-xs-12">Coverage Population <span class="required">*</span></label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input id="CoveragePop" type="number" min="1" name="CoveragePop" class="form-control col-md-7 col-xs-12" required="required">
            </div>
            <label for="CurrentStatus" class="control-label col-md-3 col-sm-3 col-xs-12">Current Status <span class="required">*</span></label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <select id="CurrentStatus" name="CurrentStatus" class="form-control col-md-7 col-xs-12" required="required">
                <option value=""></option>
                <option>PPO</option>
                <option>PPC</option>
                <option>IPO</option>
                <option>IPC*</option>
                <option>IPC</option>
              </select>
            </div>
          </div>
          <div class="item form-group">
            <label for="MajorCrops" class="control-label col-md-3 col-sm-3 col-xs-12">Major Crops <span class="required">*</span></label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input class="form-control col-md-7 col-xs-12" type="text" required id="MajorCrops" name="MajorCrops">
            </div>
            <label for="CatchmentArea" class="control-label col-md-3 col-sm-3 col-xs-12">Catchment Area <span class="required">*</span></label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input id="CatchmentArea" type="text" name="CatchmentArea" class="form-control col-md-7 col-xs-12" required="required">
            </div>
          </div>
          <div class="item form-group">
            <label for="CollectionCenterCapacity" class="control-label col-md-3 col-sm-3 col-xs-12">Collection Center Capacity(kg) <span class="required">*</span></label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input class="form-control col-md-7 col-xs-12" type="number" min="1" required id="CollectionCenterCapacity" name="CollectionCenterCapacity">
            </div>
            <label for="OperationGuideline" class="control-label col-md-3 col-sm-3 col-xs-12">Operation Guideline <span class="required">*</span></label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <select id="OperationGuideline" type="text" name="OperationGuideline" class="form-control col-md-7 col-xs-12" required="required">
                <option value=""></option>
                <option>Prepared and implemented</option>
                <option>Prepared but not implemented</option>
                <option>Not prepared</option>
              </select>
            </div>
          </div>
          <div class="item form-group">
            <label for="OperationDirective" class="control-label col-md-3 col-sm-3 col-xs-12">Operation Directive <span class="required">*</span></label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <select id="OperationDirective" type="text" name="OperationDirective" class="form-control col-md-7 col-xs-12" required="required">
                <option value=""></option>
                <option>Prepared and implemented</option>
                <option>Prepared but not implemented</option>
                <option>Not prepared</option>
              </select>
            </div>
          </div>
          <div class="item form-group">
            <label for="MoUDate" class="control-label col-md-3 col-sm-3 col-xs-12">MoU Date <span class="required">*</span></label>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <select name = "year" id = "yearformated" class="form-control">
                <option value="">Year</option>
                <?php for ($i=2074; $i < 2081; $i++) {
                  echo '<option>'.$i.'</option>';
                } ?>
              </select>
            </div>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <select name = "month" id = "monthformated" class="form-control">
                <option value="">Month</option>
                <?php for ($i=1; $i < 13; $i++) {
                  if ($i<10) {
                    echo '<option>0'.$i.'</option>';
                  }else
                    echo '<option>'.$i.'</option>';
                } ?>                  
              </select>
            </div>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <select name = "day" id = "dayformated" class="form-control">
                <option value="">Day</option>
                <?php for ($i=1; $i < 33; $i++) { 
                  if ($i<10) {
                    echo '<option>0'.$i.'</option>';
                  }else
                    echo '<option>'.$i.'</option>';
                } ?>                  
              </select>
            </div>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input type = "text" id="MoUDate" class="form-control" name = "MoUDate" readonly placeholder="DD/MM/YYYY" required>
              <input type="hidden" name="type" value="CC">
              <input type="hidden" name="SubSector" value="NA">
              <input type="hidden" name="BusinessType" value="NA">
            </div>
          </div>
          <div class="ln_solid"></div>
          <div class="form-group">
            <div class="col-md-6 col-md-offset-3">
              <button type="button" id="close" class="btn btn-default">Close</button>
              <button type="submit" id="submit" class="btn btn-success">Submit</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>          
</form>
  <script src="//cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
  <script type="text/javascript">
    $(document).ready(function(){
      $('#myTable').DataTable({
        "scrollX": true,
        "scrollY": 400,
        "ordering": false
      });

      window.setTimeout(function() {
        $(".alert").slideUp(500, function(){
            $(this).remove('dismiss'); 
          });
      }, 2000);
    })

    $('#close').on('click', function(){
      $('#submit').html('Submit');
      $('#frmScheme').trigger("reset");
      $('#mdlScheme').modal('hide');
    });

    function getRMs(district, rm){
      $.ajax({
        url:"<?php echo base_url();?>SchemeCard/getRMs",
        method:"POST",
        data:{district:district, rm:rm},
        success:function(data)
        {
         $('#rmc').html(data);
        }
      });
    }

    $('#district').change(function(){
      var district = $('#district').val();
      if(district != '')
      {
       getRMs(district, null);
       
      }else{
        $('#rm').html('<option value="">Select RM</option>');
      }
    });

    // MoU Date
    $('#yearformated').change(function(){
      $('#MoUDate').val($('#dayformated').val()+'/'+$('#monthformated').val()+'/'+$('#yearformated').val());
    });
    $('#dayformated').change(function(){
      $('#MoUDate').val($('#dayformated').val()+'/'+$('#monthformated').val()+'/'+$('#yearformated').val());
    });
    $('#monthformated').change(function(){
      $('#MoUDate').val($('#dayformated').val()+'/'+$('#monthformated').val()+'/'+$('#yearformated').val());
    });

    function deleteScheme(id,o){
    var urltext = '<?php echo base_url("AgriBusinessPlan/delById");?>';
    var p=o.parentNode.parentNode;
    var c=confirm('Are you sure');
    if(c==true){
      $.ajax({
        url: urltext,
        type: 'POST',
        data:{id:id, tbl:'agri_business_master'},
        error: function(){
          alert('Error!! user delete failed');
        },
        success: function(data){
          if (data=='deleted') {
            alert("Record deleted successfull");            
            p.parentNode.removeChild(p);
          }else{
            alert(data);
          }
          
        }
      });
    }        
  }

  function getById(id){
    $.ajax({
      url: '<?php echo base_url('AgriBusinessPlan/getById') ?>',
      method:'Post',
      dataType:'json',
      data:{id:id, tbl:'agri_business_master'},
      success: function(data){
        console.log(data);
        for (var i = data.length - 1; i >= 0; i--) {
          $('#id').val(data[i].Id);
          $('#district').val(data[i].District);
          getRMs(data[i].District, data[i].RM);
          $('#rmc').val(data[i].RM);
          $('#ward').val(data[i].WardNo);
          $('#FY').val(data[i].FY);
          $('#AgriBusinessName').val(data[i].AgriBusinessName);
          $('#SubSector').val(data[i].SubSector);
          $('#BusinessType').val(data[i].BusinessType);
          $('#BusinessOwner').val(data[i].Owner);
          $('#BusinessOwnerNature').val(data[i].OwnerNature);
          $('#BusinessPlanPreparation').val(data[i].BusinessPlanPreparation);
          $('#Support_Org').val(data[i].SupportOrg);
          $('#LinkToValueChain').val(data[i].LinkToValueChain);
          $('#AffiliationWithCoops').val(data[i].AffiliationWithCoops);
          $('#AffiliatedCoopName').val(data[i].AffiliatedCoopName);
          $('#CoveragePop').val(data[i].CoveragePop);
          $('#CurrentStatus').val(data[i].CurrentStatus);
          $('#MajorCrops').val(data[i].MajorCrops);
          $('#CatchmentArea').val(data[i].CatchmentArea);
          $('#CollectionCenterCapacity').val(data[i].CollectionCenterCapacity);
          $('#OperationGuideline').val(data[i].OperationGuideline);
          $('#OperationDirective').val(data[i].OperationDirective);
          $('#MoUDate').val(data[i].MoUDate);
          $('#Scheme_Start_Date').val(data[i].Scheme_Start_Date);
          $('#mdlScheme').modal('show');
        }
      }

    });
  }
  </script>
  