<?php defined('BASEPATH') OR exit('No direct script access allowed');
if ($this->session->flashdata('msg')=='success') { ?>
  <script type="text/javascript">
    alert("Saved Successfully");
  </script>
<?php }?>
<style type="text/css">
  .x_panel, .x_title {
    margin-bottom: 5px;
    padding: 10px 10px 5px;
  }
  .x_title h2 {
      margin: -7px 0 6px;
  }
  .table-bordered>tbody>tr>td, .table-bordered>tbody>tr>th, 
  .table-bordered>tfoot>tr>td, .table-bordered>tfoot>tr>th, 
  .table-bordered>thead>tr>td, .table-bordered>thead>tr>th {
      vertical-align: middle;
  }
  th {
    background-color: #31bc86; /* #31bc86   */
    font-weight: bold;
    color: #fff;
    vertical-align: middle;
    text-align: center; 
  }
  .header > th {
    background-color: #31bc86; /* #31bc86   */
    font-weight: bold;
    color: #fff;
    vertical-align: middle;  
  }
  div.dataTables_wrapper {
    width: 100%;
    margin: 0 auto;
  }

  .a-left{
    text-align: left;
  }
</style>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css">
<script type="text/javascript" src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
  <!-- page content -->
  <div class="right_col" role="main" style="min-height: 770px;">
    <div class="" style="margin-top: 40px;">
      <div class="clearfix"></div>
      <div class="row">
       <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel">
              <div class="x_title">
                <h2 style="line-height: 25px;">सहकारी विवरण</h2>
                  <ul class="nav navbar-right panel_toolbox">
                    <li class="dropdown">
                      <a href="javascript:void(0)" role="button" aria-expanded="false"> Download Data <i class="fa fa-cloud-download"></i></a>
                    </li>
                  </ul>             
                <div class="clearfix"></div>
              </div>
              <div class="x_content" style="overflow-x: auto;">
                <table class="table table-bordered table-hover table-striped" id="tblCoopInfo" style="width: 3500px;">
                  <thead>
                    <tr>
                      <th width="130">
                        <button type="button" class="btn btn-default" data-toggle="modal" data-target="#mdlCoop" title="Open Entry Form">नयाँ फारम</button>
                      </th>
                      <th width="60">जिल्ला</th>
                      <th width="80">गाउँपालिका</th>
                      <th width="30">वार्ड न.</th>
                      <th width="130">संस्थाको नाम</th>
                      <th width="70">महिला सदस्य संख्या</th>
                      <th width="70">पुरुष सदस्य संख्या</th>
                      <th width="70">संस्थागत सदस्य संख्या</th>
                      <th width="70">दलित सदस्य संख्या</th>
                      <th width="70">जनजाती सदस्य संख्या</th>
                      <th width="70">अन्य सदस्य संख्या</th>
                      <th width="70">कुल शेयर रकम</th>
                      <th width="70">कुल निक्षेप रकम</th>
                      <th width="130">खा.पा. यो. मर्मत सम्भार राहतकोष रकम</th>
                      <th width="80">आयआर्जन क्षेत्रमा लगानी</th>
                      <th width="70">ऋणी संख्या</th>
                      <th width="80">पशुपालन क्षेत्रमा लगानी</th>
                      <th width="70">ऋणी संख्या</th>
                      <th width="80">व्यापार क्षेत्रमा लगानी</th>
                      <th width="70">ऋणी संख्या</th>
                      <th width="100">वैदेशिक रोजगारी क्षेत्रमा लगानी</th>
                      <th width="70">ऋणी संख्या</th>
                      <th width="80">घरायसी क्षेत्रमा लगानी</th>
                      <th width="70">ऋणी संख्या</th>
                      <th width="70">कुल ब्याज आम्दानी</th>
                      <th width="70">कुल अन्य आम्दानी</th>
                      <th width="70">कुल आम्दानी</th>
                      <th width="70">कुल खर्च</th>
                      <th width="70">पाउनु पर्ने ब्याज</th>
                      <th width="70">कुल भाका नाघेको रकम</th>
                      <th width="120">संचालन आत्मनिर्भरता (OSS)</th>
                      <th width="100">आवद्ध सामुदायिक संस्था</th>
                      <th width="90">आवद्ध कृषि तथा आयआर्जन समूह</th>
                      <th width="90">आवद्ध खा.पा. योजना</th>
                      <th width="90">आवद्ध सिचाई योजना</th>
                      <th width="100">आवद्ध बहुउपयोगी योजना</th>
                      <th width="70">आवद्ध अन्य</th>
                      <th width="180">सहकारीले संचालन गरेको व्यवसाय</th>
                    </tr>
                  <tbody>
                     
                  </tbody>
                </table>
              </div>
            </div>
          </div>
      </div>
    </div>
  </div>       
</form>
  <form id="frmCoop" class="form-horizontal form-label-left" action="<?php echo base_url();?>Hg/saveData" method="POST">
    <div class="modal fade bs-example-modal-lg" id="mdlCoop" tabindex="-1" role="dialog" aria-hidden="true" style="display: none;">
    <div class="modal-dialog modal-lg" style="width: 70%;">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span>
          </button>
          <h4 class="modal-title" id="myModalLabel2" style="text-align: center;">सहकारी विवरण फारम</h4>
        </div>
        <div class="modal-body">

          <div class="form-group">
            <label class="control-label col-md-1 col-sm-3 col-xs-12" for="district">जिल्ला 
            </label>
            <div class="col-md-1 col-sm-3 col-xs-6">
              <input type="hidden" name="id" value="0" id="id">
              <select class="form-control col-md-7 col-xs-12" required="required" name="district" id="district">
                <option value="">Select district</option>
                <option>Achham</option>
                <option>Bajhang</option>
                <option>Baitadi</option>
                <option>Bajura</option>
                <option>Darchula</option>
                <option>Dadeldhura</option>
                <option>Dailekh</option>
                <option>Doti</option>                            
                <option>Humla</option>                   
                <option>Kailali</option>
              </select>
            </div>

            <label class="control-label col-md-1 col-sm-3 col-xs-12 col-sm-3 col-xs-12" for="rmc"> पालिकाको नाम
            </label>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <select class="form-control col-md-7 col-xs-12" required="required" name="rmc" id="rmc">
                <option value="">select RM</option>
              </select>
            </div>
            <label class="control-label col-md-1 col-sm-3 col-xs-12 col-sm-3 col-xs-6" for="ward">वार्ड नं. 
            </label>
            <div class="col-md-1 col-sm-3 col-xs-6">
              <input id="ward" class="form-control col-md-7 col-xs-12" name="ward" placeholder="ward number" required="required" type="number" min="1" max="15">
            </div>
            <label class="control-label col-md-2 col-sm-3 col-xs-12 col-sm-3 col-xs-6" for="coopName">सहकारीको संस्थाको नाम 
            </label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input id="coopName" class="form-control col-md-7 col-xs-12" name="coopName" placeholder="Name of Cooperative" required="required" type="text" min="1" max="15">
            </div>
          </div>
          <hr>
          <div class="item form-group">            
            <label class="control-label col-md-1 col-sm-3" for="femaleMember">महिला सदस्य 
            </label>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <input type="number" id="femaleMember" name="femaleMember" min="0" required class="form-control col-md-7 col-xs-12" placeholder="Female share member">
            </div>
            <label class="control-label col-md-2 col-sm-3" for="maleMember">पुरुष सदस्य 
            </label>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <input type="number" id="maleMember" name="maleMember" min="0" required class="form-control col-md-7 col-xs-12" placeholder="Male share member">
            </div>
            <label class="control-label col-md-2 col-sm-3" for="instMember">संस्थागत सदस्य 
            </label>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <input type="number" id="instMember" name="instMember" min="0" required class="form-control col-md-7 col-xs-12" placeholder="Institutional share member">
            </div>
          </div>
          <div class="item form-group">
            <label class="control-label col-md-1 col-sm-3" for="dalitMember">दलित सदस्य 
            </label>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <input type="number" id="dalitMember" name="dalitMember" min="0" required class="form-control col-md-7 col-xs-12" placeholder="Dalit share member">
            </div>
            <label class="control-label col-md-2 col-sm-3" for="janajatiMember">जनजाती सदस्य 
            </label>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <input type="number" id="janajatiMember" name="janajatiMember" min="0" required class="form-control col-md-7 col-xs-12" placeholder="Janajati share member">
            </div>
            <label class="control-label col-md-2 col-sm-3" for="otherMember">अन्य सदस्य 
            </label>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <input type="number" id="otherMember" name="otherMember" min="0" required class="form-control col-md-7 col-xs-12"  placeholder="Other share member">
            </div>
          </div>
          <div class="item form-group">
            <label class="control-label col-md-1 col-sm-3" for="totalShare">कुल शेयर रकम
            </label>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <input type="number" id="totalShare" name="totalShare" min="0" required class="form-control col-md-7 col-xs-12" placeholder="शेयर रकम (total share)">
            </div>
            <label class="control-label col-md-2 col-sm-3" for="totalSaving">कुल निक्षेप(बचत) 
            </label>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <input type="number" id="totalSaving" name="totalSaving" min="0" required class="form-control col-md-7 col-xs-12" placeholder="बचत रकम (total savings)">
            </div>
            <label class="control-label col-md-2 col-sm-3" for="omFund">खा.पा. योजना मर्मत सम्भार राहतकोषमा भएको जम्मा रकम<span class="required"> *</span>
            </label>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <input type="number" id="omFund" name="omFund" min="0" required class="form-control col-md-7 col-xs-12" placeholder="WS OM relief fund">
            </div>
          </div>
          <hr>
          <h4 style="text-align: center;">पूंजी परिचालन (ऋण लगानी)</h4>
          <table style="width: 100%;" class="table table-bordered">
            <tr>
              <th width="100">लगानी क्षेत्र</th>
              <th width="100">लगानी रू</th>
              <th width="100">ऋणी संख्या</th>
              <th width="100">लगानी क्षेत्र</th>
              <th width="100">लगानी रू</th>
              <th width="100">ऋणी संख्या</th>
            </tr>
            <tr>
              <td width="100" style="text-align: right;"><label class="control-label" for="incomeSector">आयआर्जन</label></td>
              <td width="100" style="text-align: center;"><input type="number" id="incomeSector" name="incomeSector" min="0" required class="form-control" placeholder="investment in IG"></td>
              <td width="100" style="text-align: center;"><input type="number" id="investIncomeNumber" name="investIncomeNumber" min="0" required class="form-control" placeholder="No of loan in IG"></td>
              <td width="100" style="text-align: right;"><label class="control-label">पशुपालन</label></td>
              <td width="100" style="text-align: center;"><input type="number" id="livestockSector" name="livestockSector" min="0" required class="form-control" placeholder="investment in livestosk"></td>
              <td width="100" style="text-align: center;"><input type="number" id="investLivestockNumber" name="investLivestockNumber" min="0" required class="form-control" placeholder="No of loan in livestosk"></td>
            </tr>
            <tr>
              <td width="100" style="text-align: right;"><label class="control-label">व्यापार</label></td>
              <td width="100" style="text-align: center;"><input type="number" id="businessSector" name="businessSector" min="0" required class="form-control"placeholder="investment in investBusinessNumber"></td>
              <td width="100" style="text-align: center;"><input type="number" id="investBusinessNumber" name="investBusinessNumber" min="0" required class="form-control"placeholder="No of business loans"></td>
              <td width="100" style="text-align: right;"><label class="control-label">वैदेशिक रोजगारी</label></td>
              <td width="100" style="text-align: center;"><input type="number" id="foreignJobSector" name="foreignJobSector" min="0" required class="form-control" placeholder="investment in foreign job"></td>
              <td width="100" style="text-align: center;"><input type="number" id="investForeignNumber" name="investForeignNumber" min="0" required class="form-control" placeholder="No of loan for foreign job"></td>
            </tr>
            <tr>
              <td width="100" style="text-align: right;"><label class="control-label">घरायसी</label></td>
              <td width="100" style="text-align: center;"><input type="number" id="hhExp" name="hhExp" min="0" required class="form-control"placeholder="investment in household expenditure"></td>
              <td width="100" style="text-align: center;"><input type="number" id="investHHNumber" name="investHHNumber" min="0" required class="form-control" placeholder="No of loan for HH expenditure"></td>
              <td colspan="3"></td>
            </tr>
          </table>
          <hr>
          <div class="item form-group">            
            <label class="control-label col-md-2 col-sm-3" for="interestIncome">व्याज आम्दानी 
            </label>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <input type="number" id="interestIncome" step="0.01" name="interestIncome" min="0" required class="form-control col-md-7 col-xs-12" placeholder="Total interest income">
            </div>
            <label class="control-label col-md-2 col-sm-3" for="otherIncome">अन्य आम्दानी 
            </label>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <input type="number" id="otherIncome" name="otherIncome" min="0" required class="form-control col-md-7 col-xs-12" step="0.01" placeholder="Total other income">
            </div>
            <label class="control-label col-md-2 col-sm-3" for="totalIncome">कुल आम्दानी 
            </label>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <input type="number" id="totalIncome" step="0.01" name="totalIncome" min="0" required class="form-control col-md-7 col-xs-12" placeholder="Total Income">
            </div>
          </div>
          <div class="item form-group">
            <label class="control-label col-md-2 col-sm-3" for="totalExp">कुल खर्च 
            </label>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <input type="number" id="totalExp" name="totalExp" step="0.01" min="0" required class="form-control col-md-7 col-xs-12" placeholder="Total expenditure">
            </div>
            <label class="control-label col-md-2 col-sm-3" for="interestReceivable">पाउनु पर्ने ब्याज 
            </label>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <input type="number" id="interestReceivable" name="interestReceivable" step="0.01" min="0" required class="form-control col-md-7 col-xs-12" placeholder="Interest receivable">
            </div>
            <label class="control-label col-md-2 col-sm-3" for="amountOverDue">भाका नाघेको रकम 
            </label>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <input type="number" id="amountOverDue" name="amountOverDue" step="0.01" min="0" required class="form-control col-md-7 col-xs-12" placeholder="Amounts overdue">
            </div>
          </div>
          <div class="item form-group">
            <label class="control-label col-md-2 col-sm-3" for="oss">संचालन आत्मनिर्भरता (OSS) 
            </label>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <input type="number" id="oss" name="oss" step="0.01" min="0" required class="form-control col-md-7 col-xs-12">
            </div>
          </div>
          <hr>
          <div class="item form-group">
            <label class="control-label col-md-2 col-sm-3" for="affiliatedCOs">आवद्ध सामुदायिक संस्था 
            </label>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <input type="number" id="affiliatedCOs" name="affiliatedCOs" min="0" required class="form-control col-md-7 col-xs-12" placeholder=" No of affiliated COs">
            </div>
            <label class="control-label col-md-2 col-sm-3" for="affiliatedIGs">आवद्ध कृषि तथा आयआर्जन समूह 
            </label>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <input type="number" id="affiliatedIGs" name="affiliatedIGs" min="0" required class="form-control col-md-7 col-xs-12" placeholder=" No of affiliated IGs">
            </div>
            <label class="control-label col-md-2 col-sm-3" for="affiliatedWSUCs">आवद्ध खा.पा. योजना 
            </label>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <input type="number" id="affiliatedWSUCs" name="affiliatedWSUCs" min="0" required class="form-control col-md-7 col-xs-12" placeholder=" No of affiliated WS UCs">
            </div>
          </div>
          <div class="item form-group">
            <label class="control-label col-md-2 col-sm-3" for="affiliatedIrrUCs">आवद्ध सिंचाई योजना 
            </label>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <input type="number" id="affiliatedIrrUCs" name="affiliatedIrrUCs" min="0" required class="form-control col-md-7 col-xs-12" placeholder=" No of affiliated Irrigation UCs">
            </div>
            <label class="control-label col-md-2 col-sm-3" for="affiliatedMUSUCs">आवद्ध बहुउपयोगी योजना 
            </label>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <input type="number" id="affiliatedMUSUCs" name="affiliatedMUSUCs" min="0" required class="form-control col-md-7 col-xs-12" placeholder=" No of affiliated MUS UCs">
            </div>
            <label class="control-label col-md-2 col-sm-3" for="affiliatedOthers">आवद्ध अन्य 
            </label>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <input type="number" id="affiliatedOthers" name="affiliatedOthers" min="0" required class="form-control col-md-7 col-xs-12" placeholder=" No of other affiliations">
            </div>
          </div>
          <hr>
          <div class="item form-group">
            <label class="control-label col-md-2 col-sm-3" for="affiliatedOthers">सहकारीले संचालन गरेको व्यवसाय </label>
            <div class="form-group">              
              <div class="checkbox col-md-3">
                <label>
                  <input type="checkbox" id="agriBusiness" value="Agri product collection and marketing" onclick="get_set_val(this)"> कृषि उपज संकलन तथा बजारीकरण
                  <input type="hidden" id="hidden_agriBusiness" name="agriBusiness" value="-">
                </label>
              </div>
              <div class="checkbox col-md-2">
                <label>
                  <input type="checkbox" id="techSupport" value="Technical Support" onclick="get_set_val(this)"> प्राविधिक सहयोग
                  <input type="hidden" id="hidden_techSupport" name="techSupport" value="-">
                </label>
              </div>
              <div class="checkbox col-md-2">
                <label>
                  <input type="checkbox" id="investment" value="Investment" onclick="get_set_val(this)"> आर्थिक लगानी
                  <input type="hidden" id="hidden_investment" name="investment" value="-">
                </label>
              </div>              
            </div>
          </div>
          <hr>
          <div class="item form-group">
            <label for="dataUpdateDate" class="control-label col-md-2 col-sm-3 col-xs-12">तथ्यांक अद्यावधिक गरेको मिति</label>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <select name = "year" id = "yearRegistered" class="form-control">
                <option value="">वर्ष</option>
                <?php for ($i=2072; $i < 2081; $i++) {
                  echo '<option>'.$i.'</option>';
                } ?>
              </select>
            </div>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <select name = "month" id = "monthRegistered" class="form-control">
                <option value="">महिना</option>
                <?php for ($i=1; $i < 13; $i++) {
                  if ($i<10) {
                    echo '<option>0'.$i.'</option>';
                  }else
                    echo '<option>'.$i.'</option>';
                } ?>                  
              </select>
            </div>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <select name = "day" id = "dayRegistered" class="form-control">
                <option value="">दिन</option>
                <?php for ($i=1; $i < 33; $i++) { 
                  if ($i<10) {
                    echo '<option>0'.$i.'</option>';
                  }else
                    echo '<option>'.$i.'</option>';
                } ?>                  
              </select>
            </div>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input type="text" id="dataUpdateDate" class="form-control" name="dataUpdateDate" readonly placeholder="DD/MM/YYYY">
            </div>
          </div>
          <div class="ln_solid"></div>
          <div class="form-group">
            <div class="col-md-12" style="text-align: center;">
              <button type="button" id="close" class="btn btn-default">Close</button>
              <button type="submit" id="submit" class="btn btn-success">Submit</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>          
</form>

<script type="text/javascript">
  function get_set_val(v){
    if (v.checked) {
        $('#hidden_'+ v.id).val(v.value);
    }
    else{
      $('#hidden_'+ v.id).val('-');
    }  
  }

  $(document).ready(function(){
    $('#frmCoop').submit(function(e){
      e.preventDefault();
      $.ajax({
        url:"<?php echo base_url('Cooperative/Save') ?>",
        method:'POST',
        data: new FormData(this),
        contentType: false,
        cache: false,
        processData: false,
        success: function(data){
          if (data=='Saved') {
            alert('Saved Successfully !!');
            document.getElementById("frmCoop").reset();
            $('#mdlCoop').modal('hide');
            $('#id').val(0);
          }else{
            alert(data);
          }
        }
      });
    })

    $('#tblCoopInfo').DataTable( {
      "scrollX": true,
      "ordering": false,
      "lengthChange": false,
      "pageLength" : 10,
       "ordering": false,
       "processing": true,
       "serverSide": true,                 
       "ajax":{
          url :  '<?php echo base_url('Cooperative/getList'); ?>',
          type : 'POST'
      },
    });
  });

  $('#close').on('click', function(){
    $('#mdlCoop').modal('hide');
  });

  $('#mdlCoop').on('hidden.bs.modal', function (e) {
    $(this)
    .find("input[type=number]")
        .val("0")
        .end()
      .find("input[type=hidden]")
        .val('-')
        .end()
      .find("select")
        .val('')
        .end()
      .find("input[type=checkbox]")
        .prop("checked", "")
        .end()
      .find("input[name=id]")
        .val('0')
        .end();
  })

  function getRMs(d,r){
    $.ajax({
      url:"<?php echo base_url();?>Cooperative/getRM",
      method:"POST",
      data:{district:d, rm:r},
      success:function(data)
      {
        $('#rmc').html(data);
      }
     });
  }

  $('#district').change(function(){
    var district = $('#district').val();
    if(district != '')
    {
     $.ajax({
      url:"<?php echo base_url();?>Home/getRM",
      method:"POST",
      data:{district:district},
      success:function(data)
      {
       $('#rmc').html(data);
      }
     });
    }
    else
    {
      $('#rmc').html('<option value="">Select RM</option>');
    }
  });

  function delFunction(tbl,x,o){
    var urltext = '<?php echo base_url();?>Home/delete/'+tbl+'/'+x;
    var p=o.parentNode.parentNode;
    var c=confirm('Are you sure');
    if(c==true){
      $.ajax({
        url: urltext,
        type: 'POST',
        error: function(){
          alert('Error!! user delete failed');
        },
        success: function(data){
          if (data=='deleted') {
            alert("Record deleted successfull");            
            p.parentNode.removeChild(p);
          }else{
            alert(data);
          }
          
        }
      });
    }        
  }


  // Registration Date2
  $('#yearRegistered').change(function(){
    $('#dataUpdateDate').val($('#yearRegistered').val()+'/'+$('#monthRegistered').val()+'/'+$('#dayRegistered').val());
  });
  $('#monthRegistered').change(function(){
    $('#dataUpdateDate').val($('#yearRegistered').val()+'/'+$('#monthRegistered').val()+'/'+$('#dayRegistered').val());
  });
  $('#dayRegistered').change(function(){
    $('#dataUpdateDate').val($('#yearRegistered').val()+'/'+$('#monthRegistered').val()+'/'+$('#dayRegistered').val());
  });


  function getById(tbl,id){
    var urltext = '<?php echo base_url();?>Home/getById/'+tbl+'/'+id;
    // $('#IG_id_edit').val(id);
    $.ajax({
      url: urltext,
      type: 'POST',
      dataType: 'json',
      success: function(response){
        var len = response.length; 
        if (len>0) {
          $('#id').val(response[0].Id);
          $('#district').val(response[0].District);
          getRMs(response[0].District, response[0].RM);
          $('#ward').val(response[0].Ward);
          $('#coopName').val(response[0].Cooperative_Name);
          $('#femaleMember').val(response[0].share_member_female);
          $('#maleMember').val(response[0].share_member_male);
          $('#instMember').val(response[0].share_member_institution);
          $('#dalitMember').val(response[0].share_member_dalit);
          $('#janajatiMember').val(response[0].share_member_janajati);
          $('#otherMember').val(response[0].share_member_other);
          $('#totalShare').val(response[0].total_share_amount);
          $('#totalSaving').val(response[0].total_saving);
          $('#omFund').val(response[0].ws_om_relief_fund);
          $('#incomeSector').val(response[0].loan_in_ig);
          $('#investIncomeNumber').val(response[0].no_of_ig_investment);
          $('#livestockSector').val(response[0].loan_in_livestock);
          $('#investLivestockNumber').val(response[0].no_of_livestock_loans);
          $('#businessSector').val(response[0].loan_in_business);
          $('#investBusinessNumber').val(response[0].no_of_business_loan);
          $('#foreignJobSector').val(response[0].loan_in_foreign_employment);
          $('#investForeignNumber').val(response[0].no_of_employment_loan);
          $('#hhExp').val(response[0].loan_in_home_loan);
          $('#investHHNumber').val(response[0].no_of_home_loan);
          $('#interestIncome').val(response[0].interest_income);
          $('#otherIncome').val(response[0].other_income);
          $('#totalIncome').val(response[0].total_income);
          $('#totalExp').val(response[0].total_expenditure);
          $('#interestReceivable').val(response[0].interest_dues);
          $('#amountOverDue').val(response[0].interest_over_dues);
          $('#oss').val(response[0].oss);
          $('#affiliatedCOs').val(response[0].affiliated_cos);
          $('#affiliatedIGs').val(response[0].affiliated_hg_ig);
          $('#affiliatedWSUCs').val(response[0].affiliated_dwss_ucs);
          $('#affiliatedIrrUCs').val(response[0].affiliated_irrigation_ucs);
          $('#affiliatedMUSUCs').val(response[0].affiliated_mus_ucs);
          $('#affiliatedOthers').val(response[0].affiliated_others);
          var buss = response[0].cooperative_business;
          var businesses = buss.split(", ");
          for (var i = businesses.length - 1; i >= 0; i--) {
            if(businesses[i]==='Agri product collection and marketing'){
              document.getElementById("agriBusiness").checked = true;
              $('#hidden_agriBusiness').val(businesses[i]);
            }else if (businesses[i]==='Technical Support') {
              document.getElementById("techSupport").checked = true;
              $('#hidden_techSupport').val(businesses[i]);
            }else if(businesses[i]==='Investment'){
              document.getElementById("investment").checked = true;
              $('#hidden_investment').val(businesses[i]);
            }
          }
          var ymd = (response[0].updated_date).split('/');
          for (var i = ymd.length - 1; i >= 0; i--) {
            if(i===2){
              $('#dayRegistered').val(ymd[i]);
            }else if(i===1){
              $('#monthRegistered').val(ymd[i]);
            }else{
              $('#yearRegistered').val(ymd[i]);
            }
            
          }
          $('#dataUpdateDate').val(response[0].updated_date);
          $('#mdlCoop').modal('show');
        }
        else{
          alert('Data not found');
        }         
      }
    });
    
  }

</script>