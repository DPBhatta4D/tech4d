<?php defined('BASEPATH') OR exit('No direct script access allowed');
if ($this->session->flashdata('msg')=='success') { ?>
  <script type="text/javascript">
    alert("Saved Successfully");
  </script>
<?php }?>
<style type="text/css">
  .x_panel, .x_title {
    margin-bottom: 5px;
    padding: 10px 10px 5px;
  }
  .x_title h2 {
      margin: -7px 0 6px;
  }
  .table-bordered>tbody>tr>td, .table-bordered>tbody>tr>th, 
  .table-bordered>tfoot>tr>td, .table-bordered>tfoot>tr>th, 
  .table-bordered>thead>tr>td, .table-bordered>thead>tr>th {
      vertical-align: middle;
  }
  th {
    background-color: #31bc86; /* #31bc86   */
    font-weight: bold;
    color: #fff;
    vertical-align: middle;
    text-align: center; 
  }
  .header > th {
    background-color: #31bc86; /* #31bc86   */
    font-weight: bold;
    color: #fff;
    vertical-align: middle;  
  }
  div.dataTables_wrapper {
    width: 100%;
    margin: 0 auto;
  }
</style>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css">
<script type="text/javascript" src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
  <!-- page content -->
  <div class="right_col" role="main" style="min-height: 770px;">
    <div class="" style="margin-top: 40px;">
      <div class="clearfix"></div>
      <div class="row">
       <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel">
              <div class="x_title">
                <h2 style="line-height: 25px;">घरबारी समूह विवरण</h2>
                  <ul class="nav navbar-right panel_toolbox">
                    <li class="dropdown">
                      <a href="<?php echo base_url(); ?>Reports/HG_Data" role="button" aria-expanded="false"> Download Data <i class="fa fa-cloud-download"></i></a>
                    </li>
                  </ul>             
                <div class="clearfix"></div>
              </div>
              <div class="x_content" style="overflow-x: auto;">
                <table class="table table-bordered table-hover table-striped" id="tblHg">
                  <thead>
                    <tr>
                      <th width="170">
                        <button type="button" class="btn btn-default" data-toggle="modal" data-target="#mdlHG">नयाँ फारम</button>
                      </th>
                      <th width="100">जिल्ला</th>
                      <th width="100">गाउँपालिका</th>
                      <th width="50">वार्ड न.</th>
                      <th width="140">टोलको नाम</th>
                      <th width="200">घरबारी समुहको नाम</th>
                      <th width="110">घरबारी समुहको कोड</th>
                      <th width="100">गठन भएको मिति</th>
                      <th width="100">तालिम संचालन मिति</th>
                      <th width="100">फारम भरेको मिति</th>
                      <th width="80">हित कोष (छ/छैन)</th>
                      <th width="150">हितकोषमा हालसम्मको जम्मा रकम रु</th>
                      <th width="120">प्रति महिना प्रति सदस्य रु</th>
                      <th width="110">समुहको बैठक बस्ने दिन</th>
                      <th width="110">सहकारीमा आवद्ध छ/छैन</th>
                      <th width="160">आवद्ध भएको सहकारीको नाम</th>
                      <th width="150">सहकारीको ठेगाना</th>
                      <th width="150">सम्बन्धित निकायमा दर्ता छ/छैन</th>
                      <th width="150">निकायको नाम</th>
                      <th width="100">दर्ता नम्बर</th>
                      <th width="100">दर्ता मिति</th>
                      <th width="180">RVWRMP योजना अन्तर्गत भए योजनाको कोड</th>
                      <th width="150">समूह बारे अन्य विशेषता/जानकारी</th>
                    </tr>
                  <tbody>
                     
                  </tbody>
                </table>
              </div>
            </div>
          </div>
      </div>
    </div>
  </div>
  <!-- /page content -->
  <form id="frmHG_mem" class="form-horizontal form-label-left">
    <div class="modal fade bs-example-modal-lg" id="mdlHG_mem" tabindex="-1" role="dialog" aria-hidden="true" style="display: none;">
        <div class="modal-dialog modal-lg">
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span>
              </button>
              <h4 class="modal-title" id="myModalLabel2">घरवारी समूह सदस्यहरुको विवरण</h4>
            </div>
            <div class="modal-body"><br>
            <input type="hidden" id="hgId" name="hgId" value="0">
            <table style="width:100%; border: solid thin lightgrey;" class="table table-striped table-responsive" id="tblMember">
              <thead style="width:98%;">
                <tr>
                  <th width="150">सदस्यको नाम</th>
                  <th>दलित महिला</th>
                  <th>दलित पुरुष</th>
                  <th>जनजाती महिला</th>
                  <th>जनजाती पुरुष</th>
                  <th>अन्य महिला</th>
                  <th>अन्य पुरुष</th>
                  <th width="50"><a class="btn btn-sm btn-default" href="javascript:void(0)" onclick="addMemRow()"><span class="fa fa-plus"></span></a> </th>
                </tr>
              </thead>
              <tbody>
                
              </tbody>
            </table>
              <div class="ln_solid"></div>
              <div class="form-group">
                <div class="col-md-6 col-md-offset-3">
                  <button type="submit" id="submit" class="btn btn-success">Submit</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>          
    </form>
    <form id="frmHG_mem_ic" class="form-horizontal form-label-left">
        <div class="modal fade bs-example-modal-lg" id="mdlHG_mem_income" tabindex="-1" role="dialog" aria-hidden="true" style="display: none;">
        <div class="modal-dialog modal-lg">
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span>
              </button>
              <h4 class="modal-title" id="myModalLabel2">अगुवा कृषकहरुको आम्दानी विवरण</h4>
            </div>
            <div class="modal-body"><br>
            <input type="hidden" id="hgId" name="hgId" value="0">
            <table style="width:100%; border: solid thin lightgrey;" class="table table-striped table-responsive" id="tblMemberIncome">
              <thead style="width:98%;">
                <tr>
                  <th width="200">सदस्यको नाम</th>
                  <th style="text-align:right;">2074/075</th>
                  <th style="text-align:right;">2075/076</th>
                  <th style="text-align:right;">2076/077</th>
                  <th style="text-align:right;">2077/078</th>
                  <th style="text-align:right;">2078/079</th>
                  <th width="100" style="text-align:right;"><a class="btn btn-sm btn-default" href="javascript:void(0)" onclick="addMemIncome()"><span class="fa fa-plus"></span></a> </th>
                </tr>
              </thead>
              <tbody>
                
              </tbody>
            </table>
            </div>
          </div>
        </div>
      </div>          
    </form>
    <form id="frmHG" class="form-horizontal form-label-left" action="<?php echo base_url();?>Hg/saveData" method="POST">
    <div class="modal fade bs-example-modal-lg" id="mdlHG" tabindex="-1" role="dialog" aria-hidden="true" style="display: none;">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span>
          </button>
          <h4 class="modal-title" id="myModalLabel2">घरवारी समूह विवरण फारम</h4>
        </div>
        <div class="modal-body">
          <div class="form-group">
            <label class="control-label col-md-3 col-sm-3 col-xs-12 col-sm-3 col-xs-12" for="district">जिल्ला <span class="required">*</span>
            </label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input type="hidden" name="id" value="0" id="id">
              <select class="form-control col-md-7 col-xs-12" required="required" name="district" id="district">
                <option></option>
                <option>Achham</option>
                <option>Bajhang</option>
                <option>Baitadi</option>
                <option>Bajura</option>
                <option>Darchula</option>
                <option>Dadeldhura</option>
                <option>Dailekh</option>
                <option>Doti</option>                            
                <option>Humla</option>                   
                <option>Kailali</option>
              </select>
            </div>

            <label class="control-label col-md-3 col-sm-3 col-xs-12 col-sm-3 col-xs-12" for="rmc">गाउँ/नगरपालिका <span class="required">*</span>
            </label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <select class="form-control col-md-7 col-xs-12" required="required" name="rmc" id="rmc">
                <option></option>
              </select>
            </div>
          </div>
          <div class="item form-group">
            <label class="control-label col-md-3 col-sm-3 col-xs-12 col-sm-3 col-xs-6" for="ward">वार्ड नं. <span class="required">*</span>
            </label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input id="ward" class="form-control col-md-7 col-xs-12" name="ward" placeholder="ward number" required="required" type="number">
            </div>
            <label class="control-label col-md-3 col-sm-3 col-xs-12 col-sm-3 col-xs-12" for="clusterName">टोलको नाम <span class="required">*</span>
            </label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input type="text" id="clusterName" name="clusterName" required class="form-control col-md-7 col-xs-12" placeholder="cluster name">
            </div>
          </div>
          <div class="item form-group">
            <label for="hgName" class="control-label col-md-3 col-sm-3 col-xs-12">घरवारी समुहको नाम</label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input id="hgName" type="text" name="hgName" class="form-control col-md-7 col-xs-12" required="required" placeholder="HG group name">
            </div>
          
            <label for="hgCode" class="control-label col-md-3 col-sm-3 col-xs-12">घरवारी समुहको कोड</label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input id="hgCode" type="text" name="hgCode" class="form-control col-md-7 col-xs-12" required="required" placeholder="group code">
            </div>
          </div>
          <div class="item form-group">
            <label for="formatedDate" class="control-label col-md-3 col-sm-3 col-xs-12">गठन भएको मिति</label>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <select name = "year" id = "yearformated" class="form-control">
                <option value="">वर्ष</option>
                <?php for ($i=2072; $i < 2081; $i++) {
                  echo '<option>'.$i.'</option>';
                } ?>
              </select>
            </div>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <select name = "month" id = "monthformated" class="form-control">
                <option value="">महिना</option>
                <?php for ($i=1; $i < 13; $i++) {
                  if ($i<10) {
                    echo '<option>0'.$i.'</option>';
                  }else
                    echo '<option>'.$i.'</option>';
                } ?>                  
              </select>
            </div>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <select name = "day" id = "dayformated" class="form-control">
                <option value="">दिन</option>
                <?php for ($i=1; $i < 33; $i++) { 
                  if ($i<10) {
                    echo '<option>0'.$i.'</option>';
                  }else
                    echo '<option>'.$i.'</option>';
                } ?>                  
              </select>
            </div>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input type = "text" id="formatedDate" class="form-control" name = "formatedDate" readonly placeholder="DD/MM/YYYY" required>
            </div>
          </div>
          <div class="item form-group">
            <label for="formatedDate" class="control-label col-md-3 col-sm-3 col-xs-12">तालिम संचालन मिति</label>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <select name = "t_year" id = "t_year" class="form-control">
                <option value="">वर्ष</option>
                <?php for ($i=2072; $i < 2081; $i++) {
                  echo '<option>'.$i.'</option>';
                } ?>
              </select>
            </div>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <select name = "t_month" id = "t_month" class="form-control">
                <option value="">महिना</option>
                <?php for ($i=1; $i < 13; $i++) {
                  if ($i<10) {
                    echo '<option>0'.$i.'</option>';
                  }else
                    echo '<option>'.$i.'</option>';
                } ?>                  
              </select>
            </div>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <select name = "t_day" id = "t_day" class="form-control">
                <option value="">दिन</option>
                <?php for ($i=1; $i < 33; $i++) { 
                  if ($i<10) {
                    echo '<option>0'.$i.'</option>';
                  }else
                    echo '<option>'.$i.'</option>';
                } ?>                  
              </select>
            </div>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input type = "text" id="trainingDate" class="form-control" name ="trainingDate" readonly placeholder="DD/MM/YYYY" required>
            </div>
          </div>
          <div class="item form-group">
            <label for="formFilledDate" class="control-label col-md-3 col-sm-3 col-xs-12">फारम भरेको मिति</label>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <select name = "year" id = "yearfilled" class="form-control">
                <option value="">वर्ष</option>
                <?php for ($i=2072; $i < 2081; $i++) {
                  echo '<option>'.$i.'</option>';
                } ?>
              </select>
            </div>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <select name = "month" id = "monthfilled" class="form-control">
                <option value="">महिना</option>
                <?php for ($i=1; $i < 13; $i++) {
                  if ($i<10) {
                    echo '<option>0'.$i.'</option>';
                  }else
                    echo '<option>'.$i.'</option>';
                } ?>                  
              </select>
            </div>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <select name = "day" id = "dayfilled" class="form-control">
                <option value="">दिन</option>
                <?php for ($i=1; $i < 33; $i++) { 
                  if ($i<10) {
                    echo '<option>0'.$i.'</option>';
                  }else
                    echo '<option>'.$i.'</option>';
                } ?>                  
              </select>
            </div>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input type = "text" id="formFilledDate" class="form-control" name = "formFilledDate" readonly placeholder="DD/MM/YYYY" required>
            </div>
          </div>
          <div class="item form-group">
            <label for="savingFund" class="control-label col-md-3 col-sm-3 col-xs-12">हित कोष</label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <select id="savingFund" type="text" name="savingFund" class="form-control col-md-7 col-xs-12" required="required">
                <option value="">छान्नुहोस्</option>
                <option value="Yes">छ</option>
                <option value="No">छैन</option>
              </select>
            </div>
          
            <label for="fundAmount" class="control-label col-md-3 col-sm-3 col-xs-12">छ भने, हालसम्मको जम्मा रकम</label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input id="fundAmount" type="text" name="fundAmount" class="form-control col-md-7 col-xs-12" placeholder="total saving fund">
            </div>
          </div>
          <div class="item form-group">
            <label for="fundPerPersonPerPerson" class="control-label col-md-3 col-sm-3 col-xs-12">प्रति महिना प्रति सदस्य रु</label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input id="fundPerPersonPerPerson" type="text" name="fundPerPersonPerPerson" class="form-control col-md-7 col-xs-12" placeholder="Rs. per person per month">
            </div>
          
            <label for="meetingDay" class="control-label col-md-3 col-sm-3 col-xs-12">यो समुहको बैठक बस्ने दिन</label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input id="meetingDay" type="text" name="meetingDay" class="form-control col-md-7 col-xs-12" required="required" placeholder="meeting day">
            </div>
          </div>
          <div class="item form-group">
            <label for="coopAffiliation" class="control-label col-md-3 col-sm-3 col-xs-12">के यो समूह सहकारीमा आबद्ध छ</label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <select id="coopAffiliation" type="text" name="coopAffiliation" class="form-control col-md-7 col-xs-12" required="required">
                <option value="">छान्नुहोस्</option>
                <option value="Yes">छ</option>
                <option value="No">छैन</option>
              </select>
            </div>
          
            <label for="coopName" class="control-label col-md-3 col-sm-3 col-xs-12">छ भने, सहकारीको नाम</label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input id="coopName" type="text" name="coopName" class="form-control col-md-7 col-xs-12" placeholder="cooperative name">
            </div>
          </div>
          <div class="item form-group">
            <label for="coopAddress" class="control-label col-md-3 col-sm-3 col-xs-12">सहकारीको ठेगाना</label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input id="coopAddress" type="text" name="coopAddress" class="form-control col-md-7 col-xs-12" placeholder="cooperative address">
            </div>
          
            <label for="hgRegistration" class="control-label col-md-3 col-sm-3 col-xs-12">के यो समुह सम्बन्धित निकायमा दर्ता छ</label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <select id="hgRegistration" type="text" name="hgRegistration" class="form-control col-md-7 col-xs-12" required="required">
                <option value="">छान्नुहोस्</option>
                <option value="Yes">छ</option>
                <option value="No">छैन</option>
              </select>
            </div>
          </div>
          <div class="item form-group">
            <label for="registeredTo" class="control-label col-md-3 col-sm-3 col-xs-12">निकायको नाम</label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input id="registeredTo" type="text" name="registeredTo" class="form-control col-md-7 col-xs-12" placeholder="registered to">
            </div>
          
            <label for="registrationNo" class="control-label col-md-3 col-sm-3 col-xs-12">दर्ता नं.</label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input id="registrationNo" type="text" name="registrationNo" class="form-control col-md-7 col-xs-12" placeholder="registration number">
            </div>
          </div>
          <div class="item form-group">
            <label for="registrationDate" class="control-label col-md-3 col-sm-3 col-xs-12">दर्ता मिति</label>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <select name = "year" id = "yearRegistered" class="form-control">
                <option value="">वर्ष</option>
                <?php for ($i=2072; $i < 2081; $i++) {
                  echo '<option>'.$i.'</option>';
                } ?>
              </select>
            </div>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <select name = "month" id = "monthRegistered" class="form-control">
                <option value="">महिना</option>
                <?php for ($i=1; $i < 13; $i++) {
                  if ($i<10) {
                    echo '<option>0'.$i.'</option>';
                  }else
                    echo '<option>'.$i.'</option>';
                } ?>                  
              </select>
            </div>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <select name = "day" id = "dayRegistered" class="form-control">
                <option value="">दिन</option>
                <?php for ($i=1; $i < 33; $i++) { 
                  if ($i<10) {
                    echo '<option>0'.$i.'</option>';
                  }else
                    echo '<option>'.$i.'</option>';
                } ?>                  
              </select>
              
            </div>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input type="text" id="registrationDate" class="form-control" name="registrationDate" readonly placeholder="DD/MM/YYYY">
            </div>
          </div>
          <div class="item form-group">
            <label for="schemeName" class="control-label col-md-9 col-sm-9 col-xs-12">यो समूह RVWRMP को खानेपानी वा बहुउद्देश्यीय आयोजना अन्तर्गत पर्दछ भने, आयोजनाको कोड</label>
            <div class="col-md-3 col-sm-6 col-xs-6">
              <input id="schemeName" type="text" name="schemeName" class="form-control col-md-7 col-xs-12" placeholder="scheme name if applicable">
            </div>
          </div>
          <div class="item form-group">
            <label class="control-label col-md-12" style="text-align: left;"><u>समुहमा आवद्ध सदस्यहरुको विवरण</u></label>
            <hr>
            <label class="control-label col-md-2 col-sm-9 col-xs-12">दलित महिला</label>
            <div class="col-md-2 col-sm-6 col-xs-6">
              <input id="df" type="number" name="df" class="form-control col-md-7 col-xs-12" placeholder="दलित महिला">
            </div>
            <label class="control-label col-md-2 col-sm-9 col-xs-12">दलित पुरुष</label>
            <div class="col-md-2 col-sm-6 col-xs-6">
              <input id="dm" type="number" name="dm" class="form-control col-md-7 col-xs-12" placeholder="दलित पुरुष">
            </div>
            <label class="control-label col-md-2 col-sm-9 col-xs-12">जनजाती महिला</label>
            <div class="col-md-2 col-sm-6 col-xs-6">
              <input id="jf" type="number" name="jf" class="form-control col-md-7 col-xs-12" placeholder="जनजाती महिला">
            </div>
          </div>
          <div class="item form-group">
            <label class="control-label col-md-2 col-sm-9 col-xs-12">जनजाती पुरुष</label>
            <div class="col-md-2 col-sm-6 col-xs-6">
              <input id="jm" type="number" name="jm" class="form-control col-md-7 col-xs-12" placeholder="जनजाती पुरुष">
            </div>
            <label class="control-label col-md-2 col-sm-9 col-xs-12">अन्य महिला</label>
            <div class="col-md-2 col-sm-6 col-xs-6">
              <input id="of" type="number" name="of" class="form-control col-md-7 col-xs-12" placeholder="अन्य महिला">
            </div>
            <label class="control-label col-md-2 col-sm-9 col-xs-12">अन्य पुरुष</label>
            <div class="col-md-2 col-sm-6 col-xs-6">
              <input id="om" type="number" name="om" class="form-control col-md-7 col-xs-12" placeholder="अन्य पुरुष">
            </div>
          </div>
          <div class="item form-group">
            <label for="others" class="control-label col-md-3 col-sm-6 col-xs-12">यो समूह बारे अन्य केहि बिशेषता/जानकारी</label>
            <div class="col-md-9 col-sm-6 col-xs-12">
              <textarea id="others" name="others" class="form-control col-md-7 col-xs-12" placeholder="other information about the group"></textarea>
            </div>
          </div>
          <div class="ln_solid"></div>
          <div class="form-group">
            <div class="col-md-6 col-md-offset-3">
              <button type="button" id="close" class="btn btn-default">Close</button>
              <button type="submit" id="submit" class="btn btn-success">Submit</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>          
</form>

<!-- Edit Form Here -->
<script type="text/javascript">
  function addMemRow(){
    var tr = '<tr><td width="150"><input type="text" name="memName[]" class="form-control" required></td><td><input type="number" min="0" value="0" name="dfm[]" class="form-control" required></td><td><input type="number" min="0" value="0" name="dmm[]" class="form-control" required></td><td><input type="number" min="0" value="0" name="jfm[]" class="form-control" required></td><td><input type="number" min="0" value="0" name="jmm[]" class="form-control" required></td><td><input type="number" min="0" value="0" name="ofm[]" class="form-control" required></td><td><input type="number" min="0" value="0" name="omm[]" class="form-control" required></td><td width="50"><a class="btn btn-sm btn-danger" href="javascript:void(0)" onclick="delMemRow(this)"><span class="fa fa-minus"></span></a></td></tr>';
    $('#tblMember tbody').append(tr);
  }
  
    function addMemIncome(){
        var tr='';
        $.ajax({
          url:'<?php echo base_url("Hg/getMembersList") ?>',
          method:'POST',
          data: {hid:$('#hgId').val()},
          success: function(data){
            tr = '<tr><td width="150"><input type="hidden" name="id" id="id" value="0"><select class="form-control" name="LFName[]" id="LFName">'+ data +'</select></td>';
            tr +='<td><input type="number" min="0" name="2074_2075[]" id="2074_2075" class="form-control" required></td>';
            tr +='<td><input type="number" min="0" name="2075_2076[]" id="2075_2076" class="form-control" required></td>';
            tr +='<td><input type="number" min="0" name="2076_2077[]" id="2076_2077" class="form-control" required></td>';
            tr +='<td><input type="number" min="0" name="2077_2078[]" id="2077_2078" class="form-control" required></td>';
            tr +='<td><input type="number" min="0" name="2078_2079[]" id="2078_2079" class="form-control" required></td>';
            tr += '<td width="100" style="text-align:right;"><a class="btn btn-sm btn-primary" href="javascript:void(0)" onclick="saveMemberIncome()"><span class="fa fa-floppy-o"></span></a><a class="btn btn-sm btn-danger" href="javascript:void(0)" onclick="delMemRow(this)"><span class="fa fa-minus"></span></a></td></tr>';
            $('#tblMemberIncome tbody').append(tr);
          }
        })
    }

  function delMemRow(o){
    var p=o.parentNode.parentNode;
    p.parentNode.removeChild(p);

  }

  function addMembers(id){    
    $('#hgId').val(id);
    $('#mdlHG_mem').modal('toggle');
    $.ajax({
      url:'<?php echo base_url("Hg/getMembers") ?>',
      method:'POST',
      data: {hid:id},
      success: function(data){
        $('#tblMember tbody').html(data);
      }
    })
  }
  
  function getLF_Income(id){
    $('#hgId').val(id);
    $('#mdlHG_mem_income').modal('toggle');
    $.ajax({
      url:'<?php echo base_url("Hg/getMemberIncome") ?>',
      method:'POST',
      data: {hid:id},
      success: function(data){
        $('#tblMemberIncome tbody').html(data);
      }
    })
  }

  function saveMemberIncome(){
    var hid = $('#hgId').val();
    var id = $('#id').val();
    var LFName = $("select[name='LFName[]']")
      .map(function(){return $(this).val();}).get();
    var f74_75 = $("input[name='2074_2075[]']")
      .map(function(){return $(this).val();}).get();
    var f75_76 = $("input[name='2075_2076[]']")
      .map(function(){return $(this).val();}).get();
    var f76_77 = $("input[name='2076_2077[]']")
      .map(function(){return $(this).val();}).get();
    var f77_78 = $("input[name='2077_2078[]']")
      .map(function(){return $(this).val();}).get();
    var f78_79 = $("input[name='2078_2079[]']")
      .map(function(){return $(this).val();}).get();

    $.ajax({
      url:'<?php echo base_url('Hg/saveMemberIncome') ?>',
      method:'POST',
      data:{iid:id, hgid: hid, lf_name:LFName, fy74_75:f74_75, fy75_76:f75_76, fy76_77:f76_77, fy77_78:f77_78, fy78_79:f78_79},
      success:function(data){
        if (data=='Saved Successfully' || data=='No Change') {
          getLF_Income(hid);
          $('#hgId').val(0);
          $('#id').val(0);
        }else{
          alert(data);
        }
      }
    })
  }

  function editMemberIncome(id, obj){
    var mid = id;
    $.ajax({
      url:'<?php echo base_url(); ?>Hg/getIncomeById',
      dataType:'JSON',
      data:{Id:mid},
      method:'POST',
      success: function(data){
        var currentRow=obj.parentNode.parentNode.rowIndex;
        var ronums = $('#tblMemberIncome tbody tr').length;
        var tbl="";
        
        for (var i = 0; i<data.length; i++) {        
          tr = '<tr><td width="150"><input type="hidden" name="id" id="id" value="'+id+'"><select class="form-control" name="LFName[]" id="LFName"><option>'+data[i].LF_Name+'</option></select></td>';
          tr +='<td><input type="number" min="0" name="2074_2075[]" id="2074_2075" class="form-control" value="'+data[i].FY2074_75+'" required></td>';
          tr +='<td><input type="number" min="0" name="2075_2076[]" id="2075_2076" class="form-control" value="'+data[i].FY2075_76+'" required></td>';
          tr +='<td><input type="number" min="0" name="2076_2077[]" id="2076_2077" class="form-control" value="'+data[i].FY2076_77+'" required></td>';
          tr +='<td><input type="number" min="0" name="2077_2078[]" id="2077_2078" class="form-control" value="'+data[i].FY2077_78+'" required></td>';
          tr +='<td><input type="number" min="0" name="2078_2079[]" id="2078_2079" class="form-control" value="'+data[i].FY2078_79+'" required></td>';
          tr += '<td width="100" style="text-align:right;"><a class="btn btn-sm btn-primary" href="javascript:void(0)" onclick="saveMemberIncome()"><span class="fa fa-floppy-o"></span></a><a class="btn btn-sm btn-danger" href="javascript:void(0)" onclick="delMemRow(this)"><span class="fa fa-minus"></span></a></td></tr>';
          if (ronums==currentRow) {
            $("#tblMemberIncome > tbody").append(tr);          
          }
          else{
            $('#tblMemberIncome > tbody > tr').eq(currentRow - 1).after(tr);
          }
        }
        
      }
    });

  }

  $(document).ready(function(){
    $('#frmHG_mem').submit(function(e){
      e.preventDefault();
      var r = document.getElementById("tblMember").rows.length;
      $.ajax({
        url:"<?php echo base_url('Hg/addMembers') ?>",
        method:'POST',
        data: new FormData(this),
        contentType: false,
        cache: false,
        processData: false,
        success: function(data){
          if (data=='Saved') {
            alert('Saved Successfully !!');
            document.getElementById("frmHG_mem").reset();
            $('#mdlHG_mem').modal('hide');
            $('#hgId').val(0);
          }else{
            alert(data);
          }
        }
      });
    })

    $('#tblHg').DataTable( {
      "scrollY": 400,
      "scrollX": true,
      "ordering": false,
      "lengthChange": false,
      "pageLength" : 10,
       "ordering": false,
       "processing": true,
       "serverSide": true,                 
       "ajax":{
          url :  '<?php echo base_url('Hg/getList'); ?>',
          type : 'POST'
      },
    });
  });

  $('#close').on('click', function(){
    $('#submit').html('Submit');
    $('#frmHG').trigger("reset");
    $('#mdlHG').modal('hide');
  });

  $('#close_ig').on('click', function(){
    $('#submit').html('Submit');
    $('#frmIG').trigger("reset");
    $('#mdlIG').modal('hide');
  });

    $('#close_ig_edit').on('click', function(){
    $('#submit').html('Submit');
    $('#frmIGEdit').trigger("reset");
    $('#mdlIGEdit').modal('hide');
  });

  $('#district').change(function(){
      var district = $('#district').val();
      if(district != '')
      {
       $.ajax({
        url:"<?php echo base_url();?>Home/getRM",
        method:"POST",
        data:{district:district},
        success:function(data)
        {
         $('#rmc').html(data);
        }
       });
      }
      {
        $('#rm').html('<option value="">Select RM</option>');
      }
    });

  function delFunction(tbl,x,o){
    var urltext = '<?php echo base_url();?>Home/delete/'+tbl+'/'+x;
    var p=o.parentNode.parentNode;
    var c=confirm('Are you sure');
    if(c==true){
      $.ajax({
        url: urltext,
        type: 'POST',
        error: function(){
          alert('Error!! user delete failed');
        },
        success: function(data){
          if (data=='deleted') {
            alert("Record deleted successfull");            
            p.parentNode.removeChild(p);
          }else{
            alert(data);
          }
          
        }
      });
    }        
  }

//=================================Homegarden =======================================================
  // Start Date2
  $('#yearfilled').change(function(){
    $('#formFilledDate').val($('#dayfilled').val()+'/'+$('#monthfilled').val()+'/'+$('#yearfilled').val());
  });
  $('#monthfilled').change(function(){
    $('#formFilledDate').val($('#dayfilled').val()+'/'+$('#monthfilled').val()+'/'+$('#yearfilled').val());
  });
  $('#dayfilled').change(function(){
    $('#formFilledDate').val($('#dayfilled').val()+'/'+$('#monthfilled').val()+'/'+$('#yearfilled').val());
  });
  // Formation Date
  $('#yearformated').change(function(){
    $('#formatedDate').val($('#dayformated').val()+'/'+$('#monthformated').val()+'/'+$('#yearformated').val());
  });
  $('#dayformated').change(function(){
    $('#formatedDate').val($('#dayformated').val()+'/'+$('#monthformated').val()+'/'+$('#yearformated').val());
  });
  $('#monthformated').change(function(){
    $('#formatedDate').val($('#dayformated').val()+'/'+$('#monthformated').val()+'/'+$('#yearformated').val());
  });
  // Registration Date2
  $('#yearRegistered').change(function(){
    $('#registrationDate').val($('#dayRegistered').val()+'/'+$('#monthRegistered').val()+'/'+$('#yearRegistered').val());
  });
  $('#monthRegistered').change(function(){
    $('#registrationDate').val($('#dayRegistered').val()+'/'+$('#monthRegistered').val()+'/'+$('#yearRegistered').val());
  });
  $('#dayRegistered').change(function(){
    $('#registrationDate').val($('#dayRegistered').val()+'/'+$('#monthRegistered').val()+'/'+$('#yearRegistered').val());
  });
  // Training Date
  $('#t_year').change(function(){
    $('#trainingDate').val($('#t_day').val()+'/'+$('#t_month').val()+'/'+$('#t_year').val());
  });
  $('#t_month').change(function(){
    $('#trainingDate').val($('#t_day').val()+'/'+$('#t_month').val()+'/'+$('#t_year').val());
  });
  $('#t_day').change(function(){
    $('#trainingDate').val($('#t_day').val()+'/'+$('#t_month').val()+'/'+$('#t_year').val());
  });


  function getById(tbl,id){
    var urltext = '<?php echo base_url();?>Home/getById/'+tbl+'/'+id;
    $('#IG_id_edit').val(id);
    $.ajax({
      url: urltext,
      type: 'POST',
      dataType: 'json',
      success: function(response){
        var len = response.length; 
        if (len>0) {
          //alert(response[0].Cluster_Name)
          $('#id').val(response[0].Id);
          var rm='<option>'+response[0].RM+'</option>';
          $('#district').val(response[0].District);
          $('#rmc').html(rm);
          $('#ward').val(response[0].Ward_No);
          $('#clusterName').val(response[0].Cluster_Name);
          $('#hgName').val(response[0].Group_Name);
          $('#hgCode').val(response[0].Group_Code);
          $('#formatedDate').val(response[0].Group_Formated_Date);
          $('#trainingDate').val(response[0].training_date);
          $('#formFilledDate').val(response[0].Form_Filled_Date);
          $('#savingFund').val(response[0].Saving_Fund);
          $('#fundAmount').val(response[0].Fund_Amount);
          $('#fundPerPersonPerPerson').val(response[0].fundPerPersonPerPerson);
          $('#meetingDay').val(response[0].Meeting_Day);
          $('#coopAffiliation').val(response[0].Coop_Affiliation);
          $('#coopName').val(response[0].Coop_Name);
          $('#coopAddress').val(response[0].Coop_Address);
          $('#hgRegistration').val(response[0].Group_Registration);
          $('#registeredTo').val(response[0].Registered_To);
          $('#registrationNo').val(response[0].Registration_No);
          $('#registrationDate').val(response[0].Registered_Date);
          $('#schemeName').val(response[0].Scheme_Code);
          $('#df').val(response[0].DF);
          $('#dm').val(response[0].DM);
          $('#jf').val(response[0].JF);
          $('#jm').val(response[0].JM);
          $('#of').val(response[0].OF);
          $('#om').val(response[0].OM);
          $('#others').val(response[0].Others);
          $('#mdlHG').modal('show');
        }
        else{
          alert('Data not found');
        }         
      }
    });
    
  }


//=======================================================

var flag=0;

function cancelEdit(e){
  var p=e.parentNode.parentNode;
  p.parentNode.removeChild(p);
  flag=0;
}
  
</script>