<?php defined('BASEPATH') OR exit('No direct script access allowed'); 
if ($this->session->flashdata('msg')=='success') { ?>
  <script type="text/javascript">
    alert("Saved Successfully");
  </script>
<?php }?>

<style type="text/css">
  .x_panel, .x_title {
    margin-bottom: 5px;
    padding: 10px 10px 5px;
  }
  .x_title h2 {
      margin: -7px 0 6px;
  }
  .table-bordered>tbody>tr>td, .table-bordered>tbody>tr>th, 
  .table-bordered>tfoot>tr>td, .table-bordered>tfoot>tr>th, 
  .table-bordered>thead>tr>td, .table-bordered>thead>tr>th {
      vertical-align: middle;
  }
  th {
    background-color: #31bc86; /* #31bc86   */
    font-weight: bold;
    color: #fff;
    vertical-align: middle;
    text-align: center; 
  }
  .header > th {
    background-color: #31bc86; /* #31bc86   */
    font-weight: bold;
    color: #fff;
    vertical-align: middle;  
  }
  div.dataTables_wrapper {
    width: 100%;
    margin: 0 auto;
  }
</style>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css">
<script type="text/javascript" src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
  <!-- page content -->
  <div class="right_col" role="main" style="min-height: 770px;">
    <div class="" style="margin-top: 40px;">
      <div class="clearfix"></div>
      <div class="row">
       <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="x_panel">
            <div class="x_title">
              <h2 style="line-height: 25px;">आयआर्जन विवरण</h2>
                <ul class="nav navbar-right panel_toolbox">
                  <li class="dropdown">
                    <a href="<?php echo base_url(); ?>Reports/IG_Data" role="button" aria-expanded="false"> Download Data <i class="fa fa-cloud-download"></i></a>
                  </li>
                </ul>             
              <div class="clearfix"></div>
            </div>
            <div class="x_content" style="overflow-x: auto;">
              
              <table class="table table-bordered table-hover table-striped" id="tblIg">
                <thead>
                  <tr>
                    <th width="140">
                      <button type="button" class="btn btn-default" data-toggle="modal" data-target="#mdlIG">नयाँ फारम</button>
                    </th>
                    <th width="50">विवरणको प्रकार</th>
                    <th width="50">जिल्ला</th>
                    <th width="80">गाउँपालिका</th>
                    <th width="30">वार्ड न.</th>
                    <th width="140">टोलको नाम</th>
                    <th width="160">सम्बद्ध व्यक्ति/समुहको नाम</th>
                    <th width="80">सम्बद्ध व्यक्ति/ समुहको कोड</th>
                    <th width="80">तालिम पाएको/व्यवसाय सुरु भएको मिति</th>
                    <th width="80">फारम सुरुमा भरेको मिति</th>
                    <th width="90">व्यवसायको प्रकृति</th>
                    <th width="150">आयआर्जनको क्षेत्र</th>
                    <th width="50">हित कोष (छ/छैन)</th>
                    <th width="80">हितकोषमा हालसम्मको जम्मा रकम रु</th>
                    <th width="90">प्रति महिना प्रति सदस्य रु</th>
                    <th width="90">सहकारीमा आवद्ध छ/छैन</th>
                    <th width="160">आवद्ध भएको सहकारीको नाम</th>
                    <th width="150">सहकारीको ठेगाना</th>
                    <th width="90">सहकारीबाट ऋण</th>
                    <th width="90">सम्बन्धित निकायमा दर्ता छ/छैन</th>
                    <th width="150">निकायको नाम</th>
                    <th width="100">दर्ता नं.</th>
                    <th width="100">दर्ता मिति</th>
                    <th width="150">RVWRMP योजना अन्तर्गत भए योजनाको कोड</th>
                    <th width="250">समूह बारे अन्य विशेषता/जानकारी</th>
                  </tr>
                <tbody>
                  
                </tbody>
              </table>                
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- /page content -->

<form id="frmIG" class="form-horizontal form-label-left" action="<?php echo base_url();?>Ig/saveIGData" method="POST">
    <div class="modal fade bs-example-modal-lg" id="mdlIG" tabindex="-1" role="dialog" aria-hidden="true" style="display: none;">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span>
          </button>
          <h4 class="modal-title" id="myModalLabel2">आयआर्जन विवरण फारम</h4>
        </div>
        <div class="modal-body">
          <div class="item form-group">
            <label class="control-label col-md-3 col-sm-3 col-xs-12 col-sm-3 col-xs-12" for="IG_Info_Type">आयआर्जन विवरण प्रकार <span class="required">*</span>
            </label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <select class="form-control col-md-7 col-xs-12" required="required" name="IG_Info_Type" id="IG_Info_Type">
                <option value="">छान्नुहोस्</option>
                <option value="Personal">व्यक्तिगत</option>
                <option value="Group">सामुहिक</option>
                <option value="Value Chain">Value Chain</option>
              </select>
            </div>
            <label class="control-label col-md-3 col-sm-3 col-xs-12 col-sm-3 col-xs-12" for="district">जिल्ला <span class="required">*</span>
            </label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input type="hidden" name="IG_id" value="0" id="IG_id">
              <select class="form-control col-md-7 col-xs-12" required="required" name="IG_district" id="IG_district">
                <option>जिल्ला छान्नुहोस्</option>
                <option>Achham</option>
                <option>Bajhang</option>
                <option>Baitadi</option>
                <option>Bajura</option>
                <option>Darchula</option>
                <option>Dadeldhura</option>
                <option>Dailekh</option>
                <option>Doti</option>                            
                <option>Humla</option>                   
                <option>Kailali</option>
              </select>
            </div>
          </div>
          <div class="item form-group">
            <label class="control-label col-md-3 col-sm-3 col-xs-12 col-sm-3 col-xs-12" for="IG_rmc">गाउँ/नगरपालिका <span class="required">*</span>
            </label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <select class="form-control col-md-7 col-xs-12" required="required" name="IG_rmc" id="IG_rmc">
                <option>गाउँ/नगरपालिका छान्नुहोस्</option>
              </select>
            </div>          
            <label class="control-label col-md-3 col-sm-3 col-xs-12 col-sm-3 col-xs-6" for="IG_ward">वार्ड नं. <span class="required">*</span>
            </label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input id="IG_ward" class="form-control col-md-7 col-xs-12" name="IG_ward" placeholder="ward number" required="required" type="number">
            </div>
          </div>
          <div class="item form-group">
            <label class="control-label col-md-3 col-sm-3 col-xs-12 col-sm-3 col-xs-12" for="IG_clusterName">टोलको नाम <span class="required">*</span>
            </label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input type="text" id="IG_clusterName" name="IG_clusterName" required class="form-control col-md-7 col-xs-12" placeholder="IG_cluster name">
            </div>
            <label for="Group_Person_Name" class="control-label col-md-3 col-sm-3 col-xs-12">व्यक्ति वा समुहको नाम</label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input id="Group_Person_Name" type="text" name="Group_Person_Name" class="form-control col-md-7 col-xs-12" required="required" placeholder="HG group name">
            </div>          
          </div>
          <div class="item form-group">
            <label for="Group_Person_Code" class="control-label col-md-3 col-sm-3 col-xs-12">व्यक्ति वा समुहको कोड</label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input id="Group_Person_Code" type="text" name="Group_Person_Code" class="form-control col-md-7 col-xs-12" required="required" placeholder="group code">
            </div>
          </div>
          <div class="item form-group">
            <label for="Business_Start_Date" class="control-label col-md-3 col-sm-3 col-xs-12">समूह गठन भई तालिम पाएको वा व्यवसाय सुरु भएको मिति</label>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <select name = "year" id = "ig_start_year" class="form-control">
                <option value="">वर्ष</option>
                <?php for ($i=2067; $i < 2081; $i++) {
                  echo '<option>'.$i.'</option>';
                } ?>
              </select>
            </div>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <select name = "month" id = "ig_start_month" class="form-control">
                <option value="">महिना</option>
                <?php for ($i=1; $i < 13; $i++) {
                  if ($i<10) {
                    echo '<option>0'.$i.'</option>';
                  }else
                    echo '<option>'.$i.'</option>';
                } ?>                  
              </select>
            </div>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <select name = "day" id = "ig_start_day" class="form-control">
                <option value="">दिन</option>
                <?php for ($i=1; $i < 33; $i++) { 
                  if ($i<10) {
                    echo '<option>0'.$i.'</option>';
                  }else
                    echo '<option>'.$i.'</option>';
                } ?>                  
              </select>
            </div>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input type = "text" id="Business_Start_Date" class="form-control" name = "Business_Start_Date" readonly placeholder="DD/MM/YYYY" required>
            </div>
          </div>
          <div class="item form-group">
            <label for="formFilledDate" class="control-label col-md-3 col-sm-3 col-xs-12">यो फारम सुरुमा भरेको मिति</label>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <select name = "year" id = "ig_yearfilled" class="form-control">
                <option value="">वर्ष</option>
                <?php for ($i=2067; $i < 2081; $i++) {
                  echo '<option>'.$i.'</option>';
                } ?>
              </select>
            </div>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <select name = "month" id = "ig_monthfilled" class="form-control">
                <option value="">महिना</option>
                <?php for ($i=1; $i < 13; $i++) {
                  if ($i<10) {
                    echo '<option>0'.$i.'</option>';
                  }else
                    echo '<option>'.$i.'</option>';
                } ?>                  
              </select>
            </div>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <select name = "day" id = "ig_dayfilled" class="form-control">
                <option value="">दिन</option>
                <?php for ($i=1; $i < 33; $i++) { 
                  if ($i<10) {
                    echo '<option>0'.$i.'</option>';
                  }else
                    echo '<option>'.$i.'</option>';
                } ?>                  
              </select>
            </div>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input type = "text" id="ig_formFilledDate" class="form-control" name = "ig_formFilledDate" readonly placeholder="DD/MM/YYYY" required>
            </div>
          </div>
          <div class="item form-group">
            <label for="Business_Type" class="control-label col-md-3 col-sm-3 col-xs-12">व्यवसायको प्रकृति</label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <select id="Business_Type" type="text" name="Business_Type" class="form-control col-md-7 col-xs-12" required="required">
                <option value="">छान्नुहोस्</option>
                <option value="Agricultrual">कृषिमा आधारित</option>
                <option value="Processing">प्रशोधनमा आधारित</option>
                <option value="Service Oriented">सेवामुलक</option>
              </select>
            </div>
          
            <label for="IG_Sector" class="control-label col-md-3 col-sm-3 col-xs-12">आयआर्जनको क्षेत्र</label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input id="IG_Sector" type="text" name="IG_Sector" class="form-control col-md-7 col-xs-12" placeholder="Business Sector" required>
            </div>
          </div>
          <div class="item form-group">
            <label for="ig_savingFund" class="control-label col-md-3 col-sm-3 col-xs-12">हित कोष</label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <select id="ig_savingFund" type="text" name="ig_savingFund" class="form-control col-md-7 col-xs-12" required="required">
                <option value="">छान्नुहोस्</option>
                <option value="Yes">छ</option>
                <option value="No">छैन</option>
              </select>
            </div>
          
            <label for="ig_fundAmount" class="control-label col-md-3 col-sm-3 col-xs-12">छ भने, हालसम्मको जम्मा रकम</label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input id="ig_fundAmount" type="text" name="ig_fundAmount" class="form-control col-md-7 col-xs-12" placeholder="total saving fund">
            </div>
          </div>
          <div class="item form-group">
            <label for="Fund_Per_Person" class="control-label col-md-3 col-sm-3 col-xs-12">प्रति महिना प्रति सदस्य रु</label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input id="Fund_Per_Person" type="text" name="Fund_Per_Person" class="form-control col-md-7 col-xs-12" placeholder="Rs. per person per month">
            </div>
            <label for="ig_coopAffiliation" class="control-label col-md-3 col-sm-3 col-xs-12">के यो समूह सहकारीमा आबद्ध छ</label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <select id="ig_coopAffiliation" type="text" name="ig_coopAffiliation" class="form-control col-md-7 col-xs-12" required="required">
                <option value="">छान्नुहोस्</option>
                <option value="Yes">छ</option>
                <option value="No">छैन</option>
              </select>
            </div>          
          </div>
          <div class="item form-group">
            <label for="ig_coopName" class="control-label col-md-3 col-sm-3 col-xs-12">छ भने, सहकारीको नाम</label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input id="ig_coopName" type="text" name="ig_coopName" class="form-control col-md-7 col-xs-12" placeholder="cooperative name">
            </div>
            <label for="ig_coopAddress" class="control-label col-md-3 col-sm-3 col-xs-12">सहकारीको ठेगाना</label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input id="ig_coopAddress" type="text" name="ig_coopAddress" class="form-control col-md-7 col-xs-12" placeholder="cooperative address">
            </div>            
          </div>
          <div class="item form-group">
            <label for="Loan_From_Coop" class="control-label col-md-3 col-sm-3 col-xs-12">के सहकारीबाट ऋण लिइएको छ</label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <select id="Loan_From_Coop" type="text" name="Loan_From_Coop" class="form-control col-md-7 col-xs-12" required="required">
                <option value="">छान्नुहोस्</option>
                <option value="Yes">छ</option>
                <option value="No">छैन</option>
              </select>
            </div>
          
            <label for="ig_Registration" class="control-label col-md-3 col-sm-3 col-xs-12">के यो समुह सम्बन्धित निकायमा दर्ता छ</label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <select id="ig_Registration" type="text" name="ig_Registration" class="form-control col-md-7 col-xs-12" required="required">
                <option value="">छान्नुहोस्</option>
                <option value="Yes">छ</option>
                <option value="No">छैन</option>
              </select>
            </div>
          </div>
          <div class="item form-group">
            <label for="ig_registeredTo" class="control-label col-md-3 col-sm-3 col-xs-12">निकायको नाम</label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input id="ig_registeredTo" type="text" name="ig_registeredTo" class="form-control col-md-7 col-xs-12" placeholder="registered to">
            </div>
          
            <label for="ig_registrationNo" class="control-label col-md-3 col-sm-3 col-xs-12">दर्ता नं.</label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input id="ig_registrationNo" type="text" name="ig_registrationNo" class="form-control col-md-7 col-xs-12" placeholder="registration number">
            </div>
          </div>
          <div class="item form-group">
            <label for="Registered_Date" class="control-label col-md-3 col-sm-3 col-xs-12">दर्ता मिति</label>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <select name = "year" id = "ig_yearRegistered" class="form-control">
                <option value="">वर्ष</option>
                <?php for ($i=2067; $i < 2081; $i++) {
                  echo '<option>'.$i.'</option>';
                } ?>
              </select>
            </div>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <select name = "month" id = "ig_monthRegistered" class="form-control">
                <option value="">महिना</option>
                <?php for ($i=1; $i < 13; $i++) {
                  if ($i<10) {
                    echo '<option>0'.$i.'</option>';
                  }else
                    echo '<option>'.$i.'</option>';
                } ?>                  
              </select>
            </div>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <select name = "day" id = "ig_dayRegistered" class="form-control">
                <option value="">दिन</option>
                <?php for ($i=1; $i < 33; $i++) { 
                  if ($i<10) {
                    echo '<option>0'.$i.'</option>';
                  }else
                    echo '<option>'.$i.'</option>';
                } ?>                  
              </select>
              
            </div>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input type="text" id="Registered_Date" class="form-control" name="Registered_Date" readonly placeholder="DD/MM/YYYY">
            </div>
          </div>
          <div class="item form-group">
            <label for="Scheme_Code" class="control-label col-md-9 col-sm-9 col-xs-12">यो समूह RVWRMP को खानेपानी वा बहुउद्देश्यीय आयोजना अन्तर्गत पर्दछ भने, आयोजनाको कोड</label>
            <div class="col-md-3 col-sm-6 col-xs-6">
              <input id="Scheme_Code" type="text" name="Scheme_Code" class="form-control col-md-7 col-xs-12" placeholder="scheme name if applicable">
            </div>
          </div>
          <div class="item form-group">
            <label class="control-label col-md-12" style="text-align: left;"><u>समुहमा आवद्ध सदस्यहरुको विवरण</u></label>
            <hr>
            <label class="control-label col-md-2 col-sm-9 col-xs-12">दलित महिला</label>
            <div class="col-md-2 col-sm-6 col-xs-6">
              <input id="df1" type="number" min="0" name="df" class="form-control col-md-7 col-xs-12" placeholder="दलित महिला">
            </div>
            <label class="control-label col-md-2 col-sm-9 col-xs-12">दलित पुरुष</label>
            <div class="col-md-2 col-sm-6 col-xs-6">
              <input id="dm1" type="number" min="0" name="dm" class="form-control col-md-7 col-xs-12" placeholder="दलित पुरुष">
            </div>
            <label class="control-label col-md-2 col-sm-9 col-xs-12">जनजाती महिला</label>
            <div class="col-md-2 col-sm-6 col-xs-6">
              <input id="jf1" type="number" min="0" name="jf" class="form-control col-md-7 col-xs-12" placeholder="जनजाती महिला">
            </div>
          </div>
          <div class="item form-group">
            <label class="control-label col-md-2 col-sm-9 col-xs-12">जनजाती पुरुष</label>
            <div class="col-md-2 col-sm-6 col-xs-6">
              <input id="jm1" type="number" min="0" name="jm" class="form-control col-md-7 col-xs-12" placeholder="जनजाती पुरुष">
            </div>
            <label class="control-label col-md-2 col-sm-9 col-xs-12">अन्य महिला</label>
            <div class="col-md-2 col-sm-6 col-xs-6">
              <input id="of1" type="number" min="0" name="of" class="form-control col-md-7 col-xs-12" placeholder="अन्य महिला">
            </div>
            <label class="control-label col-md-2 col-sm-9 col-xs-12">अन्य पुरुष</label>
            <div class="col-md-2 col-sm-6 col-xs-6">
              <input id="om1" type="number" min="0" name="om" class="form-control col-md-7 col-xs-12" placeholder="अन्य पुरुष">
            </div>
          </div>
          <div class="item form-group">
            <label for="ig_others" class="control-label col-md-3 col-sm-6 col-xs-12">यो समूह बारे अन्य केहि बिशेषता/जानकारी</label>
            <div class="col-md-9 col-sm-6 col-xs-12">
              <textarea id="ig_others" name="ig_others" class="form-control col-md-7 col-xs-12" placeholder="other information about the group"></textarea>
            </div>
          </div>
          <div class="ln_solid"></div>
          <div class="form-group">
            <div class="col-md-6 col-md-offset-3">
              <button type="button" id="close_ig" class="btn btn-default">Close</button>
              <button type="submit" id="submit" class="btn btn-success">Submit</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>          
</form>
<form id="frmIGEdit" class="form-horizontal form-label-left" action="<?php echo base_url();?>Ig/saveIGData" method="POST">
    <div class="modal fade bs-example-modal-lg" id="mdlIGEdit" tabindex="-1" role="dialog" aria-hidden="true" style="display: none;">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span>
          </button>
          <h4 class="modal-title" id="myModalLabel2">आयआर्जन विवरण फारम</h4>
        </div>
        <div class="modal-body">
          <div class="item form-group">
            <label class="control-label col-md-3 col-sm-3 col-xs-12 col-sm-3 col-xs-12" for="IG_Info_Type">आयआर्जन विवरण प्रकार <span class="required">*</span>
            </label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <select class="form-control col-md-7 col-xs-12" required="required" name="IG_Info_Type" id="IG_Info_Type_eidt">
                <option value="">छान्नुहोस्</option>
                <option value="Personal">व्यक्तिगत</option>
                <option value="Group">सामुहिक</option>
              </select>
            </div>
            <label class="control-label col-md-3 col-sm-3 col-xs-12 col-sm-3 col-xs-12" for="district">जिल्ला <span class="required">*</span>
            </label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input type="hidden" name="IG_id" value="0" id="IG_id_edit">
              <select class="form-control col-md-7 col-xs-12" required="required" name="IG_district" id="IG_district_eidt">
                <option>जिल्ला छान्नुहोस्</option>
                <option>Achham</option>
                <option>Bajhang</option>
                <option>Baitadi</option>
                <option>Bajura</option>
                <option>Darchula</option>
                <option>Dadeldhura</option>
                <option>Dailekh</option>
                <option>Doti</option>                            
                <option>Humla</option>                   
                <option>Kailali</option>
              </select>
            </div>
          </div>
          <div class="item form-group">
            <label class="control-label col-md-3 col-sm-3 col-xs-12 col-sm-3 col-xs-12" for="IG_rmc">गाउँ/नगरपालिका <span class="required">*</span>
            </label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <select class="form-control col-md-7 col-xs-12" required="required" name="IG_rmc" id="IG_rmc_eidt">
                <option>गाउँ/नगरपालिका छान्नुहोस्</option>
              </select>
            </div>          
            <label class="control-label col-md-3 col-sm-3 col-xs-12 col-sm-3 col-xs-6" for="IG_ward">वार्ड नं. <span class="required">*</span>
            </label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input id="IG_ward_eidt" class="form-control col-md-7 col-xs-12" name="IG_ward" placeholder="ward number" required="required" type="number">
            </div>
          </div>
          <div class="item form-group">
            <label class="control-label col-md-3 col-sm-3 col-xs-12 col-sm-3 col-xs-12" for="IG_clusterName">टोलको नाम <span class="required">*</span>
            </label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input type="text" id="IG_clusterName_eidt" name="IG_clusterName" required class="form-control col-md-7 col-xs-12" placeholder="IG_cluster name">
            </div>
            <label for="Group_Person_Name" class="control-label col-md-3 col-sm-3 col-xs-12">व्यक्ति वा समुहको नाम</label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input id="Group_Person_Name_eidt" type="text" name="Group_Person_Name" class="form-control col-md-7 col-xs-12" required="required" placeholder="HG group name">
            </div>          
          </div>
          <div class="item form-group">
            <label for="Group_Person_Code" class="control-label col-md-3 col-sm-3 col-xs-12">व्यक्ति वा समुहको कोड</label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input id="Group_Person_Code_eidt" type="text" name="Group_Person_Code" class="form-control col-md-7 col-xs-12" required="required" placeholder="group code">
            </div>
          </div>
          <div class="item form-group">
            <label for="Business_Start_Date" class="control-label col-md-3 col-sm-3 col-xs-12">समूह गठन भई तालिम पाएको वा व्यवसाय सुरु भएको मिति</label>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <select name = "year" id = "ig_start_year_eidt" class="form-control">
                <option value="">वर्ष</option>
                <?php for ($i=2067; $i < 2081; $i++) {
                  echo '<option>'.$i.'</option>';
                } ?>
              </select>
            </div>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <select name = "month" id = "ig_start_month_eidt" class="form-control">
                <option value="">महिना</option>
                <?php for ($i=1; $i < 13; $i++) {
                  if ($i<10) {
                    echo '<option>0'.$i.'</option>';
                  }else
                    echo '<option>'.$i.'</option>';
                } ?>                  
              </select>
            </div>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <select name = "day" id = "ig_start_day_eidt" class="form-control">
                <option value="">दिन</option>
                <?php for ($i=1; $i < 33; $i++) { 
                  if ($i<10) {
                    echo '<option>0'.$i.'</option>';
                  }else
                    echo '<option>'.$i.'</option>';
                } ?>                  
              </select>
            </div>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input type = "text" id="Business_Start_Date_eidt" class="form-control" name = "Business_Start_Date" readonly placeholder="DD/MM/YYYY" required>
            </div>
          </div>
          <div class="item form-group">
            <label for="formFilledDate" class="control-label col-md-3 col-sm-3 col-xs-12">यो फारम सुरुमा भरेको मिति</label>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <select name = "year" id = "ig_yearfilled_eidt" class="form-control">
                <option value="">वर्ष</option>
                <?php for ($i=2067; $i < 2081; $i++) {
                  echo '<option>'.$i.'</option>';
                } ?>
              </select>
            </div>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <select name = "month" id = "ig_monthfilled_eidt" class="form-control">
                <option value="">महिना</option>
                <?php for ($i=1; $i < 13; $i++) {
                  if ($i<10) {
                    echo '<option>0'.$i.'</option>';
                  }else
                    echo '<option>'.$i.'</option>';
                } ?>                  
              </select>
            </div>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <select name = "day" id = "ig_dayfilled_eidt" class="form-control">
                <option value="">दिन</option>
                <?php for ($i=1; $i < 33; $i++) { 
                  if ($i<10) {
                    echo '<option>0'.$i.'</option>';
                  }else
                    echo '<option>'.$i.'</option>';
                } ?>                  
              </select>
            </div>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input type = "text" id="ig_formFilledDate_eidt" class="form-control" name = "ig_formFilledDate" readonly placeholder="DD/MM/YYYY" required>
            </div>
          </div>
          <div class="item form-group">
            <label for="Business_Type" class="control-label col-md-3 col-sm-3 col-xs-12">व्यवसायको प्रकृति</label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <select id="Business_Type_eidt" type="text" name="Business_Type" class="form-control col-md-7 col-xs-12" required="required">
                <option value="">छान्नुहोस्</option>
                <option value="Agricultrual">कृषिमा आधारित</option>
                <option value="Processing">प्रशोधनमा आधारित</option>
                <option value="Service Oriented">सेवामुलक</option>
              </select>
            </div>
          
            <label for="IG_Sector" class="control-label col-md-3 col-sm-3 col-xs-12">आयआर्जनको क्षेत्र</label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input id="IG_Sector_eidt" type="text" name="IG_Sector" class="form-control col-md-7 col-xs-12" placeholder="Business Sector" required>
            </div>
          </div>
          <div class="item form-group">
            <label for="ig_savingFund" class="control-label col-md-3 col-sm-3 col-xs-12">हित कोष</label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <select id="ig_savingFund_eidt" type="text" name="ig_savingFund" class="form-control col-md-7 col-xs-12" required="required">
                <option value="">छान्नुहोस्</option>
                <option value="Yes">छ</option>
                <option value="No">छैन</option>
              </select>
            </div>
          
            <label for="ig_fundAmount" class="control-label col-md-3 col-sm-3 col-xs-12">छ भने, हालसम्मको जम्मा रकम</label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input id="ig_fundAmount_eidt" type="text" name="ig_fundAmount" class="form-control col-md-7 col-xs-12" placeholder="total saving fund">
            </div>
          </div>
          <div class="item form-group">
            <label for="Fund_Per_Person" class="control-label col-md-3 col-sm-3 col-xs-12">प्रति महिना प्रति सदस्य रु</label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input id="Fund_Per_Person_eidt" type="text" name="Fund_Per_Person" class="form-control col-md-7 col-xs-12" placeholder="Rs. per person per month">
            </div>
            <label for="ig_coopAffiliation" class="control-label col-md-3 col-sm-3 col-xs-12">के यो समूह सहकारीमा आबद्ध छ</label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <select id="ig_coopAffiliation_eidt" type="text" name="ig_coopAffiliation" class="form-control col-md-7 col-xs-12" required="required">
                <option value="">छान्नुहोस्</option>
                <option value="Yes">छ</option>
                <option value="No">छैन</option>
              </select>
            </div>          
          </div>
          <div class="item form-group">
            <label for="ig_coopName" class="control-label col-md-3 col-sm-3 col-xs-12">छ भने, सहकारीको नाम</label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input id="ig_coopName_eidt" type="text" name="ig_coopName" class="form-control col-md-7 col-xs-12" placeholder="cooperative name">
            </div>
            <label for="ig_coopAddress" class="control-label col-md-3 col-sm-3 col-xs-12">सहकारीको ठेगाना</label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input id="ig_coopAddress_eidt" type="text" name="ig_coopAddress" class="form-control col-md-7 col-xs-12" placeholder="cooperative address">
            </div>            
          </div>
          <div class="item form-group">
            <label for="Loan_From_Coop" class="control-label col-md-3 col-sm-3 col-xs-12">के सहकारीबाट ऋण लिइएको छ</label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <select id="Loan_From_Coop_eidt" type="text" name="Loan_From_Coop" class="form-control col-md-7 col-xs-12" required="required">
                <option value="">छान्नुहोस्</option>
                <option value="Yes">छ</option>
                <option value="No">छैन</option>
              </select>
            </div>
          
            <label for="ig_Registration" class="control-label col-md-3 col-sm-3 col-xs-12">के यो समुह सम्बन्धित निकायमा दर्ता छ</label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <select id="ig_Registration_eidt" type="text" name="ig_Registration" class="form-control col-md-7 col-xs-12" required="required">
                <option value="">छान्नुहोस्</option>
                <option value="Yes">छ</option>
                <option value="No">छैन</option>
              </select>
            </div>
          </div>
          <div class="item form-group">
            <label for="ig_registeredTo" class="control-label col-md-3 col-sm-3 col-xs-12">निकायको नाम</label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input id="ig_registeredTo_eidt" type="text" name="ig_registeredTo" class="form-control col-md-7 col-xs-12" placeholder="registered to">
            </div>
          
            <label for="ig_registrationNo" class="control-label col-md-3 col-sm-3 col-xs-12">दर्ता नं.</label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input id="ig_registrationNo_eidt" type="text" name="ig_registrationNo" class="form-control col-md-7 col-xs-12" placeholder="registration number">
            </div>
          </div>
          <div class="item form-group">
            <label for="Registered_Date" class="control-label col-md-3 col-sm-3 col-xs-12">दर्ता मिति</label>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <select name = "year" id = "ig_yearRegistered_eidt" class="form-control">
                <option value="">वर्ष</option>
                <?php for ($i=2067; $i < 2081; $i++) {
                  echo '<option>'.$i.'</option>';
                } ?>
              </select>
            </div>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <select name = "month" id = "ig_monthRegistered_eidt" class="form-control">
                <option value="">महिना</option>
                <?php for ($i=1; $i < 13; $i++) {
                  if ($i<10) {
                    echo '<option>0'.$i.'</option>';
                  }else
                    echo '<option>'.$i.'</option>';
                } ?>                  
              </select>
            </div>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <select name = "day" id = "ig_dayRegistered_eidt" class="form-control">
                <option value="">दिन</option>
                <?php for ($i=1; $i < 33; $i++) { 
                  if ($i<10) {
                    echo '<option>0'.$i.'</option>';
                  }else
                    echo '<option>'.$i.'</option>';
                } ?>                  
              </select>
              
            </div>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input type="text" id="Registered_Date_eidt" class="form-control" name="Registered_Date" readonly placeholder="DD/MM/YYYY">
            </div>
          </div>
          <div class="item form-group">
            <label for="Scheme_Code" class="control-label col-md-9 col-sm-9 col-xs-12">यो समूह RVWRMP को खानेपानी वा बहुउद्देश्यीय आयोजना अन्तर्गत पर्दछ भने, आयोजनाको कोड</label>
            <div class="col-md-3 col-sm-6 col-xs-6">
              <input id="Scheme_Code_eidt" type="text" name="Scheme_Code" class="form-control col-md-7 col-xs-12" placeholder="scheme name if applicable">
            </div>
          </div>
          <div class="item form-group">
            <label class="control-label col-md-12" style="text-align: left;"><u>समुहमा आवद्ध सदस्यहरुको विवरण</u></label>
            <hr>
            <label class="control-label col-md-2 col-sm-9 col-xs-12">दलित महिला</label>
            <div class="col-md-2 col-sm-6 col-xs-6">
              <input id="df11" type="number" min="0" name="df" class="form-control col-md-7 col-xs-12" placeholder="दलित महिला">
            </div>
            <label class="control-label col-md-2 col-sm-9 col-xs-12">दलित पुरुष</label>
            <div class="col-md-2 col-sm-6 col-xs-6">
              <input id="dm11" type="number" min="0" name="dm" class="form-control col-md-7 col-xs-12" placeholder="दलित पुरुष">
            </div>
            <label class="control-label col-md-2 col-sm-9 col-xs-12">जनजाती महिला</label>
            <div class="col-md-2 col-sm-6 col-xs-6">
              <input id="jf11" type="number" min="0" name="jf" class="form-control col-md-7 col-xs-12" placeholder="जनजाती महिला">
            </div>
          </div>
          <div class="item form-group">
            <label class="control-label col-md-2 col-sm-9 col-xs-12">जनजाती पुरुष</label>
            <div class="col-md-2 col-sm-6 col-xs-6">
              <input id="jm11" type="number" min="0" name="jm" class="form-control col-md-7 col-xs-12" placeholder="जनजाती पुरुष">
            </div>
            <label class="control-label col-md-2 col-sm-9 col-xs-12">अन्य महिला</label>
            <div class="col-md-2 col-sm-6 col-xs-6">
              <input id="of11" type="number" min="0" name="of" class="form-control col-md-7 col-xs-12" placeholder="अन्य महिला">
            </div>
            <label class="control-label col-md-2 col-sm-9 col-xs-12">अन्य पुरुष</label>
            <div class="col-md-2 col-sm-6 col-xs-6">
              <input id="om11" type="number" min="0" name="om" class="form-control col-md-7 col-xs-12" placeholder="अन्य पुरुष">
            </div>
          </div>
          <div class="item form-group">
            <label for="ig_others" class="control-label col-md-3 col-sm-6 col-xs-12">यो समूह बारे अन्य केहि बिशेषता/जानकारी</label>
            <div class="col-md-9 col-sm-6 col-xs-12">
              <textarea id="ig_others_eidt" name="ig_others" class="form-control col-md-7 col-xs-12" placeholder="other information about the group"></textarea>
            </div>
          </div>
          <div class="ln_solid"></div>
          <div class="form-group">
            <div class="col-md-6 col-md-offset-3">
              <button type="button" id="close_ig_edit" class="btn btn-default">Close</button>
              <button type="submit" id="submit" class="btn btn-success">Submit</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>          
</form>
<div class="modal fade bs-example-modal-xl" id="mdlIncome" tabindex="-1" role="dialog" aria-hidden="true" style="display: none;">
    <div class="modal-dialog modal-xl" id="myMdl" style="width: 1140px;">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span>
          </button>
          <h4 class="modal-title">व्यक्ति / आयआर्जन समूह सदस्यले गरेको आम्दानी विवरण</h4>
        </div>
        <div class="modal-body">
          <div id="incomeTable">
            <a href="javascript:void(0)" class="btn btn-success" onclick="addRow()">Add New</a>
            <form id="frmIncome">
              <input type="hidden" name="hgId_income" id="hgId_income" value="0">
              <input type="hidden" name="income_Id" id="income_Id" value="0">
              <table class='table table-bordered table-hover table-striped' id='icTable'>
                <thead>
                  <tr>
                    <th>Member Name</th>
                    <th width="70">HH No</th>
                    <th width="100">Ethnicity</th>
                    <th width="75">Male</th>
                    <th width="75">Female</th>
                    <th width="120">2074/075</th>
                    <th width="120">2075/076</th>
                    <th width="120">2076/077</th>
                    <th width="120">2077/078</th>
                    <th width="120">2078/079</th>
                    <th width="60">#</th>
                  </tr>
                </thead>
                <tbody>
                  
                </tbody>
                <tfoot>
                  <tr>
                    <td colspan="11" style="text-align: center;">
                      <button type="submit" class="btn btn-primary"> Save Data</button>
                    </td>
                  </tr>
                </tfoot>
              </table>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
<!-- Edit Form Here -->
<script type="text/javascript">
  $(document).ready(function() {
    $('#tblIg').DataTable( {
      "scrollY": 400,
      "scrollX": true,
      "ordering": false,
      "lengthChange": false,
      "pageLength" : 10,
       "ordering": false,
       "processing": true,
       "serverSide": true,                 
       "ajax":{
          url :  '<?php echo base_url('Ig/getList'); ?>',
          type : 'POST'
        }
    });

    $('#frmIncome').submit(function(e){
      e.preventDefault();
      let mName = $('#MembersName').val();
      if (mName) {
        let id=$('#hgId_income').val();
        $.ajax({
          url:"<?php echo base_url('Ig/saveIncomeData') ?>",
          method:'POST',
          data: new FormData(this),
          contentType: false,
          cache: false,
          processData: false,
          success: function(data){
            if (data=='Saved') {
                var urltext = '<?php echo base_url();?>Ig/getIncomes/'+id;
                $.ajax({
                    url: urltext,
                    type:'POST',
                    success: function(res){
                      $('#icTable tbody').html(res);
                    }
                });
                alert('Saved Successfully !!');
            }else{
              alert(data);
            }
          }
        });
      }      
    })
  });

  function delMemRow(o){
    var p=o.parentNode.parentNode;
    p.parentNode.removeChild(p);

  }

  $('#close_ig').on('click', function(){
    $('#submit').html('Submit');
    $('#frmIG').trigger("reset");
    $('#mdlIG').modal('hide');
  });

  $('#close_ig_edit').on('click', function(){
    $('#submit').html('Submit');
    $('#frmIGEdit').trigger("reset");
    $('#mdlIGEdit').modal('hide');
  });

  $('#district').change(function(){
      var district = $('#district').val();
      if(district != '')
      {
       $.ajax({
        url:"<?php echo base_url();?>Home/getRM",
        method:"POST",
        data:{district:district},
        success:function(data)
        {
         $('#rmc').html(data);
        }
       });
      }
      {
        $('#rm').html('<option value="">Select RM</option>');
      }
    });

  $('#IG_district').change(function(){
      var district = $('#IG_district').val();
      if(district != '')
      {
       $.ajax({
        url:"<?php echo base_url();?>Home/getRM",
        method:"POST",
        data:{district:district},
        success:function(data)
        {
         $('#IG_rmc').html(data);
        }
       });
      }
      {
        $('#IG_rmc').html('<option value="">Select RM</option>');
      }
    });

    $('#IG_district_eidt').change(function(){
      var district = $('#IG_district_eidt').val();
      if(district != '')
      {
       $.ajax({
        url:"<?php echo base_url();?>Home/getRM",
        method:"POST",
        data:{district:district},
        success:function(data)
        {
         $('#IG_rmc_eidt').html(data);
        }
       });
      }
      {
        $('#IG_rmc_eidt').html('<option value="">Select RM</option>');
      }
    });

  function delFunction(tbl,x,o){
    var urltext = '<?php echo base_url();?>Home/delete/'+tbl+'/'+x;
    var p=o.parentNode.parentNode;
    var c=confirm('Are you sure');
    if(c==true){
      $.ajax({
        url: urltext,
        type: 'POST',
        error: function(){
          alert('Error!! user delete failed');
        },
        success: function(data){
          if (data=='deleted') {
            alert("Record deleted successfull");            
            p.parentNode.removeChild(p);
          }else{
            alert(data);
          }
          
        }
      });
    }        
  }
//======================================================IG Edit From=========================================
  // Business Start Date1
  $('#ig_start_year_eidt').change(function(){
    $('#Business_Start_Date_eidt').val($('#ig_start_day_eidt').val()+'/'+$('#ig_start_month_eidt').val()+'/'+$('#ig_start_year_eidt').val());
  });
  $('#ig_start_month_eidt').change(function(){
    $('#Business_Start_Date_eidt').val($('#ig_start_day_eidt').val()+'/'+$('#ig_start_month_eidt').val()+'/'+$('#ig_start_year_eidt').val());
  });
  $('#ig_start_day_eidt').change(function(){
    $('#Business_Start_Date_eidt').val($('#ig_start_day_eidt').val()+'/'+$('#ig_start_month_eidt').val()+'/'+$('#ig_start_year_eidt').val());
  });
  // Form Filled Date1
  $('#ig_yearfilled_eidt').change(function(){
    $('#ig_formFilledDate_eidt').val($('#ig_dayfilled_eidt').val()+'/'+$('#ig_monthfilled_eidt').val()+'/'+$('#ig_yearfilled_eidt').val());
  });
  $('#ig_monthfilled_eidt').change(function(){
    $('#ig_formFilledDate_eidt').val($('#ig_dayfilled_eidt').val()+'/'+$('#ig_monthfilled_eidt').val()+'/'+$('#ig_yearfilled_eidt').val());
  });
  $('#ig_dayfilled_eidt').change(function(){
    $('#ig_formFilledDate_eidt').val($('#ig_dayfilled_eidt').val()+'/'+$('#ig_monthfilled_eidt').val()+'/'+$('#ig_yearfilled_eidt').val());
  });
  // Registered Date1
  $('#ig_yearRegistered_eidt').change(function(){
    $('#Registered_Date_eidt').val($('#ig_dayRegistered_eidt').val()+'/'+$('#ig_monthRegistered_eidt').val()+'/'+$('#ig_yearRegistered_eidt').val());
  });
  $('#ig_monthRegistered_eidt').change(function(){
    $('#Registered_Date_eidt').val($('#ig_dayRegistered_eidt').val()+'/'+$('#ig_monthRegistered_eidt').val()+'/'+$('#ig_yearRegistered_eidt').val());
  });
  $('#ig_dayRegistered_eidt').change(function(){
    $('#Registered_Date_eidt').val($('#ig_dayRegistered_eidt').val()+'/'+$('#ig_monthRegistered_eidt').val()+'/'+$('#ig_yearRegistered_eidt').val());
  });
//=========================================IG Entry Form=======================================================
  // Business Start Date1
  $('#ig_start_year').change(function(){
    $('#Business_Start_Date').val($('#ig_start_day').val()+'/'+$('#ig_start_month').val()+'/'+$('#ig_start_year').val());
  });
  $('#ig_start_month').change(function(){
    $('#Business_Start_Date').val($('#ig_start_day').val()+'/'+$('#ig_start_month').val()+'/'+$('#ig_start_year').val());
  });
  $('#ig_start_day').change(function(){
    $('#Business_Start_Date').val($('#ig_start_day').val()+'/'+$('#ig_start_month').val()+'/'+$('#ig_start_year').val());
  });
  // Form Filled Date1
  $('#ig_yearfilled').change(function(){
    $('#ig_formFilledDate').val($('#ig_dayfilled').val()+'/'+$('#ig_monthfilled').val()+'/'+$('#ig_yearfilled').val());
  });
  $('#ig_monthfilled').change(function(){
    $('#ig_formFilledDate').val($('#ig_dayfilled').val()+'/'+$('#ig_monthfilled').val()+'/'+$('#ig_yearfilled').val());
  });
  $('#ig_dayfilled').change(function(){
    $('#ig_formFilledDate').val($('#ig_dayfilled').val()+'/'+$('#ig_monthfilled').val()+'/'+$('#ig_yearfilled').val());
  });
  // Registered Date1
  $('#ig_yearRegistered').change(function(){
    $('#Registered_Date').val($('#ig_dayRegistered').val()+'/'+$('#ig_monthRegistered').val()+'/'+$('#ig_yearRegistered').val());
  });
  $('#ig_monthRegistered').change(function(){
    $('#Registered_Date').val($('#ig_dayRegistered').val()+'/'+$('#ig_monthRegistered').val()+'/'+$('#ig_yearRegistered').val());
  });
  $('#ig_dayRegistered').change(function(){
    $('#Registered_Date').val($('#ig_dayRegistered').val()+'/'+$('#ig_monthRegistered').val()+'/'+$('#ig_yearRegistered').val());
  });

function getIncome(id){
    var urltext = '<?php echo base_url();?>Ig/getIncomes/'+id;
    $.ajax({
      url: urltext,
      type:'POST',
      success: function(res){
        $('#icTable tbody').html(res);
        $('#hgId_income').val(id);
        $('#mdlIncome').modal('show');
      }
    });
}

  function getById(tbl,id){
    var urltext = '<?php echo base_url();?>Home/getById/'+tbl+'/'+id;
    $('#IG_id_edit').val(id);
    $.ajax({
      url: urltext,
      type: 'POST',
      dataType: 'json',
      success: function(response){
        var len = response.length; 
        if (len>0) {
          var rm='<option>'+response[0].RM+'</option>';
          $('#IG_Info_Type_eidt').val(response[0].IG_Info_Type);
          $('#IG_district_eidt').val(response[0].District);
          $('#IG_rmc_eidt').html(rm);
          $('#IG_ward_eidt').val(response[0].Ward_No);
          $('#IG_clusterName_eidt').val(response[0].Cluster_Name);
          $('#Group_Person_Name_eidt').val(response[0].Group_Person_Name);
          $('#Group_Person_Code_eidt').val(response[0].Group_Person_Code);
          $('#Business_Start_Date_eidt').val(response[0].Business_Start_Date);
          $('#ig_formFilledDate_eidt').val(response[0].Form_Filled_Date);
          $('#Business_Type_eidt').val(response[0].Business_Type);
          $('#IG_Sector_eidt').val(response[0].IG_Sector);
          $('#ig_savingFund_eidt').val(response[0].Saving_Fund);
          $('#ig_fundAmount_eidt').val(response[0].Fund_Amount);
          $('#Fund_Per_Person_eidt').val(response[0].Fund_Per_Person);
          $('#ig_coopAffiliation_eidt').val(response[0].Coop_Affiliation);
          $('#ig_coopName_eidt').val(response[0].Coop_Name);
          $('#ig_coopAddress_eidt').val(response[0].Coop_Address);
          $('#Loan_From_Coop_eidt').val(response[0].Loan_From_Coop);
          $('#ig_Registration_eidt').val(response[0].Group_Registration);
          $('#ig_registeredTo_eidt').val(response[0].Registered_To);
          $('#ig_registrationNo_eidt').val(response[0].Registration_No);
          $('#Registered_Date_eidt').val(response[0].Registered_Date);
          $('#Scheme_Code_eidt').val(response[0].Scheme_Code);
          $('#df11').val(response[0].DF);
          $('#dm11').val(response[0].DM);
          $('#jf11').val(response[0].JF);
          $('#jm11').val(response[0].JM);
          $('#of11').val(response[0].OF);
          $('#om11').val(response[0].OM);
          $('#ig_others_eidt').val(response[0].Others);
          $('#mdlIGEdit').modal('show');
        }
        else{
          alert('Data not found');
        }         
      }
    });
    
  }
  
  //=======================================================

var flag=0;

  function getIncomeById(id){
    if (flag===1) {
      alert('Please save current data');
    }else{
      var tr="";
      $.ajax({
        url:'<?php echo base_url("Ig/getIncomeById");?>',
        method:"POST",
        data:{id:id},
        success: function(data){
          $('#icTable tbody').append(data);
          flag=1;
        }
      })
    }
    
  }

  function updateIncomeById(){
    var p = $('#particulars').val();
    var fy1 = $('#fy74_75').val();
    var fy2 = $('#fy75_76').val();
    var fy3 = $('#fy76_77').val();
    var fy4 = $('#fy77_78').val();
    var id = $('#editId').val();
    var igId = $('#editIgId').val();

    $.ajax({
      url:'<?php echo base_url("Home/updateIncome") ?>',
      method:"POST",
      data:{id:id, particular:p, f7475:fy1, f7576:fy2, f7677:fy3, f7778:fy4},
      success:function(data){
        if (data=='Saved Successfully' || data=='No Change') {
          getIncomes(igId);
          alert(data);
          flag=0;               
        }else{
            alert(data);
        }
      }
    })
  }

  function getIncomes(id){
    var urltext = '<?php echo base_url();?>Home/getIncomes/'+id;
    $.ajax({
      url: urltext,
      type:'POST',
      success: function(res){
        $('#incomeTable').html(res);
      }
    });
}

function cancelEdit(e){
  var p=e.parentNode.parentNode;
  p.parentNode.removeChild(p);
  flag=0;
}

function addRow(){
  var tbl="";
  tbl +='<tr><td><input type="text" name="MembersName[]" id="MembersName" class="form-control" required></td>';
  tbl +='<td><input type="number" min="0" name="HH_No[]" id="HH_No" class="form-control" required></td>';
  tbl +='<td><select type="text" name="CasteEthnicity[]" id="CasteEthnicity" class="form-control" required><option>Dalit</option><option>Janajati</option><option>Others</option></select></td>';
  tbl +='<td><input type="number" min="0" name="Male[]" id="Male" class="form-control" required></td>';
  tbl +='<td><input type="number" min="0" name="Female[]" id="Female" class="form-control" required></td>';
  tbl +='<td><input type="number" min="0" name="2074_2075[]" id="2074_2075" class="form-control" required></td>';
  tbl +='<td><input type="number" min="0" name="2075_2076[]" id="2075_2076" class="form-control" required></td>';
  tbl +='<td><input type="number" min="0" name="2076_2077[]" id="2076_2077" class="form-control" required></td>';
  tbl +='<td><input type="number" min="0" name="2077_2078[]" id="2077_2079" class="form-control" required></td>';
  tbl +='<td><input type="number" min="0" name="2078_2079[]" id="2078_2079" class="form-control" required></td>';
  tbl +='<td><a href="javascript:void(0)" onclick="cancelEdit(this)"> Cancel</a></td></tr>';

  $('#icTable tbody').append(tbl);
}

// Get Member Income for update ===================
function getMemberIncome(id, obj){
    var mid = id;
    $.ajax({
      url:'<?php echo base_url(); ?>Ig/getIncomeById',
      dataType:'JSON',
      data:{Id:mid},
      method:'POST',
      success: function(data){
        var currentRow=obj.parentNode.parentNode.rowIndex;
        var ronums = $('#icTable tbody tr').length;
        var i;
        var tbl="";
        
        for (var i = 0; i<data.length; i++) {          
          tbl +='<tr><td><input type="hidden" id="income_id" name="income_id" value="'+data[i].Id+'" ><input type="text" name="MembersName[]" id="MembersName" value="'+data[i].MembersName+'" class="form-control" required></td>';
          tbl +='<td><input type="number" min="0" name="HH_No[]" id="HH_No" value="'+data[i].HH_No+'" class="form-control" required></td>';
          tbl +='<td><select type="text" name="CasteEthnicity[]" id="CasteEthnicity" value="'+data[i].CasteEthnicity+'" class="form-control" required><option>Dalit</option><option>Janajati</option><option>Others</option></select></td>';
          tbl +='<td><input type="number" min="0" name="Male[]" id="Male" value="'+data[i].Male+'" class="form-control" required></td>';
          tbl +='<td><input type="number" min="0" name="Female[]" id="Female" value="'+data[i].Female+'" class="form-control" required></td>';
          tbl +='<td><input type="number" min="0" name="2074_2075[]" id="2074_2075" value="'+data[i].FY_2074_2075 +'" class="form-control" required></td>';
          tbl +='<td><input type="number" min="0" name="2075_2076[]" id="2075_2076" value="'+data[i].FY_2075_2076 +'" class="form-control" required></td>';
          tbl +='<td><input type="number" min="0" name="2076_2077[]" id="2076_2077" value="'+data[i].FY_2076_2077 +'" class="form-control" required></td>';
          tbl +='<td><input type="number" min="0" name="2077_2078[]" id="2077_2078" value="'+data[i].FY_2077_2078 +'" class="form-control" required></td>';
          tbl +='<td><input type="number" min="0" name="2078_2079[]" id="2078_2079" value="'+data[i].FY_2078_2079 +'" class="form-control" required></td>';
          tbl +='<td width="60"><a href="javascript:void(0)" onclick="cancelEdit(this)"> Cancel</a></td></tr>';
          if (ronums==currentRow) {
            $("#icTable > tbody").append(tbl);            
          }
          else{
            $('#icTable > tbody > tr').eq(currentRow - 1).after(tbl);
          }
        }
        
      }
    });

  }



</script>