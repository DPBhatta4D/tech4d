<?php defined('BASEPATH') OR exit('No direct script access allowed');
if ($this->session->flashdata('msg')=='success') { ?>
  <script type="text/javascript">
    alert("Saved Successfully");
  </script>
<?php }?>
<link href="<?php echo base_url(); ?>assets/build/css/custom.css" rel="stylesheet">
  <!-- page content -->
  <div class="right_col" role="main" style="min-height: 770px;">
    <div class="" style="margin-top: 40px;">
      <div class="clearfix"></div>
      <div class="row">
       <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel">
              <div class="x_title">
                <h2 style="line-height: 25px;">घरबारी समूह तथा आयआर्जन विवरण</h2>
                  <ul class="nav navbar-right panel_toolbox">
                    <li class="dropdown">
                      <a href="<?php echo base_url(); ?>Reports/HG_IG_Data" role="button" aria-expanded="false"> Download Data <i class="fa fa-cloud-download"></i></a>
                    </li>
                  </ul>             
                <div class="clearfix"></div>
              </div>
              <div class="x_content">
                <div class="" role="tabpanel" data-example-id="togglable-tabs">
                  <ul id="myTab" class="nav nav-tabs bar_tabs" role="tablist">
                    <li role="presentation" class="active"><a href="#tab_content1" id="home-tab" role="tab" data-toggle="tab" aria-expanded="false">घरबारी समूह विवरण</a>
                    </li>
                    <li role="presentation" class=""><a href="#tab_content2" role="tab" id="profile-tab" data-toggle="tab" aria-expanded="false">आयआर्जन विवरण</a>
                    </li>                    
                  </ul>
                  <div id="myTabContent" class="tab-content">
                    <div role="tabpanel" class="tab-pane fade  active in" id="tab_content1" aria-labelledby="home-tab">
                      <div class="x_panel">
                        <div class="x_content" style="overflow-y: hidden; overflow-x: auto;">
                          <br>
                          <table class="table table-bordered table-hover table-striped">
                            <thead>
                              <tr>
                                <th width="170">
                                  <button type="button" class="btn btn-default" data-toggle="modal" data-target="#mdlHG">नयाँ फारम</button>
                                </th>
                                <th width="100">जिल्ला</th>
                                <th width="150">गाउँपालिका</th>
                                <th width="50">वार्ड न.</th>
                                <th width="140">टोलको नाम</th>
                                <th width="160">घरबारी समुहको नाम</th>
                                <th width="100">घरबारी समुहको कोड</th>
                                <th width="100">गठन भएको मिति</th>
                                <th width="100">फारम भरेको मिति</th>
                                <th width="80">हित कोष (छ/छैन)</th>
                                <th width="150">हितकोषमा हालसम्मको जम्मा रकम रु</th>
                                <th width="120">प्रति महिना प्रति सदस्य रु</th>
                                <th width="110">समुहको बैठक बस्ने दिन</th>
                                <th width="110">सहकारीमा आवद्ध छ/छैन</th>
                                <th width="160">आवद्ध भएको सहकारीको नाम</th>
                                <th width="150">सहकारीको ठेगाना</th>
                                <th width="150">सम्बन्धित निकायमा दर्ता छ/छैन</th>
                                <th width="150">निकायको नाम</th>
                                <th width="100">दर्ता नम्बर</th>
                                <th width="100">दर्ता मिति</th>
                                <th width="180">RVWRMP योजना अन्तर्गत भए योजनाको कोड</th>
                                <th width="150">समूह बारे अन्य विशेषता/जानकारी</th>
                              </tr>
                              <tr>
                              </tr>
                            <tbody>
                              <?php
                                foreach ($groups as $group) {
                                  ?>
                                  <tr>
                                    <td width="170">
                                      <a onclick="delFunction('homegarden','<?php echo $group->Id; ?>', this)" href="#">
                                          <span class="fa fa-trash btn btn-danger btn-sm"></span> 
                                      </a>
                                      <a onclick="getById('homegarden',<?php echo $group->Id; ?>)" href="#"><span class="fa fa-pencil btn btn-info btn-sm"></span> 
                                      </a>
                                      <a onclick="addMembers(<?php echo $group->Id; ?>)" href="#"><span class="fa fa-plus btn btn-info btn-sm"> सदस्य</span>
                                      </a>
                                    </td>
                                    <td width="100"><?php echo $group->District; ?></td>
                                    <td width="150"><?php echo $group->RM; ?></td>
                                    <td width="50"><?php echo $group->Ward_No; ?></td>
                                    <td width="140"><?php echo $group->Cluster_Name; ?></td>
                                    <td width="160"><?php echo $group->Group_Name; ?></td>
                                    <td width="100"><?php echo $group->Group_Code; ?></td>
                                    <td width="100"><?php echo $group->Group_Formated_Date; ?></td>
                                    <td width="100"><?php echo $group->Form_Filled_Date; ?></td>
                                    <td width="80"><?php echo $group->Saving_Fund; ?></td>
                                    <td width="150"><?php echo $group->Fund_Amount; ?></td>
                                    <td width="120"><?php echo $group->fundPerPersonPerPerson; ?></td>
                                    <td width="110"><?php echo $group->Meeting_Day; ?></td>
                                    <td width="110"><?php echo $group->Coop_Affiliation; ?></td>
                                    <td width="160"><?php echo $group->Coop_Name; ?></td>
                                    <td width="150"><?php echo $group->Coop_Address; ?></td>
                                    <td width="150"><?php echo $group->Group_Registration; ?></td>
                                    <td width="150"><?php echo $group->Registered_To; ?></td>
                                    <td width="100"><?php echo $group->Registration_No; ?></td>
                                    <td width="100"><?php echo $group->Registered_Date; ?></td>
                                    <td width="180"><?php echo $group->Scheme_Code; ?></td>
                                    <td width="150"><?php echo $group->Others; ?></td>
                                  </tr>
                              <?php
                                }
                              ?>     
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                    <div role="tabpanel" class="tab-pane fade" id="tab_content2" aria-labelledby="home-tab">
                      <div class="x_panel">
                        <div class="x_content" style="overflow-y: hidden; overflow-x: auto;">
                          <br>
                          <table class="table table-bordered table-hover table-striped">
                            <thead>
                              <tr>
                                <th width="165">
                                  <button type="button" class="btn btn-default" data-toggle="modal" data-target="#mdlIG">नयाँ फारम</button>
                                </th>
                                <th width="100">विवरणको प्रकार</th>
                                <th width="100">जिल्ला</th>
                                <th width="150">गाउँपालिका</th>
                                <th width="50">वार्ड न.</th>
                                <th width="140">टोलको नाम</th>
                                <th width="160">सम्बद्ध व्यक्ति/समुहको नाम</th>
                                <th width="100">सम्बद्ध व्यक्ति/ समुहको कोड</th>
                                <th width="150">तालिम पाएको/व्यवसाय सुरु भएको मिति</th>
                                <th width="130">फारम सुरुमा भरेको मिति</th>
                                <th width="130">व्यवसायको प्रकृति</th>
                                <th width="130">आयआर्जनको क्षेत्र</th>
                                <th width="80">हित कोष (छ/छैन)</th>
                                <th width="150">हितकोषमा हालसम्मको जम्मा रकम रु</th>
                                <th width="120">प्रति महिना प्रति सदस्य रु</th>
                                <th width="110">सहकारीमा आवद्ध छ/छैन</th>
                                <th width="160">आवद्ध भएको सहकारीको नाम</th>
                                <th width="150">सहकारीको ठेगाना</th>
                                <th width="150">सहकारीबाट ऋण</th>
                                <th width="150">सम्बन्धित निकायमा दर्ता छ/छैन</th>
                                <th width="150">निकायको नाम</th>
                                <th width="100">दर्ता नं.</th>
                                <th width="100">दर्ता मिति</th>
                                <th width="180">RVWRMP योजना अन्तर्गत भए योजनाको कोड</th>
                                <th width="150">समूह बारे अन्य विशेषता/जानकारी</th>
                              </tr>
                              <tr>
                              </tr>
                            <tbody>
                              <?php
                                foreach ($igs as $group) {
                                  ?>
                                  <tr>
                                    <td width="165">
                                      <a onclick="delFunction('ig_info','<?php echo $group->Id; ?>', this)" href="#">
                                          <span class="fa fa-trash btn btn-danger btn-sm"></span></a>
                                      <a onclick="getById('ig_info',<?php echo $group->Id; ?>)" href="#"><span class="fa fa-pencil btn btn-info btn-sm"></span></a>
                                      <a onclick="getIncome(<?php echo $group->Id; ?>,'<?php echo $group->Group_Person_Name; ?>')" href="#"><span class="btn btn-info btn-sm">आम्दानी</span></a>
                                    </td>
                                    <td width="100"><?php echo $group->IG_Info_Type; ?></td>
                                    <td width="100"><?php echo $group->District; ?></td>
                                    <td width="150"><?php echo $group->RM; ?></td>
                                    <td width="50"><?php echo $group->Ward_No; ?></td>
                                    <td width="140"><?php echo $group->Cluster_Name; ?></td>
                                    <td width="160"><?php echo $group->Group_Person_Name; ?></td>
                                    <td width="100"><?php echo $group->Group_Person_Code; ?></td>
                                    <td width="150"><?php echo $group->Business_Start_Date; ?></td>
                                    <td width="130"><?php echo $group->Form_Filled_Date; ?></td>
                                    <td width="130"><?php echo $group->Business_Type; ?></td>
                                    <td width="130"><?php echo $group->IG_Sector; ?></td>
                                    <td width="80"><?php echo $group->Saving_Fund; ?></td>
                                    <td width="150"><?php echo $group->Fund_Amount; ?></td>
                                    <td width="120"><?php echo $group->Fund_Per_Person; ?></td>
                                    <td width="110"><?php echo $group->Coop_Affiliation; ?></td>
                                    <td width="160"><?php echo $group->Coop_Name; ?></td>
                                    <td width="150"><?php echo $group->Coop_Address; ?></td>
                                    <td width="150"><?php echo $group->Loan_From_Coop; ?></td>
                                    <td width="150"><?php echo $group->Group_Registration; ?></td>
                                    <td width="150"><?php echo $group->Registered_To; ?></td>
                                    <td width="100"><?php echo $group->Registration_No; ?></td>
                                    <td width="100"><?php echo $group->Registered_Date; ?></td>
                                    <td width="180"><?php echo $group->Scheme_Code; ?></td>
                                    <td width="150"><?php echo $group->Others; ?></td>
                                  </tr>
                              <?php
                                }
                              ?>     
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
      </div>
    </div>
  </div>
  <!-- /page content -->
  <form id="frmHG_mem" class="form-horizontal form-label-left">
    <div class="modal fade bs-example-modal-lg" id="mdlHG_mem" tabindex="-1" role="dialog" aria-hidden="true" style="display: none;">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span>
          </button>
          <h4 class="modal-title" id="myModalLabel2">घरवारी समूह सदस्यहरुको विवरण</h4>
        </div>
        <div class="modal-body"><br>
        <input type="hidden" id="hgId" name="hgId" value="0">
        <table style="width:100%; border: solid thin lightgrey;" class="table table-striped table-responsive" id="tblMember">
          <thead style="width:98%;">
            <tr>
              <th>सदस्यको नाम</th>
              <th>दलित महिला</th>
              <th>दलित पुरुष</th>
              <th>जनजाती महिला</th>
              <th>जनजाती पुरुष</th>
              <th>अन्य महिला</th>
              <th>अन्य पुरुष</th>
              <th><a class="btn btn-sm btn-default" href="javascript:void(0)" onclick="addMemRow()"><span class="fa fa-plus"></span></a> </th>
            </tr>
          </thead>
          <tbody>
            
          </tbody>
        </table>
          <div class="ln_solid"></div>
          <div class="form-group">
            <div class="col-md-6 col-md-offset-3">
              <button type="submit" id="submit" class="btn btn-success">Submit</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>          
</form>
  <form id="frmHG" class="form-horizontal form-label-left" action="<?php echo base_url();?>Home/saveHGData" method="POST">
    <div class="modal fade bs-example-modal-lg" id="mdlHG" tabindex="-1" role="dialog" aria-hidden="true" style="display: none;">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span>
          </button>
          <h4 class="modal-title" id="myModalLabel2">घरवारी समूह विवरण फारम</h4>
        </div>
        <div class="modal-body">
          <div class="form-group">
            <label class="control-label col-md-3 col-sm-3 col-xs-12 col-sm-3 col-xs-12" for="district">जिल्ला <span class="required">*</span>
            </label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input type="hidden" name="id" value="0" id="id">
              <select class="form-control col-md-7 col-xs-12" required="required" name="district" id="district">
                <option></option>
                <option>Achham</option>
                <option>Bajhang</option>
                <option>Baitadi</option>
                <option>Bajura</option>
                <option>Darchula</option>
                <option>Dadeldhura</option>
                <option>Dailekh</option>
                <option>Doti</option>                            
                <option>Humla</option>                   
                <option>Kailali</option>
              </select>
            </div>

            <label class="control-label col-md-3 col-sm-3 col-xs-12 col-sm-3 col-xs-12" for="rmc">गाउँ/नगरपालिका <span class="required">*</span>
            </label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <select class="form-control col-md-7 col-xs-12" required="required" name="rmc" id="rmc">
                <option></option>
              </select>
            </div>
          </div>
          <div class="item form-group">
            <label class="control-label col-md-3 col-sm-3 col-xs-12 col-sm-3 col-xs-6" for="ward">वार्ड नं. <span class="required">*</span>
            </label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input id="ward" class="form-control col-md-7 col-xs-12" name="ward" placeholder="ward number" required="required" type="number">
            </div>
            <label class="control-label col-md-3 col-sm-3 col-xs-12 col-sm-3 col-xs-12" for="clusterName">टोलको नाम <span class="required">*</span>
            </label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input type="text" id="clusterName" name="clusterName" required class="form-control col-md-7 col-xs-12" placeholder="cluster name">
            </div>
          </div>
          <div class="item form-group">
            <label for="hgName" class="control-label col-md-3 col-sm-3 col-xs-12">घरवारी समुहको नाम</label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input id="hgName" type="text" name="hgName" class="form-control col-md-7 col-xs-12" required="required" placeholder="HG group name">
            </div>
          
            <label for="hgCode" class="control-label col-md-3 col-sm-3 col-xs-12">घरवारी समुहको कोड</label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input id="hgCode" type="text" name="hgCode" class="form-control col-md-7 col-xs-12" required="required" placeholder="group code">
            </div>
          </div>
          <div class="item form-group">
            <label for="formatedDate" class="control-label col-md-3 col-sm-3 col-xs-12">गठन भएको मिति</label>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <select name = "year" id = "yearformated" class="form-control">
                <option value="">वर्ष</option>
                <?php for ($i=2074; $i < 2081; $i++) {
                  echo '<option>'.$i.'</option>';
                } ?>
              </select>
            </div>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <select name = "month" id = "monthformated" class="form-control">
                <option value="">महिना</option>
                <?php for ($i=1; $i < 13; $i++) {
                  if ($i<10) {
                    echo '<option>0'.$i.'</option>';
                  }else
                    echo '<option>'.$i.'</option>';
                } ?>                  
              </select>
            </div>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <select name = "day" id = "dayformated" class="form-control">
                <option value="">दिन</option>
                <?php for ($i=1; $i < 33; $i++) { 
                  if ($i<10) {
                    echo '<option>0'.$i.'</option>';
                  }else
                    echo '<option>'.$i.'</option>';
                } ?>                  
              </select>
            </div>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input type = "text" id="formatedDate" class="form-control" name = "formatedDate" readonly placeholder="DD/MM/YYYY" required>
            </div>
          </div>
          <div class="item form-group">
            <label for="formFilledDate" class="control-label col-md-3 col-sm-3 col-xs-12">फारम भरेको मिति</label>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <select name = "year" id = "yearfilled" class="form-control">
                <option value="">वर्ष</option>
                <?php for ($i=2074; $i < 2081; $i++) {
                  echo '<option>'.$i.'</option>';
                } ?>
              </select>
            </div>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <select name = "month" id = "monthfilled" class="form-control">
                <option value="">महिना</option>
                <?php for ($i=1; $i < 13; $i++) {
                  if ($i<10) {
                    echo '<option>0'.$i.'</option>';
                  }else
                    echo '<option>'.$i.'</option>';
                } ?>                  
              </select>
            </div>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <select name = "day" id = "dayfilled" class="form-control">
                <option value="">दिन</option>
                <?php for ($i=1; $i < 33; $i++) { 
                  if ($i<10) {
                    echo '<option>0'.$i.'</option>';
                  }else
                    echo '<option>'.$i.'</option>';
                } ?>                  
              </select>
            </div>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input type = "text" id="formFilledDate" class="form-control" name = "formFilledDate" readonly placeholder="DD/MM/YYYY" required>
            </div>
          </div>
          <div class="item form-group">
            <label for="savingFund" class="control-label col-md-3 col-sm-3 col-xs-12">हित कोष</label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <select id="savingFund" type="text" name="savingFund" class="form-control col-md-7 col-xs-12" required="required">
                <option value="">छान्नुहोस्</option>
                <option value="Yes">छ</option>
                <option value="No">छैन</option>
              </select>
            </div>
          
            <label for="fundAmount" class="control-label col-md-3 col-sm-3 col-xs-12">छ भने, हालसम्मको जम्मा रकम</label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input id="fundAmount" type="text" name="fundAmount" class="form-control col-md-7 col-xs-12" placeholder="total saving fund">
            </div>
          </div>
          <div class="item form-group">
            <label for="fundPerPersonPerPerson" class="control-label col-md-3 col-sm-3 col-xs-12">प्रति महिना प्रति सदस्य रु</label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input id="fundPerPersonPerPerson" type="text" name="fundPerPersonPerPerson" class="form-control col-md-7 col-xs-12" placeholder="Rs. per person per month">
            </div>
          
            <label for="meetingDay" class="control-label col-md-3 col-sm-3 col-xs-12">यो समुहको बैठक बस्ने दिन</label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input id="meetingDay" type="text" name="meetingDay" class="form-control col-md-7 col-xs-12" required="required" placeholder="meeting day">
            </div>
          </div>
          <div class="item form-group">
            <label for="coopAffiliation" class="control-label col-md-3 col-sm-3 col-xs-12">के यो समूह सहकारीमा आबद्ध छ</label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <select id="coopAffiliation" type="text" name="coopAffiliation" class="form-control col-md-7 col-xs-12" required="required">
                <option value="">छान्नुहोस्</option>
                <option value="Yes">छ</option>
                <option value="No">छैन</option>
              </select>
            </div>
          
            <label for="coopName" class="control-label col-md-3 col-sm-3 col-xs-12">छ भने, सहकारीको नाम</label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input id="coopName" type="text" name="coopName" class="form-control col-md-7 col-xs-12" placeholder="cooperative name">
            </div>
          </div>
          <div class="item form-group">
            <label for="coopAddress" class="control-label col-md-3 col-sm-3 col-xs-12">सहकारीको ठेगाना</label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input id="coopAddress" type="text" name="coopAddress" class="form-control col-md-7 col-xs-12" placeholder="cooperative address">
            </div>
          
            <label for="hgRegistration" class="control-label col-md-3 col-sm-3 col-xs-12">के यो समुह सम्बन्धित निकायमा दर्ता छ</label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <select id="hgRegistration" type="text" name="hgRegistration" class="form-control col-md-7 col-xs-12" required="required">
                <option value="">छान्नुहोस्</option>
                <option value="Yes">छ</option>
                <option value="No">छैन</option>
              </select>
            </div>
          </div>
          <div class="item form-group">
            <label for="registeredTo" class="control-label col-md-3 col-sm-3 col-xs-12">निकायको नाम</label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input id="registeredTo" type="text" name="registeredTo" class="form-control col-md-7 col-xs-12" placeholder="registered to">
            </div>
          
            <label for="registrationNo" class="control-label col-md-3 col-sm-3 col-xs-12">दर्ता नं.</label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input id="registrationNo" type="text" name="registrationNo" class="form-control col-md-7 col-xs-12" placeholder="registration number">
            </div>
          </div>
          <div class="item form-group">
            <label for="registrationDate" class="control-label col-md-3 col-sm-3 col-xs-12">दर्ता मिति</label>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <select name = "year" id = "yearRegistered" class="form-control">
                <option value="">वर्ष</option>
                <?php for ($i=2074; $i < 2081; $i++) {
                  echo '<option>'.$i.'</option>';
                } ?>
              </select>
            </div>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <select name = "month" id = "monthRegistered" class="form-control">
                <option value="">महिना</option>
                <?php for ($i=1; $i < 13; $i++) {
                  if ($i<10) {
                    echo '<option>0'.$i.'</option>';
                  }else
                    echo '<option>'.$i.'</option>';
                } ?>                  
              </select>
            </div>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <select name = "day" id = "dayRegistered" class="form-control">
                <option value="">दिन</option>
                <?php for ($i=1; $i < 33; $i++) { 
                  if ($i<10) {
                    echo '<option>0'.$i.'</option>';
                  }else
                    echo '<option>'.$i.'</option>';
                } ?>                  
              </select>
              
            </div>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input type="text" id="registrationDate" class="form-control" name="registrationDate" readonly placeholder="DD/MM/YYYY">
            </div>
          </div>
          <div class="item form-group">
            <label for="schemeName" class="control-label col-md-9 col-sm-9 col-xs-12">यो समूह RVWRMP को खानेपानी वा बहुउद्देश्यीय आयोजना अन्तर्गत पर्दछ भने, आयोजनाको कोड</label>
            <div class="col-md-3 col-sm-6 col-xs-6">
              <input id="schemeName" type="text" name="schemeName" class="form-control col-md-7 col-xs-12" placeholder="scheme name if applicable">
            </div>
          </div>
          <div class="item form-group">
            <label class="control-label col-md-12" style="text-align: left;"><u>समुहमा आवद्ध सदस्यहरुको विवरण</u></label>
            <hr>
            <label class="control-label col-md-2 col-sm-9 col-xs-12">दलित महिला</label>
            <div class="col-md-2 col-sm-6 col-xs-6">
              <input id="df" type="number" name="df" class="form-control col-md-7 col-xs-12" placeholder="दलित महिला">
            </div>
            <label class="control-label col-md-2 col-sm-9 col-xs-12">दलित पुरुष</label>
            <div class="col-md-2 col-sm-6 col-xs-6">
              <input id="dm" type="number" name="dm" class="form-control col-md-7 col-xs-12" placeholder="दलित पुरुष">
            </div>
            <label class="control-label col-md-2 col-sm-9 col-xs-12">जनजाती महिला</label>
            <div class="col-md-2 col-sm-6 col-xs-6">
              <input id="jf" type="number" name="jf" class="form-control col-md-7 col-xs-12" placeholder="जनजाती महिला">
            </div>
          </div>
          <div class="item form-group">
            <label class="control-label col-md-2 col-sm-9 col-xs-12">जनजाती पुरुष</label>
            <div class="col-md-2 col-sm-6 col-xs-6">
              <input id="jm" type="number" name="jm" class="form-control col-md-7 col-xs-12" placeholder="जनजाती पुरुष">
            </div>
            <label class="control-label col-md-2 col-sm-9 col-xs-12">अन्य महिला</label>
            <div class="col-md-2 col-sm-6 col-xs-6">
              <input id="of" type="number" name="of" class="form-control col-md-7 col-xs-12" placeholder="अन्य महिला">
            </div>
            <label class="control-label col-md-2 col-sm-9 col-xs-12">अन्य पुरुष</label>
            <div class="col-md-2 col-sm-6 col-xs-6">
              <input id="om" type="number" name="om" class="form-control col-md-7 col-xs-12" placeholder="अन्य पुरुष">
            </div>
          </div>
          <div class="item form-group">
            <label for="others" class="control-label col-md-3 col-sm-6 col-xs-12">यो समूह बारे अन्य केहि बिशेषता/जानकारी</label>
            <div class="col-md-9 col-sm-6 col-xs-12">
              <textarea id="others" name="others" class="form-control col-md-7 col-xs-12" placeholder="other information about the group"></textarea>
            </div>
          </div>
          <div class="ln_solid"></div>
          <div class="form-group">
            <div class="col-md-6 col-md-offset-3">
              <button type="button" id="close" class="btn btn-default">Close</button>
              <button type="submit" id="submit" class="btn btn-success">Submit</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>          
</form>

<form id="frmIG" class="form-horizontal form-label-left" action="<?php echo base_url();?>Home/saveIGData" method="POST">
    <div class="modal fade bs-example-modal-lg" id="mdlIG" tabindex="-1" role="dialog" aria-hidden="true" style="display: none;">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span>
          </button>
          <h4 class="modal-title" id="myModalLabel2">आयआर्जन विवरण फारम</h4>
        </div>
        <div class="modal-body">
          <div class="item form-group">
            <label class="control-label col-md-3 col-sm-3 col-xs-12 col-sm-3 col-xs-12" for="IG_Info_Type">आयआर्जन विवरण प्रकार <span class="required">*</span>
            </label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <select class="form-control col-md-7 col-xs-12" required="required" name="IG_Info_Type" id="IG_Info_Type">
                <option value="">छान्नुहोस्</option>
                <option value="Personal">व्यक्तिगत</option>
                <option value="Group">सामुहिक</option>
              </select>
            </div>
            <label class="control-label col-md-3 col-sm-3 col-xs-12 col-sm-3 col-xs-12" for="district">जिल्ला <span class="required">*</span>
            </label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input type="hidden" name="IG_id" value="0" id="IG_id">
              <select class="form-control col-md-7 col-xs-12" required="required" name="IG_district" id="IG_district">
                <option>जिल्ला छान्नुहोस्</option>
                <option>Achham</option>
                <option>Bajhang</option>
                <option>Baitadi</option>
                <option>Bajura</option>
                <option>Darchula</option>
                <option>Dadeldhura</option>
                <option>Dailekh</option>
                <option>Doti</option>                            
                <option>Humla</option>                   
                <option>Kailali</option>
              </select>
            </div>
          </div>
          <div class="item form-group">
            <label class="control-label col-md-3 col-sm-3 col-xs-12 col-sm-3 col-xs-12" for="IG_rmc">गाउँ/नगरपालिका <span class="required">*</span>
            </label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <select class="form-control col-md-7 col-xs-12" required="required" name="IG_rmc" id="IG_rmc">
                <option>गाउँ/नगरपालिका छान्नुहोस्</option>
              </select>
            </div>          
            <label class="control-label col-md-3 col-sm-3 col-xs-12 col-sm-3 col-xs-6" for="IG_ward">वार्ड नं. <span class="required">*</span>
            </label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input id="IG_ward" class="form-control col-md-7 col-xs-12" name="IG_ward" placeholder="ward number" required="required" type="number">
            </div>
          </div>
          <div class="item form-group">
            <label class="control-label col-md-3 col-sm-3 col-xs-12 col-sm-3 col-xs-12" for="IG_clusterName">टोलको नाम <span class="required">*</span>
            </label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input type="text" id="IG_clusterName" name="IG_clusterName" required class="form-control col-md-7 col-xs-12" placeholder="IG_cluster name">
            </div>
            <label for="Group_Person_Name" class="control-label col-md-3 col-sm-3 col-xs-12">व्यक्ति वा समुहको नाम</label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input id="Group_Person_Name" type="text" name="Group_Person_Name" class="form-control col-md-7 col-xs-12" required="required" placeholder="HG group name">
            </div>          
          </div>
          <div class="item form-group">
            <label for="Group_Person_Code" class="control-label col-md-3 col-sm-3 col-xs-12">व्यक्ति वा समुहको कोड</label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input id="Group_Person_Code" type="text" name="Group_Person_Code" class="form-control col-md-7 col-xs-12" required="required" placeholder="group code">
            </div>
          </div>
          <div class="item form-group">
            <label for="Business_Start_Date" class="control-label col-md-3 col-sm-3 col-xs-12">समूह गठन भई तालिम पाएको वा व्यवसाय सुरु भएको मिति</label>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <select name = "year" id = "ig_start_year" class="form-control">
                <option value="">वर्ष</option>
                <?php for ($i=2074; $i < 2081; $i++) {
                  echo '<option>'.$i.'</option>';
                } ?>
              </select>
            </div>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <select name = "month" id = "ig_start_month" class="form-control">
                <option value="">महिना</option>
                <?php for ($i=1; $i < 13; $i++) {
                  if ($i<10) {
                    echo '<option>0'.$i.'</option>';
                  }else
                    echo '<option>'.$i.'</option>';
                } ?>                  
              </select>
            </div>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <select name = "day" id = "ig_start_day" class="form-control">
                <option value="">दिन</option>
                <?php for ($i=1; $i < 33; $i++) { 
                  if ($i<10) {
                    echo '<option>0'.$i.'</option>';
                  }else
                    echo '<option>'.$i.'</option>';
                } ?>                  
              </select>
            </div>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input type = "text" id="Business_Start_Date" class="form-control" name = "Business_Start_Date" readonly placeholder="DD/MM/YYYY" required>
            </div>
          </div>
          <div class="item form-group">
            <label for="formFilledDate" class="control-label col-md-3 col-sm-3 col-xs-12">यो फारम सुरुमा भरेको मिति</label>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <select name = "year" id = "ig_yearfilled" class="form-control">
                <option value="">वर्ष</option>
                <?php for ($i=2074; $i < 2081; $i++) {
                  echo '<option>'.$i.'</option>';
                } ?>
              </select>
            </div>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <select name = "month" id = "ig_monthfilled" class="form-control">
                <option value="">महिना</option>
                <?php for ($i=1; $i < 13; $i++) {
                  if ($i<10) {
                    echo '<option>0'.$i.'</option>';
                  }else
                    echo '<option>'.$i.'</option>';
                } ?>                  
              </select>
            </div>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <select name = "day" id = "ig_dayfilled" class="form-control">
                <option value="">दिन</option>
                <?php for ($i=1; $i < 33; $i++) { 
                  if ($i<10) {
                    echo '<option>0'.$i.'</option>';
                  }else
                    echo '<option>'.$i.'</option>';
                } ?>                  
              </select>
            </div>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input type = "text" id="ig_formFilledDate" class="form-control" name = "ig_formFilledDate" readonly placeholder="DD/MM/YYYY" required>
            </div>
          </div>
          <div class="item form-group">
            <label for="Business_Type" class="control-label col-md-3 col-sm-3 col-xs-12">व्यवसायको प्रकृति</label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <select id="Business_Type" type="text" name="Business_Type" class="form-control col-md-7 col-xs-12" required="required">
                <option value="">छान्नुहोस्</option>
                <option value="Agricultrual">कृषिमा आधारित</option>
                <option value="Processing">प्रशोधनमा आधारित</option>
                <option value="Service Oriented">सेवामुलक</option>
              </select>
            </div>
          
            <label for="IG_Sector" class="control-label col-md-3 col-sm-3 col-xs-12">आयआर्जनको क्षेत्र</label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input id="IG_Sector" type="text" name="IG_Sector" class="form-control col-md-7 col-xs-12" placeholder="Business Sector" required>
            </div>
          </div>
          <div class="item form-group">
            <label for="ig_savingFund" class="control-label col-md-3 col-sm-3 col-xs-12">हित कोष</label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <select id="ig_savingFund" type="text" name="ig_savingFund" class="form-control col-md-7 col-xs-12" required="required">
                <option value="">छान्नुहोस्</option>
                <option value="Yes">छ</option>
                <option value="No">छैन</option>
              </select>
            </div>
          
            <label for="ig_fundAmount" class="control-label col-md-3 col-sm-3 col-xs-12">छ भने, हालसम्मको जम्मा रकम</label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input id="ig_fundAmount" type="text" name="ig_fundAmount" class="form-control col-md-7 col-xs-12" placeholder="total saving fund">
            </div>
          </div>
          <div class="item form-group">
            <label for="Fund_Per_Person" class="control-label col-md-3 col-sm-3 col-xs-12">प्रति महिना प्रति सदस्य रु</label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input id="Fund_Per_Person" type="text" name="Fund_Per_Person" class="form-control col-md-7 col-xs-12" placeholder="Rs. per person per month">
            </div>
            <label for="ig_coopAffiliation" class="control-label col-md-3 col-sm-3 col-xs-12">के यो समूह सहकारीमा आबद्ध छ</label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <select id="ig_coopAffiliation" type="text" name="ig_coopAffiliation" class="form-control col-md-7 col-xs-12" required="required">
                <option value="">छान्नुहोस्</option>
                <option value="Yes">छ</option>
                <option value="No">छैन</option>
              </select>
            </div>          
          </div>
          <div class="item form-group">
            <label for="ig_coopName" class="control-label col-md-3 col-sm-3 col-xs-12">छ भने, सहकारीको नाम</label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input id="ig_coopName" type="text" name="ig_coopName" class="form-control col-md-7 col-xs-12" placeholder="cooperative name">
            </div>
            <label for="ig_coopAddress" class="control-label col-md-3 col-sm-3 col-xs-12">सहकारीको ठेगाना</label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input id="ig_coopAddress" type="text" name="ig_coopAddress" class="form-control col-md-7 col-xs-12" placeholder="cooperative address">
            </div>            
          </div>
          <div class="item form-group">
            <label for="Loan_From_Coop" class="control-label col-md-3 col-sm-3 col-xs-12">के सहकारीबाट ऋण लिइएको छ</label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <select id="Loan_From_Coop" type="text" name="Loan_From_Coop" class="form-control col-md-7 col-xs-12" required="required">
                <option value="">छान्नुहोस्</option>
                <option value="Yes">छ</option>
                <option value="No">छैन</option>
              </select>
            </div>
          
            <label for="ig_Registration" class="control-label col-md-3 col-sm-3 col-xs-12">के यो समुह सम्बन्धित निकायमा दर्ता छ</label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <select id="ig_Registration" type="text" name="ig_Registration" class="form-control col-md-7 col-xs-12" required="required">
                <option value="">छान्नुहोस्</option>
                <option value="Yes">छ</option>
                <option value="No">छैन</option>
              </select>
            </div>
          </div>
          <div class="item form-group">
            <label for="ig_registeredTo" class="control-label col-md-3 col-sm-3 col-xs-12">निकायको नाम</label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input id="ig_registeredTo" type="text" name="ig_registeredTo" class="form-control col-md-7 col-xs-12" placeholder="registered to">
            </div>
          
            <label for="ig_registrationNo" class="control-label col-md-3 col-sm-3 col-xs-12">दर्ता नं.</label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input id="ig_registrationNo" type="text" name="ig_registrationNo" class="form-control col-md-7 col-xs-12" placeholder="registration number">
            </div>
          </div>
          <div class="item form-group">
            <label for="Registered_Date" class="control-label col-md-3 col-sm-3 col-xs-12">दर्ता मिति</label>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <select name = "year" id = "ig_yearRegistered" class="form-control">
                <option value="">वर्ष</option>
                <?php for ($i=2074; $i < 2081; $i++) {
                  echo '<option>'.$i.'</option>';
                } ?>
              </select>
            </div>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <select name = "month" id = "ig_monthRegistered" class="form-control">
                <option value="">महिना</option>
                <?php for ($i=1; $i < 13; $i++) {
                  if ($i<10) {
                    echo '<option>0'.$i.'</option>';
                  }else
                    echo '<option>'.$i.'</option>';
                } ?>                  
              </select>
            </div>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <select name = "day" id = "ig_dayRegistered" class="form-control">
                <option value="">दिन</option>
                <?php for ($i=1; $i < 33; $i++) { 
                  if ($i<10) {
                    echo '<option>0'.$i.'</option>';
                  }else
                    echo '<option>'.$i.'</option>';
                } ?>                  
              </select>
              
            </div>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input type="text" id="Registered_Date" class="form-control" name="Registered_Date" readonly placeholder="DD/MM/YYYY">
            </div>
          </div>
          <div class="item form-group">
            <label for="Scheme_Code" class="control-label col-md-9 col-sm-9 col-xs-12">यो समूह RVWRMP को खानेपानी वा बहुउद्देश्यीय आयोजना अन्तर्गत पर्दछ भने, आयोजनाको कोड</label>
            <div class="col-md-3 col-sm-6 col-xs-6">
              <input id="Scheme_Code" type="text" name="Scheme_Code" class="form-control col-md-7 col-xs-12" placeholder="scheme name if applicable">
            </div>
          </div>
          <div class="item form-group">
            <label class="control-label col-md-12" style="text-align: left;"><u>समुहमा आवद्ध सदस्यहरुको विवरण</u></label>
            <hr>
            <label class="control-label col-md-2 col-sm-9 col-xs-12">दलित महिला</label>
            <div class="col-md-2 col-sm-6 col-xs-6">
              <input id="df1" type="number" name="df" class="form-control col-md-7 col-xs-12" placeholder="दलित महिला">
            </div>
            <label class="control-label col-md-2 col-sm-9 col-xs-12">दलित पुरुष</label>
            <div class="col-md-2 col-sm-6 col-xs-6">
              <input id="dm1" type="number" name="dm" class="form-control col-md-7 col-xs-12" placeholder="दलित पुरुष">
            </div>
            <label class="control-label col-md-2 col-sm-9 col-xs-12">जनजाती महिला</label>
            <div class="col-md-2 col-sm-6 col-xs-6">
              <input id="jf1" type="number" name="jf" class="form-control col-md-7 col-xs-12" placeholder="जनजाती महिला">
            </div>
          </div>
          <div class="item form-group">
            <label class="control-label col-md-2 col-sm-9 col-xs-12">जनजाती पुरुष</label>
            <div class="col-md-2 col-sm-6 col-xs-6">
              <input id="jm1" type="number" name="jm" class="form-control col-md-7 col-xs-12" placeholder="जनजाती पुरुष">
            </div>
            <label class="control-label col-md-2 col-sm-9 col-xs-12">अन्य महिला</label>
            <div class="col-md-2 col-sm-6 col-xs-6">
              <input id="of1" type="number" name="of" class="form-control col-md-7 col-xs-12" placeholder="अन्य महिला">
            </div>
            <label class="control-label col-md-2 col-sm-9 col-xs-12">अन्य पुरुष</label>
            <div class="col-md-2 col-sm-6 col-xs-6">
              <input id="om1" type="number" name="om" class="form-control col-md-7 col-xs-12" placeholder="अन्य पुरुष">
            </div>
          </div>
          <div class="item form-group">
            <label for="ig_others" class="control-label col-md-3 col-sm-6 col-xs-12">यो समूह बारे अन्य केहि बिशेषता/जानकारी</label>
            <div class="col-md-9 col-sm-6 col-xs-12">
              <textarea id="ig_others" name="ig_others" class="form-control col-md-7 col-xs-12" placeholder="other information about the group"></textarea>
            </div>
          </div>
          <div class="ln_solid"></div>
          <div class="form-group">
            <h4 class="col-md-6" style="margin-bottom: -10px;margin-top: -10px;">समूह वा व्यक्तिले प्रत्येक आ.व.मा गरेको आम्दानी (रु.)</h4>
          </div>
          <div class="form-group">
            <label class="control-label col-md-3 col-sm-6 col-xs-12">विवरण</label>
            <label class="control-label col-md-2 col-sm-6 col-xs-12">आ.व. २०७४/७५</label>
            <label class="control-label col-md-2 col-sm-6 col-xs-12">आ.व. २०७५/७६</label>
            <label class="control-label col-md-2 col-sm-6 col-xs-12">आ.व. २०७६/७७</label>
            <label class="control-label col-md-2 col-sm-6 col-xs-12">आ.व. २०७७/७८</label>
            <div class="ln_solid" style="margin-top: 4px;"></div>
            <div class="ln_solid"></div>
            <div class="row" style="margin-top: -10px;">
              <div class="col-md-12" >
                <p class="control-label col-md-3">समुहगत वा व्यक्तिगत जम्मा रु.</p>
                <input type="hidden" name="particulars[]" value="Total Income">
                <div class="col-md-2">
                  <input type="text" name="fy74_75[]" class="form-control col-md-2" style="text-align: right;">
                </div>
                <div class="col-md-2">
                  <input type="text" name="fy75_76[]" class="form-control col-md-2" style="text-align: right;">
                </div>
                <div class="col-md-2">
                  <input type="text" name="fy76_77[]" class="form-control col-md-2" style="text-align: right;">
                </div>
                <div class="col-md-2">
                  <input type="text" name="fy77_78[]" class="form-control col-md-2" style="text-align: right;">
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-12">
                <p class="control-label col-md-3 col-sm-6 col-xs-12">प्रति व्यक्ति औषत रु.</p>
                <input type="hidden" name="particulars[]" value="Average Per Person Income">
                <div class="col-md-2">
                  <input type="text" name="fy74_75[]" class="form-control col-md-2" style="text-align: right;">
                </div>
                <div class="col-md-2">
                  <input type="text" name="fy75_76[]" class="form-control col-md-2" style="text-align: right;">
                </div>
                <div class="col-md-2">
                  <input type="text" name="fy76_77[]" class="form-control col-md-2" style="text-align: right;">
                </div>
                <div class="col-md-2">
                  <input type="text" name="fy77_78[]" class="form-control col-md-2" style="text-align: right;">
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-12">
                <p class="control-label col-md-3 col-sm-6 col-xs-12">सबै भन्दा कम आम्दानी गर्ने रु.</p>
                <input type="hidden" name="particulars[]" value="Least Income">
                <div class="col-md-2">
                  <input type="text" name="fy74_75[]" class="form-control col-md-2" style="text-align: right;">
                </div>
                <div class="col-md-2">
                  <input type="text" name="fy75_76[]" class="form-control col-md-2" style="text-align: right;">
                </div>
                <div class="col-md-2">
                  <input type="text" name="fy76_77[]" class="form-control col-md-2" style="text-align: right;">
                </div>
                <div class="col-md-2">
                  <input type="text" name="fy77_78[]" class="form-control col-md-2" style="text-align: right;">
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-12">
                <p class="control-label col-md-3 col-sm-6 col-xs-12">सबै भन्दा बढी आम्दानी गर्ने रु.</p>
                <input type="hidden" name="particulars[]" value="Max Income">
                <div class="col-md-2">
                  <input type="text" name="fy74_75[]" class="form-control col-md-2" style="text-align: right;">
                </div>
                <div class="col-md-2">
                  <input type="text" name="fy75_76[]" class="form-control col-md-2" style="text-align: right;">
                </div>
                <div class="col-md-2">
                  <input type="text" name="fy76_77[]" class="form-control col-md-2" style="text-align: right;">
                </div>
                <div class="col-md-2">
                  <input type="text" name="fy77_78[]" class="form-control col-md-2" style="text-align: right;">
                </div>
              </div>
            </div>
          </div>
          <div class="ln_solid"></div>
          <div class="form-group">
            <div class="col-md-6 col-md-offset-3">
              <button type="button" id="close_ig" class="btn btn-default">Close</button>
              <button type="submit" id="submit" class="btn btn-success">Submit</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>          
</form>
<form id="frmIGEdit" class="form-horizontal form-label-left" action="<?php echo base_url();?>Home/saveIGData" method="POST">
    <div class="modal fade bs-example-modal-lg" id="mdlIGEdit" tabindex="-1" role="dialog" aria-hidden="true" style="display: none;">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span>
          </button>
          <h4 class="modal-title" id="myModalLabel2">आयआर्जन विवरण फारम</h4>
        </div>
        <div class="modal-body">
          <div class="item form-group">
            <label class="control-label col-md-3 col-sm-3 col-xs-12 col-sm-3 col-xs-12" for="IG_Info_Type">आयआर्जन विवरण प्रकार <span class="required">*</span>
            </label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <select class="form-control col-md-7 col-xs-12" required="required" name="IG_Info_Type" id="IG_Info_Type_eidt">
                <option value="">छान्नुहोस्</option>
                <option value="Personal">व्यक्तिगत</option>
                <option value="Group">सामुहिक</option>
              </select>
            </div>
            <label class="control-label col-md-3 col-sm-3 col-xs-12 col-sm-3 col-xs-12" for="district">जिल्ला <span class="required">*</span>
            </label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input type="hidden" name="IG_id" value="0" id="IG_id_edit">
              <select class="form-control col-md-7 col-xs-12" required="required" name="IG_district" id="IG_district_eidt">
                <option>जिल्ला छान्नुहोस्</option>
                <option>Achham</option>
                <option>Bajhang</option>
                <option>Baitadi</option>
                <option>Bajura</option>
                <option>Darchula</option>
                <option>Dadeldhura</option>
                <option>Dailekh</option>
                <option>Doti</option>                            
                <option>Humla</option>                   
                <option>Kailali</option>
              </select>
            </div>
          </div>
          <div class="item form-group">
            <label class="control-label col-md-3 col-sm-3 col-xs-12 col-sm-3 col-xs-12" for="IG_rmc">गाउँ/नगरपालिका <span class="required">*</span>
            </label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <select class="form-control col-md-7 col-xs-12" required="required" name="IG_rmc" id="IG_rmc_eidt">
                <option>गाउँ/नगरपालिका छान्नुहोस्</option>
              </select>
            </div>          
            <label class="control-label col-md-3 col-sm-3 col-xs-12 col-sm-3 col-xs-6" for="IG_ward">वार्ड नं. <span class="required">*</span>
            </label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input id="IG_ward_eidt" class="form-control col-md-7 col-xs-12" name="IG_ward" placeholder="ward number" required="required" type="number">
            </div>
          </div>
          <div class="item form-group">
            <label class="control-label col-md-3 col-sm-3 col-xs-12 col-sm-3 col-xs-12" for="IG_clusterName">टोलको नाम <span class="required">*</span>
            </label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input type="text" id="IG_clusterName_eidt" name="IG_clusterName" required class="form-control col-md-7 col-xs-12" placeholder="IG_cluster name">
            </div>
            <label for="Group_Person_Name" class="control-label col-md-3 col-sm-3 col-xs-12">व्यक्ति वा समुहको नाम</label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input id="Group_Person_Name_eidt" type="text" name="Group_Person_Name" class="form-control col-md-7 col-xs-12" required="required" placeholder="HG group name">
            </div>          
          </div>
          <div class="item form-group">
            <label for="Group_Person_Code" class="control-label col-md-3 col-sm-3 col-xs-12">व्यक्ति वा समुहको कोड</label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input id="Group_Person_Code_eidt" type="text" name="Group_Person_Code" class="form-control col-md-7 col-xs-12" required="required" placeholder="group code">
            </div>
          </div>
          <div class="item form-group">
            <label for="Business_Start_Date" class="control-label col-md-3 col-sm-3 col-xs-12">समूह गठन भई तालिम पाएको वा व्यवसाय सुरु भएको मिति</label>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <select name = "year" id = "ig_start_year_eidt" class="form-control">
                <option value="">वर्ष</option>
                <?php for ($i=2074; $i < 2081; $i++) {
                  echo '<option>'.$i.'</option>';
                } ?>
              </select>
            </div>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <select name = "month" id = "ig_start_month_eidt" class="form-control">
                <option value="">महिना</option>
                <?php for ($i=1; $i < 13; $i++) {
                  if ($i<10) {
                    echo '<option>0'.$i.'</option>';
                  }else
                    echo '<option>'.$i.'</option>';
                } ?>                  
              </select>
            </div>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <select name = "day" id = "ig_start_day_eidt" class="form-control">
                <option value="">दिन</option>
                <?php for ($i=1; $i < 33; $i++) { 
                  if ($i<10) {
                    echo '<option>0'.$i.'</option>';
                  }else
                    echo '<option>'.$i.'</option>';
                } ?>                  
              </select>
            </div>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input type = "text" id="Business_Start_Date_eidt" class="form-control" name = "Business_Start_Date" readonly placeholder="DD/MM/YYYY" required>
            </div>
          </div>
          <div class="item form-group">
            <label for="formFilledDate" class="control-label col-md-3 col-sm-3 col-xs-12">यो फारम सुरुमा भरेको मिति</label>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <select name = "year" id = "ig_yearfilled_eidt" class="form-control">
                <option value="">वर्ष</option>
                <?php for ($i=2074; $i < 2081; $i++) {
                  echo '<option>'.$i.'</option>';
                } ?>
              </select>
            </div>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <select name = "month" id = "ig_monthfilled_eidt" class="form-control">
                <option value="">महिना</option>
                <?php for ($i=1; $i < 13; $i++) {
                  if ($i<10) {
                    echo '<option>0'.$i.'</option>';
                  }else
                    echo '<option>'.$i.'</option>';
                } ?>                  
              </select>
            </div>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <select name = "day" id = "ig_dayfilled_eidt" class="form-control">
                <option value="">दिन</option>
                <?php for ($i=1; $i < 33; $i++) { 
                  if ($i<10) {
                    echo '<option>0'.$i.'</option>';
                  }else
                    echo '<option>'.$i.'</option>';
                } ?>                  
              </select>
            </div>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input type = "text" id="ig_formFilledDate_eidt" class="form-control" name = "ig_formFilledDate" readonly placeholder="DD/MM/YYYY" required>
            </div>
          </div>
          <div class="item form-group">
            <label for="Business_Type" class="control-label col-md-3 col-sm-3 col-xs-12">व्यवसायको प्रकृति</label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <select id="Business_Type_eidt" type="text" name="Business_Type" class="form-control col-md-7 col-xs-12" required="required">
                <option value="">छान्नुहोस्</option>
                <option value="Agricultrual">कृषिमा आधारित</option>
                <option value="Processing">प्रशोधनमा आधारित</option>
                <option value="Service Oriented">सेवामुलक</option>
              </select>
            </div>
          
            <label for="IG_Sector" class="control-label col-md-3 col-sm-3 col-xs-12">आयआर्जनको क्षेत्र</label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input id="IG_Sector_eidt" type="text" name="IG_Sector" class="form-control col-md-7 col-xs-12" placeholder="Business Sector" required>
            </div>
          </div>
          <div class="item form-group">
            <label for="ig_savingFund" class="control-label col-md-3 col-sm-3 col-xs-12">हित कोष</label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <select id="ig_savingFund_eidt" type="text" name="ig_savingFund" class="form-control col-md-7 col-xs-12" required="required">
                <option value="">छान्नुहोस्</option>
                <option value="Yes">छ</option>
                <option value="No">छैन</option>
              </select>
            </div>
          
            <label for="ig_fundAmount" class="control-label col-md-3 col-sm-3 col-xs-12">छ भने, हालसम्मको जम्मा रकम</label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input id="ig_fundAmount_eidt" type="text" name="ig_fundAmount" class="form-control col-md-7 col-xs-12" placeholder="total saving fund">
            </div>
          </div>
          <div class="item form-group">
            <label for="Fund_Per_Person" class="control-label col-md-3 col-sm-3 col-xs-12">प्रति महिना प्रति सदस्य रु</label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input id="Fund_Per_Person_eidt" type="text" name="Fund_Per_Person" class="form-control col-md-7 col-xs-12" placeholder="Rs. per person per month">
            </div>
            <label for="ig_coopAffiliation" class="control-label col-md-3 col-sm-3 col-xs-12">के यो समूह सहकारीमा आबद्ध छ</label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <select id="ig_coopAffiliation_eidt" type="text" name="ig_coopAffiliation" class="form-control col-md-7 col-xs-12" required="required">
                <option value="">छान्नुहोस्</option>
                <option value="Yes">छ</option>
                <option value="No">छैन</option>
              </select>
            </div>          
          </div>
          <div class="item form-group">
            <label for="ig_coopName" class="control-label col-md-3 col-sm-3 col-xs-12">छ भने, सहकारीको नाम</label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input id="ig_coopName_eidt" type="text" name="ig_coopName" class="form-control col-md-7 col-xs-12" placeholder="cooperative name">
            </div>
            <label for="ig_coopAddress" class="control-label col-md-3 col-sm-3 col-xs-12">सहकारीको ठेगाना</label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input id="ig_coopAddress_eidt" type="text" name="ig_coopAddress" class="form-control col-md-7 col-xs-12" placeholder="cooperative address">
            </div>            
          </div>
          <div class="item form-group">
            <label for="Loan_From_Coop" class="control-label col-md-3 col-sm-3 col-xs-12">के सहकारीबाट ऋण लिइएको छ</label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <select id="Loan_From_Coop_eidt" type="text" name="Loan_From_Coop" class="form-control col-md-7 col-xs-12" required="required">
                <option value="">छान्नुहोस्</option>
                <option value="Yes">छ</option>
                <option value="No">छैन</option>
              </select>
            </div>
          
            <label for="ig_Registration" class="control-label col-md-3 col-sm-3 col-xs-12">के यो समुह सम्बन्धित निकायमा दर्ता छ</label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <select id="ig_Registration_eidt" type="text" name="ig_Registration" class="form-control col-md-7 col-xs-12" required="required">
                <option value="">छान्नुहोस्</option>
                <option value="Yes">छ</option>
                <option value="No">छैन</option>
              </select>
            </div>
          </div>
          <div class="item form-group">
            <label for="ig_registeredTo" class="control-label col-md-3 col-sm-3 col-xs-12">निकायको नाम</label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input id="ig_registeredTo_eidt" type="text" name="ig_registeredTo" class="form-control col-md-7 col-xs-12" placeholder="registered to">
            </div>
          
            <label for="ig_registrationNo" class="control-label col-md-3 col-sm-3 col-xs-12">दर्ता नं.</label>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input id="ig_registrationNo_eidt" type="text" name="ig_registrationNo" class="form-control col-md-7 col-xs-12" placeholder="registration number">
            </div>
          </div>
          <div class="item form-group">
            <label for="Registered_Date" class="control-label col-md-3 col-sm-3 col-xs-12">दर्ता मिति</label>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <select name = "year" id = "ig_yearRegistered_eidt" class="form-control">
                <option value="">वर्ष</option>
                <?php for ($i=2074; $i < 2081; $i++) {
                  echo '<option>'.$i.'</option>';
                } ?>
              </select>
            </div>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <select name = "month" id = "ig_monthRegistered_eidt" class="form-control">
                <option value="">महिना</option>
                <?php for ($i=1; $i < 13; $i++) {
                  if ($i<10) {
                    echo '<option>0'.$i.'</option>';
                  }else
                    echo '<option>'.$i.'</option>';
                } ?>                  
              </select>
            </div>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <select name = "day" id = "ig_dayRegistered_eidt" class="form-control">
                <option value="">दिन</option>
                <?php for ($i=1; $i < 33; $i++) { 
                  if ($i<10) {
                    echo '<option>0'.$i.'</option>';
                  }else
                    echo '<option>'.$i.'</option>';
                } ?>                  
              </select>
              
            </div>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <input type="text" id="Registered_Date_eidt" class="form-control" name="Registered_Date" readonly placeholder="DD/MM/YYYY">
            </div>
          </div>
          <div class="item form-group">
            <label for="Scheme_Code" class="control-label col-md-9 col-sm-9 col-xs-12">यो समूह RVWRMP को खानेपानी वा बहुउद्देश्यीय आयोजना अन्तर्गत पर्दछ भने, आयोजनाको कोड</label>
            <div class="col-md-3 col-sm-6 col-xs-6">
              <input id="Scheme_Code_eidt" type="text" name="Scheme_Code" class="form-control col-md-7 col-xs-12" placeholder="scheme name if applicable">
            </div>
          </div>
          <div class="item form-group">
            <label class="control-label col-md-12" style="text-align: left;"><u>समुहमा आवद्ध सदस्यहरुको विवरण</u></label>
            <hr>
            <label class="control-label col-md-2 col-sm-9 col-xs-12">दलित महिला</label>
            <div class="col-md-2 col-sm-6 col-xs-6">
              <input id="df11" type="number" name="df" class="form-control col-md-7 col-xs-12" placeholder="दलित महिला">
            </div>
            <label class="control-label col-md-2 col-sm-9 col-xs-12">दलित पुरुष</label>
            <div class="col-md-2 col-sm-6 col-xs-6">
              <input id="dm11" type="number" name="dm" class="form-control col-md-7 col-xs-12" placeholder="दलित पुरुष">
            </div>
            <label class="control-label col-md-2 col-sm-9 col-xs-12">जनजाती महिला</label>
            <div class="col-md-2 col-sm-6 col-xs-6">
              <input id="jf11" type="number" name="jf" class="form-control col-md-7 col-xs-12" placeholder="जनजाती महिला">
            </div>
          </div>
          <div class="item form-group">
            <label class="control-label col-md-2 col-sm-9 col-xs-12">जनजाती पुरुष</label>
            <div class="col-md-2 col-sm-6 col-xs-6">
              <input id="jm11" type="number" name="jm" class="form-control col-md-7 col-xs-12" placeholder="जनजाती पुरुष">
            </div>
            <label class="control-label col-md-2 col-sm-9 col-xs-12">अन्य महिला</label>
            <div class="col-md-2 col-sm-6 col-xs-6">
              <input id="of11" type="number" name="of" class="form-control col-md-7 col-xs-12" placeholder="अन्य महिला">
            </div>
            <label class="control-label col-md-2 col-sm-9 col-xs-12">अन्य पुरुष</label>
            <div class="col-md-2 col-sm-6 col-xs-6">
              <input id="om11" type="number" name="om" class="form-control col-md-7 col-xs-12" placeholder="अन्य पुरुष">
            </div>
          </div>
          <div class="item form-group">
            <label for="ig_others" class="control-label col-md-3 col-sm-6 col-xs-12">यो समूह बारे अन्य केहि बिशेषता/जानकारी</label>
            <div class="col-md-9 col-sm-6 col-xs-12">
              <textarea id="ig_others_eidt" name="ig_others" class="form-control col-md-7 col-xs-12" placeholder="other information about the group"></textarea>
            </div>
          </div>
          <div class="ln_solid"></div>
          <div class="form-group">
            <div class="col-md-6 col-md-offset-3">
              <button type="button" id="close_ig_edit" class="btn btn-default">Close</button>
              <button type="submit" id="submit" class="btn btn-success">Submit</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>          
</form>
<div class="modal fade bs-example-modal-lg" id="mdlIncome" tabindex="-1" role="dialog" aria-hidden="true" style="display: none;">
    <div class="modal-dialog modal-md" id="myMdl">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span>
          </button>
          <h4 class="modal-title" id="IncomeTableHeader"></h4>
        </div>
        <div class="modal-body">
          <div id="incomeTable">
          </div>
        </div>
      </div>
    </div>
  </div>
<!-- Edit Form Here -->
<script type="text/javascript">
  function addMemRow(){
    var tr = '<tr><td><input type="text" name="memName[]" class="form-control"></td><td><input type="number" name="dfm[]" class="form-control"></td><td><input type="number" name="dmm[]" class="form-control"></td><td><input type="number" name="jfm[]" class="form-control"></td><td><input type="number" name="jmm[]" class="form-control"></td><td><input type="number" name="ofm[]" class="form-control"></td><td><input type="number" name="omm[]" class="form-control"></td><td><a class="btn btn-sm btn-danger" href="javascript:void(0)" onclick="delMemRow(this)"><span class="fa fa-minus"></span></a></td></tr>';
    $('#tblMember tbody').append(tr);
  }

  function delMemRow(o){
    var p=o.parentNode.parentNode;
    p.parentNode.removeChild(p);

  }

  function addMembers(id){    
    $('#hgId').val(id);
    $('#mdlHG_mem').modal('toggle');
    $.ajax({
      url:'<?php echo base_url("Home/getMembers") ?>',
      method:'POST',
      data: {hid:id},
      success: function(data){
        $('#tblMember tbody').html(data);
      }
    })
  }

  $(document).ready(function(){
    $('#frmHG_mem').submit(function(e){
      e.preventDefault();
      var r = document.getElementById("tblMember").rows.length;
      $.ajax({
        url:"<?php echo base_url('Home/addMembers') ?>",
        method:'POST',
        data: new FormData(this),
        contentType: false,
        cache: false,
        processData: false,
        success: function(data){
          if (data=='Saved') {
            alert('Saved Successfully !!');
            document.getElementById("frmHG_mem").reset();
            $('#mdlHG_mem').modal('hide');
            $('#hgId').val(0);
          }else{
            alert(data);
          }
        }
      });
    })
  });

  $('#close').on('click', function(){
    $('#submit').html('Submit');
    $('#frmHG').trigger("reset");
    $('#mdlHG').modal('hide');
  });

  $('#close_ig').on('click', function(){
    $('#submit').html('Submit');
    $('#frmIG').trigger("reset");
    $('#mdlIG').modal('hide');
  });

    $('#close_ig_edit').on('click', function(){
    $('#submit').html('Submit');
    $('#frmIGEdit').trigger("reset");
    $('#mdlIGEdit').modal('hide');
  });

  $('#district').change(function(){
      var district = $('#district').val();
      if(district != '')
      {
       $.ajax({
        url:"<?php echo base_url();?>Home/getRM",
        method:"POST",
        data:{district:district},
        success:function(data)
        {
         $('#rmc').html(data);
        }
       });
      }
      {
        $('#rm').html('<option value="">Select RM</option>');
      }
    });

  $('#IG_district').change(function(){
      var district = $('#IG_district').val();
      if(district != '')
      {
       $.ajax({
        url:"<?php echo base_url();?>Home/getRM",
        method:"POST",
        data:{district:district},
        success:function(data)
        {
         $('#IG_rmc').html(data);
        }
       });
      }
      {
        $('#IG_rmc').html('<option value="">Select RM</option>');
      }
    });

    $('#IG_district_eidt').change(function(){
      var district = $('#IG_district_eidt').val();
      if(district != '')
      {
       $.ajax({
        url:"<?php echo base_url();?>Home/getRM",
        method:"POST",
        data:{district:district},
        success:function(data)
        {
         $('#IG_rmc_eidt').html(data);
        }
       });
      }
      {
        $('#IG_rmc_eidt').html('<option value="">Select RM</option>');
      }
    });

  function delFunction(tbl,x,o){
    var urltext = '<?php echo base_url();?>Home/delete/'+tbl+'/'+x;
    var p=o.parentNode.parentNode;
    var c=confirm('Are you sure');
    if(c==true){
      $.ajax({
        url: urltext,
        type: 'POST',
        error: function(){
          alert('Error!! user delete failed');
        },
        success: function(data){
          if (data=='deleted') {
            alert("Record deleted successfull");            
            p.parentNode.removeChild(p);
          }else{
            alert(data);
          }
          
        }
      });
    }        
  }
//======================================================IG Edit From=========================================
  // Business Start Date1
  $('#ig_start_year_eidt').change(function(){
    $('#Business_Start_Date_eidt').val($('#ig_start_day_eidt').val()+'/'+$('#ig_start_month_eidt').val()+'/'+$('#ig_start_year_eidt').val());
  });
  $('#ig_start_month_eidt').change(function(){
    $('#Business_Start_Date_eidt').val($('#ig_start_day_eidt').val()+'/'+$('#ig_start_month_eidt').val()+'/'+$('#ig_start_year_eidt').val());
  });
  $('#ig_start_day_eidt').change(function(){
    $('#Business_Start_Date_eidt').val($('#ig_start_day_eidt').val()+'/'+$('#ig_start_month_eidt').val()+'/'+$('#ig_start_year_eidt').val());
  });
  // Form Filled Date1
  $('#ig_yearfilled_eidt').change(function(){
    $('#ig_formFilledDate_eidt').val($('#ig_dayfilled_eidt').val()+'/'+$('#ig_dayfilled_eidt').val()+'/'+$('#ig_yearfilled_eidt').val());
  });
  $('#ig_monthfilled_eidt').change(function(){
    $('#ig_formFilledDate_eidt').val($('#ig_dayfilled_eidt').val()+'/'+$('#ig_monthfilled_eidt').val()+'/'+$('#ig_yearfilled_eidt').val());
  });
  $('#ig_dayfilled_eidt').change(function(){
    $('#ig_formFilledDate_eidt').val($('#ig_dayfilled_eidt').val()+'/'+$('#ig_dayfilled_eidt').val()+'/'+$('#ig_yearfilled_eidt').val());
  });
  // Registered Date1
  $('#ig_yearRegistered_eidt').change(function(){
    $('#Registered_Date_eidt').val($('#ig_dayRegistered_eidt').val()+'/'+$('#ig_monthRegistered_eidt').val()+'/'+$('#ig_yearRegistered_eidt').val());
  });
  $('#ig_monthRegistered_eidt').change(function(){
    $('#Registered_Date_eidt').val($('#ig_dayRegistered_eidt').val()+'/'+$('#ig_monthRegistered_eidt').val()+'/'+$('#ig_yearRegistered_eidt').val());
  });
  $('#ig_dayRegistered_eidt').change(function(){
    $('#Registered_Date_eidt').val($('#ig_dayRegistered_eidt').val()+'/'+$('#ig_monthRegistered_eidt').val()+'/'+$('#ig_yearRegistered_eidt').val());
  });
//=========================================IG Entry Form=======================================================
  // Business Start Date1
  $('#ig_start_year').change(function(){
    $('#Business_Start_Date').val($('#ig_start_day').val()+'/'+$('#ig_start_month').val()+'/'+$('#ig_start_year').val());
  });
  $('#ig_start_month').change(function(){
    $('#Business_Start_Date').val($('#ig_start_day').val()+'/'+$('#ig_start_month').val()+'/'+$('#ig_start_year').val());
  });
  $('#ig_start_day').change(function(){
    $('#Business_Start_Date').val($('#ig_start_day').val()+'/'+$('#ig_start_month').val()+'/'+$('#ig_start_year').val());
  });
  // Form Filled Date1
  $('#ig_yearfilled').change(function(){
    $('#ig_formFilledDate').val($('#ig_dayfilled').val()+'/'+$('#ig_dayfilled').val()+'/'+$('#ig_yearfilled').val());
  });
  $('#ig_monthfilled').change(function(){
    $('#ig_formFilledDate').val($('#ig_dayfilled').val()+'/'+$('#ig_monthfilled').val()+'/'+$('#ig_yearfilled').val());
  });
  $('#ig_dayfilled').change(function(){
    $('#ig_formFilledDate').val($('#ig_dayfilled').val()+'/'+$('#ig_dayfilled').val()+'/'+$('#ig_yearfilled').val());
  });
  // Registered Date1
  $('#ig_yearRegistered').change(function(){
    $('#Registered_Date').val($('#ig_dayRegistered').val()+'/'+$('#ig_monthRegistered').val()+'/'+$('#ig_yearRegistered').val());
  });
  $('#ig_monthRegistered').change(function(){
    $('#Registered_Date').val($('#ig_dayRegistered').val()+'/'+$('#ig_monthRegistered').val()+'/'+$('#ig_yearRegistered').val());
  });
  $('#ig_dayRegistered').change(function(){
    $('#Registered_Date').val($('#ig_dayRegistered').val()+'/'+$('#ig_monthRegistered').val()+'/'+$('#ig_yearRegistered').val());
  });
//=================================Homegarden =======================================================
  // Start Date2
  $('#yearfilled').change(function(){
    $('#formFilledDate').val($('#dayfilled').val()+'/'+$('#monthfilled').val()+'/'+$('#yearfilled').val());
  });
  $('#monthfilled').change(function(){
    $('#formFilledDate').val($('#dayfilled').val()+'/'+$('#monthfilled').val()+'/'+$('#yearfilled').val());
  });
  $('#dayfilled').change(function(){
    $('#formFilledDate').val($('#dayfilled').val()+'/'+$('#monthfilled').val()+'/'+$('#yearfilled').val());
  });
  // Formation Date
  $('#yearformated').change(function(){
    $('#formatedDate').val($('#dayformated').val()+'/'+$('#monthformated').val()+'/'+$('#yearformated').val());
  });
  $('#dayformated').change(function(){
    $('#formatedDate').val($('#dayformated').val()+'/'+$('#monthformated').val()+'/'+$('#yearformated').val());
  });
  $('#monthformated').change(function(){
    $('#formatedDate').val($('#dayformated').val()+'/'+$('#monthformated').val()+'/'+$('#yearformated').val());
  });
  // Registration Date2
  $('#yearRegistered').change(function(){
    $('#registrationDate').val($('#dayRegistered').val()+'/'+$('#monthRegistered').val()+'/'+$('#yearRegistered').val());
  });
  $('#monthRegistered').change(function(){
    $('#registrationDate').val($('#dayRegistered').val()+'/'+$('#monthRegistered').val()+'/'+$('#yearRegistered').val());
  });
  $('#dayRegistered').change(function(){
    $('#registrationDate').val($('#dayRegistered').val()+'/'+$('#monthRegistered').val()+'/'+$('#yearRegistered').val());
  });


function getIncome(id,name){
    var urltext = '<?php echo base_url();?>Home/getIncomes/'+id;
    $.ajax({
      url: urltext,
      type:'POST',
      success: function(res){
        $('#incomeTable').html(res);
          $('#IncomeTableHeader').html(name + ' ले प्रत्येक आ.व.मा गरेको आम्दानी (रु.)');
        $('#mdlIncome').modal('show');
      }
    });
}

  function getById(tbl,id){
    var urltext = '<?php echo base_url();?>Home/getById/'+tbl+'/'+id;
    $('#IG_id_edit').val(id);
    if (tbl=='ig_info') {
      $.ajax({
        url: urltext,
        type: 'POST',
        dataType: 'json',
        success: function(response){
          var len = response.length; 
          if (len>0) {
            var rm='<option>'+response[0].RM+'</option>';
            $('#IG_Info_Type_eidt').val(response[0].IG_Info_Type);
            $('#IG_district_eidt').val(response[0].District);
            $('#IG_rmc_eidt').html(rm);
            $('#IG_ward_eidt').val(response[0].Ward_No);
            $('#IG_clusterName_eidt').val(response[0].Cluster_Name);
            $('#Group_Person_Name_eidt').val(response[0].Group_Person_Name);
            $('#Group_Person_Code_eidt').val(response[0].Group_Person_Code);
            $('#Business_Start_Date_eidt').val(response[0].Business_Start_Date);
            $('#ig_formFilledDate_eidt').val(response[0].Form_Filled_Date);
            $('#Business_Type_eidt').val(response[0].Business_Type);
            $('#IG_Sector_eidt').val(response[0].IG_Sector);
            $('#ig_savingFund_eidt').val(response[0].Saving_Fund);
            $('#ig_fundAmount_eidt').val(response[0].Fund_Amount);
            $('#Fund_Per_Person_eidt').val(response[0].Fund_Per_Person);
            $('#ig_coopAffiliation_eidt').val(response[0].Coop_Affiliation);
            $('#ig_coopName_eidt').val(response[0].Coop_Name);
            $('#ig_coopAddress_eidt').val(response[0].Coop_Address);
            $('#Loan_From_Coop_eidt').val(response[0].Loan_From_Coop);
            $('#ig_Registration_eidt').val(response[0].Group_Registration);
            $('#ig_registeredTo_eidt').val(response[0].Registered_To);
            $('#ig_registrationNo_eidt').val(response[0].Registration_No);
            $('#Registered_Date_eidt').val(response[0].Registered_Date);
            $('#Scheme_Code_eidt').val(response[0].Scheme_Code);
            $('#df11').val(response[0].DF);
            $('#dm11').val(response[0].DM);
            $('#jf11').val(response[0].JF);
            $('#jm11').val(response[0].JM);
            $('#of11').val(response[0].OF);
            $('#om11').val(response[0].OM);
            $('#ig_others_eidt').val(response[0].Others);
            $('#mdlIGEdit').modal('show');
          }
          else{
            alert('Data not found');
          }         
        }
      });
    }else{
      $.ajax({
        url: urltext,
        type: 'POST',
        dataType: 'json',
        success: function(response){
          var len = response.length; 
          if (len>0) {
            //alert(response[0].Cluster_Name)
            $('#id').val(response[0].Id);
            var rm='<option>'+response[0].RM+'</option>';
            $('#district').val(response[0].District);
            $('#rmc').html(rm);
            $('#ward').val(response[0].Ward_No);
            $('#clusterName').val(response[0].Cluster_Name);
            $('#hgName').val(response[0].Group_Name);
            $('#hgCode').val(response[0].Group_Code);
            $('#formatedDate').val(response[0].Group_Formated_Date);
            $('#formFilledDate').val(response[0].Form_Filled_Date);
            $('#savingFund').val(response[0].Saving_Fund);
            $('#fundAmount').val(response[0].Fund_Amount);
            $('#fundPerPersonPerPerson').val(response[0].fundPerPersonPerPerson);
            $('#meetingDay').val(response[0].Meeting_Day);
            $('#coopAffiliation').val(response[0].Coop_Affiliation);
            $('#coopName').val(response[0].Coop_Name);
            $('#coopAddress').val(response[0].Coop_Address);
            $('#hgRegistration').val(response[0].Group_Registration);
            $('#registeredTo').val(response[0].Registered_To);
            $('#registrationNo').val(response[0].Registration_No);
            $('#registrationDate').val(response[0].Registered_Date);
            $('#schemeName').val(response[0].Scheme_Code);
            $('#df').val(response[0].DF);
            $('#dm').val(response[0].DM);
            $('#jf').val(response[0].JF);
            $('#jm').val(response[0].JM);
            $('#of').val(response[0].OF);
            $('#om').val(response[0].OM);
            $('#others').val(response[0].Others);
            $('#mdlHG').modal('show');
          }
          else{
            alert('Data not found');
          }         
        }
      });
    }
    
  }


//=======================================================

var flag=0;

  function getIncomeById(id){
    if (flag===1) {
      alert('Please save current data');
    }else{
      var tr="";
      $.ajax({
        url:'<?php echo base_url("Home/getIncomeById");?>',
        method:"POST",
        data:{id:id},
        success: function(data){
          $('#icTable tbody').append(data);
          flag=1;
        }
      })
    }
    
  }

  function updateIncomeById(){
    var p = $('#particulars').val();
    var fy1 = $('#fy74_75').val();
    var fy2 = $('#fy75_76').val();
    var fy3 = $('#fy76_77').val();
    var fy4 = $('#fy77_78').val();
    var id = $('#editId').val();
    var igId = $('#editIgId').val();

    $.ajax({
      url:'<?php echo base_url("Home/updateIncome") ?>',
      method:"POST",
      data:{id:id, particular:p, f7475:fy1, f7576:fy2, f7677:fy3, f7778:fy4},
      success:function(data){
        if (data=='Saved Successfully' || data=='No Change') {
          getIncomes(igId);
          alert(data);
          flag=0;               
        }else{
            alert(data);
        }
      }
    })
  }

  function getIncomes(id){
    var urltext = '<?php echo base_url();?>Home/getIncomes/'+id;
    $.ajax({
      url: urltext,
      type:'POST',
      success: function(res){
        $('#incomeTable').html(res);
      }
    });
}

function cancelEdit(e){
  var p=e.parentNode.parentNode;
  p.parentNode.removeChild(p);
  flag=0;
}
  
</script>