<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<style type="text/css">
  .x_panel, .x_title {
    margin-bottom: 5px;
    padding: 10px 10px 5px;
}
.x_title h2 {
    margin: -7px 0 6px;
}

table {
  margin-top: -19px;
    border-collapse: collapse;
    margin-bottom: 0em;
    width: 100%;
    background: #fff;
}

td {
    padding: 0.2em .75em;
    text-align: left;
    border-left: solid thin;
    border-right: solid thin;
    border-color: #eee;
}
.table-bordered>tbody>tr>td, .table-bordered>tbody>tr>th, 
.table-bordered>thead>tr>td, .table-bordered>thead>tr>th {
    vertical-align: middle;
}
th {
    background-color: #31bc86; /* #31bc86   */
    font-weight: bold;
    color: #fff;
    vertical-align: middle;
    text-align: center; 
}
.header > th {
    background-color: #31bc86; /* #31bc86   */
    font-weight: bold;
    color: #fff;
    vertical-align: middle;  
}
</style>
  <!-- page content -->
  <div class="right_col" role="main" style="min-height: 770px;">
    <div class="" style="margin-top: 40px;">
      <div class="clearfix"></div>
      <div class="row">
        <div class="col-md-6 col-sm-12 col-xs-12">
          <?php if ($this->session->userdata('loginType')=='Admin') { ?>
          <div class="x_panel">
            <div class="x_title">
              <h2 style="line-height: 25px;"> Rural Advisory Services (RAS) Beneficiaries</h2>
              <div class="clearfix"></div>
            </div>
            <div class="x_content" style="overflow-x: auto;">
              <br>
              <table class="table table-bordered table-hover table-striped" id="tblHg">
                <thead>
                  <tr>
                    <th width="50">SN</th>
                    <th>Activity</th>
                    <th>Total HH</th>
                    <th>Total Beneficiary</th>
                  </tr>
                <tbody>
                   <?php echo $ras; ?>
                </tbody>
              </table>
            </div>
            </div>
          <?php } ?>
        </div>
      </div>
    </div>
  </div>

