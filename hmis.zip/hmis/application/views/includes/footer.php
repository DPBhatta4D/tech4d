<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
        <!-- footer content -->
        <footer class="footer_fixed">
			<div class="pull-left">
            Template by <a href="https://colorlib.com">Colorlib</a>
			</div>
			<div class="pull-right">
				Developed by <a href="https://rvwrmp.org.np">Chhatra Chaudhary, MIS Section, RVWRMP</a>
			</div>
			<div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
      </div>
    </div>
    
    <!-- Bootstrap -->
    <script src="<?php echo base_url(); ?>assets/vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- NProgress -->
    <script src="<?php echo base_url(); ?>assets/vendors/nprogress/nprogress.js"></script>
    <!-- Custom Theme Scripts -->
    <script src="<?php echo base_url(); ?>assets/build/js/custom.min.js"></script>
    <!-- <script src="<?php echo base_url(); ?>assets/vendors/validator/validator.js"></script>  -->   
  </body>
</html>