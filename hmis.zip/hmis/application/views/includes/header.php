<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <title><?php echo $page_title; ?></title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="<?php echo base_url(); ?>assets/vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/vendors/nprogress/nprogress.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>assets/build/css/custom.min.css" rel="stylesheet">
    <script src="<?php echo base_url(); ?>assets/vendors/jquery/dist/jquery.min.js"></script>    
  </head>
  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <div class="col-md-3 left_col">
          <div class="left_col scroll-view">
            <div class="navbar nav_title" style="border: 0;">
              <a class="site_title"><img src="<?php echo base_url(); ?>assets/images/logo.png" height="40" width="145" style='padding-left: 10px;'></a>
            </div>
            <div class="clearfix"></div>
            <div class="profile clearfix"  style="padding-top: 25px; margin-left: -5px; margin-bottom: -25px; text-align: center;">
              <h2 class="col-md-12" style="font-size: 16px; color:#eae9e9; line-height: 25px;">Livelihood Information Reporting System</h2>      
            </div> 
            <br>
            <!-- sidebar menu -->
            <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
              <div class="menu_section">
                <!-- <h3>General</h3> -->
                <ul class="nav side-menu">
                  <li class="" id="l1"><a href="<?php echo base_url();?>home"><i class="fa fa-tachometer" aria-hidden="true"></i> Home </a>
                  </li>
                  <li class="" id="l1"><a href="<?php echo base_url();?>Hg"><i class="fa fa-home"></i> Homegarden </a>
                  </li>
                  <li class="" id="l1"><a href="<?php echo base_url();?>Ig"><i class="fa fa-industry" aria-hidden="true"></i> Income Generation </a>
                  </li>
                  <li class="" id="l1"><a href="<?php echo base_url();?>SchemeCard"><i class="fa fa-pagelines" area-hidden="true"></i> Scheme Card / Polyhouse</a>
                  </li>
                  <li class="" id="l1"><a href="<?php echo base_url();?>AgriBusinessPlan"><i class="fa fa-briefcase" aria-hidden="true"></i></i>MUS Business Plan & Agri Business Scheme Card </a>
                  </li>
                  <li class="" id="l1"><a href="<?php echo base_url();?>AgriBusinessPlan/collectionCenter"><i class="fa fa-archive" aria-hidden="true"></i> Collection Center Card </a>
                  </li>
                  <li class="" id="l1"><a href="<?php echo base_url();?>Cooperative"><i class="fa fa-archive" aria-hidden="true"></i> Cooperative Reporting </a>
                  </li>
                  <?php if ($this->session->userdata('loginType')=='Admin') {
                    echo '<li class="a" id="l10">
                    <a href="'.base_url().'User"><i class="fa fa-user"></i> User Management </a>
                  </li>';
                  }?>
                  <li class="" id="l1"><a href="<?php echo base_url();?>BackupDB/backup"><i class="fa fa-cloud-download"></i> Backup Database </a> 
                </ul>
              </div> 
            </div>
            <!-- /sidebar menu -->
            <!-- /menu footer buttons -->
            <div class="sidebar-footer hidden-small">              
              <a data-toggle="tooltip" data-placement="top" title="" href="<?php echo base_url(); ?>Logout" data-original-title="Logout" style="width: 100%;">
                <span class="glyphicon glyphicon-off" aria-hidden="true"></span>
              </a>
            </div>
            <!-- /menu footer buttons -->
          </div>
        </div>
        <!-- top navigation -->
        <div class="top_nav">
          <div class="nav_menu">
            <nav>
              <div class="nav toggle">
                <a id="menu_toggle"><i class="fa fa-bars"></i></a>				
              </div>
              <ul class="nav navbar-nav navbar-right">
                <li style="text-align: center;">
                  <a href="javascript:;" class="user-profile dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                    <?php echo $this->session->userdata('loginName'); ?>
                    <span class=" fa fa-angle-down"></span>
                  </a>
                  <ul style="width:180px;" class="dropdown-menu dropdown-usermenu pull-right">
                    <li><a href="<?php echo base_url(); ?>Logout"><i class="fa fa-sign-out pull-right"></i> Log Out</a></li>
                    <li><a target="blank" href="https://sis.rvmis.com"><i class="fa fa-external-link pull-right"></i> Login to Scheme Info</a></li>
                    <li><a target="blank" href="https://bmrs.rvmis.com"><i class="fa fa-external-link pull-right"></i> Bi-monthly Reporting</a></li>
                  </ul>
                </li>
              </ul>
            </nav>
          </div>
        </div>