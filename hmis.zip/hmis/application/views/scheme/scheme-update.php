<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<link href="<?php echo base_url(); ?>assets/build/css/scheme_info_update.css" rel="stylesheet">
<div class="right_col" role="main" style="min-height: 770px;">
    <div class="" style="margin-top: 40px;">
      <div class="clearfix"></div>
      <div class="row">
       <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel">
              <div class="x_title">
                <h2 style="line-height: 25px;">Update Scheme Information</h2><br>
                <div class="clearfix"></div>
              </div>
              <div class="x_content">
              	<div class="row">
              		<div class="col-md-12"><br>
              			<table class="table" style="border-bottom: solid thin lightgrey;">
          					<tr>
          						<td style="text-align: right;"><b>Scheme Name</b></td>
          						<td><?php echo $schemename ?></td>
          						<td style="text-align: right;"><b>Scheme Code</b></td>
          						<td><?php echo $schemecode ?></td>
          						<td style="text-align: right;"><b>Current Status</b></td>
          						<td id="sts"><?php echo $currentstatus ?></td>
          					</tr>
              			</table>
              		</div>
              		<div class="col-md-6">
              			<div class="alert alert-danger alert-dismissible" role="alert" id="warning">
							<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
							<p id="msg"></p>
						</div>
						<div class="alert alert-success alert-dismissible" role="alert" id="success">
							<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
							<p id="msg1"></p>
						</div>
              		</div>              		
              	</div>
                <div class="" role="tabpanel" data-example-id="togglable-tabs">
                  <ul id="myTab" class="nav nav-tabs bar_tabs" role="tablist">
                    <li role="presentation" class="active"><a href="#tab_content1" role="tab" data-toggle="tab" aria-expanded="false">Beneficiary</a>
                    </li>
                    <li role="presentation" class=""><a href="#tab_content2" role="tab" data-toggle="tab" aria-expanded="false">Cost Contribution</a>
                    </li>
                    <li role="presentation" class=""><a href="#tab_content3" role="tab" id="profile-tab" data-toggle="tab" aria-expanded="false">Item Cost</a>
                    </li>
                  	<li role="presentation" class=""><a href="#tab_content0" role="tab" data-toggle="tab" aria-expanded="false">Scheme Status</a>
                    </li>
                  </ul>
                  <div id="myTabContent" class="tab-content">
                  	<div role="tabpanel" class="tab-pane fade " id="tab_content0" aria-labelledby="home-tab">
                      <div class="x_panel">
                        <div class="x_content" style="overflow-y: hidden; overflow-x: auto;">
                          	<br>
                          	
                          	<form class="form-horizontal form-label-right">
                          		<input type="hidden" name="sId" id="sId" value="<?php echo $schemecode; ?>">
                          		<input type="hidden" name="id" id="id" value="0">
	                      		<div class="item form-group">
		                      		<label for="Current_Status" class="control-label col-md-3 col-xs-3">
		                      			Change Current Status:
		                      		</label>
		                      		<div class="col-md-3">
		                      			<select id="Current_Status" name="Current_Status" class="form-control col-md-7 col-xs-3" required="required">
											<option value=""></option>
											<option>PPO</option>
											<option>PPC</option>
											<option>IPO</option>
											<option>IPC*</option>
											<option>IPC</option>
										</select>
		                      		</div>
		                      		<div class="col-md-9">
		                      		</div>
		                      	</div>
	                      		<div class="item form-group" id="dateDiv">
						            <label for="Scheme_Completed_Date" class="control-label col-md-3 col-sm-3 col-xs-12">Scheme Completed Date </label>
						            <div class="col-md-2 col-sm-3 col-xs-6">
						              <select name = "year" id = "yearformated" class="form-control">
						                <option value="">Year</option>
						                <?php for ($i=2074; $i < 2081; $i++) {
						                  echo '<option>'.$i.'</option>';
						                } ?>
						              </select>
						            </div>
						            <div class="col-md-2 col-sm-3 col-xs-6">
						              <select name = "month" id = "monthformated" class="form-control">
						                <option value="">Month</option>
						                <?php for ($i=1; $i < 13; $i++) {
						                  if ($i<10) {
						                    echo '<option>0'.$i.'</option>';
						                  }else
						                    echo '<option>'.$i.'</option>';
						                } ?>                  
						              </select>
						            </div>
						            <div class="col-md-2 col-sm-3 col-xs-6">
						              <select name = "day" id = "dayformated" class="form-control">
						                <option value="">Day</option>
						                <?php for ($i=1; $i < 33; $i++) { 
						                  if ($i<10) {
						                    echo '<option>0'.$i.'</option>';
						                  }else
						                    echo '<option>'.$i.'</option>';
						                } ?>                  
						              </select>
						            </div>
						            <div class="col-md-3 col-sm-3 col-xs-6">
						              <input type = "text" id="Scheme_Completed_Date" class="form-control" name = "Scheme_Completed_Date" readonly placeholder="DD/MM/YYYY" required>
						            </div>
						        </div>
						        <div class="ln_solid"></div>
								<div class="form-group">
									<div class="col-md-6 col-md-offset-3">
									  <button type="button" id="submit_Status" class="btn btn-success">Save</button>
									</div>
								</div>
						    </form>
                        </div>
                      </div>
                    </div>
                    <div role="tabpanel" class="tab-pane fade active in" id="tab_content1" aria-labelledby="home-tab">
                      <div class="x_panel">
                        <div class="x_content" style="overflow-y: hidden; overflow-x: auto;">
                          <br>
                          <table class="table table-bordered table-hover table-striped" id="tblBen">
                            <thead>
                              <tr>
                                <th width="100">
                                  <button type="button" id="btnAddBen" class="btn btn-default" onclick="addBenRow()"><span class="fa fa-plus"></span></button>
                                </th>
                                <th width="150">HH Head Name</th>
                                <th width="120">Tole/Cluster</th>
                                <th width="100">Ethnicity</th>
                                <th width="90">Female Beneficiary</th>
                                <th width="90">Male Beneficiary</th>
                                <th width="70">Total</th>
                                <th width="70">Irrigated Land</th>
                                <th width="120">Remarks</th>
                              </tr>
                          </thead>
                            <tbody>
                            	
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                    <div role="tabpanel" class="tab-pane fade" id="tab_content2" aria-labelledby="home-tab">
                      <div class="x_panel">
                        <div class="x_content" style="overflow-y: hidden; overflow-x: auto;">
                          <br>
                          <table id="costContribution" class="table table-bordered table-hover table-striped" style="width: 50%;">
                            
                          </table>
                        </div>
                      </div>
                    </div>
                    <div role="tabpanel" class="tab-pane fade" id="tab_content3" aria-labelledby="home-tab">
                      <div class="x_panel">
                        <div class="x_content" style="overflow-y: hidden; overflow-x: auto;">
                          <br>
                          <table id="itemCost" style="width: 60%;" class="table table-bordered table-hover table-striped">
                            
                          </table>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
      </div>
    </div>
  </div>
 <script src="<?php echo base_url(); ?>assets/build/js/schemeBen.js"></script>
 <script src="<?php echo base_url(); ?>assets/build/js/cost_contribution.js"></script>
 <script src="<?php echo base_url(); ?>assets/build/js/itemCost.js"></script> 
  <script type="text/javascript">
  	var ben = 0;
  	// Formation Date
	$('#yearformated').change(function(){
		$('#Scheme_Completed_Date').val($('#dayformated').val()+'/'+$('#monthformated').val()+'/'+$('#yearformated').val());
		$('#warning').hide();
	});
	$('#dayformated').change(function(){
		$('#Scheme_Completed_Date').val($('#dayformated').val()+'/'+$('#monthformated').val()+'/'+$('#yearformated').val());
		$('#warning').hide();
	});
	$('#monthformated').change(function(){
		$('#Scheme_Completed_Date').val($('#dayformated').val()+'/'+$('#monthformated').val()+'/'+$('#yearformated').val());
		$('#warning').hide();
	});
	//Date div
	$("#dateDiv").hide();
	$('#warning').hide();
	$('#success').hide();
	$('#Current_Status').change(function(){
		$('#warning').hide();
		if ($('#Current_Status').val()=='IPC') {
			$("#dateDiv").show();
		}else{
			$("#dateDiv").hide();
		}
	});

	$('#submit_Status').click(function(){
		if ($('#Current_Status').val()=="") {
			$('#msg').html('Please Change Current Status');
			$('#warning').show();
		}else if($('#Scheme_Completed_Date').val()=="" && $('#Current_Status').val()=="IPC"){
			$('#msg').html('Please Enter Completed Date');
			$('#warning').show();
		}else{
			$.ajax({
				url:'<?php echo base_url('SchemeCard/updateSchemeStatus'); ?>',
				method:'POST',
				data:{id:$('#sId').val(), status:$('#Current_Status').val(), cdate: $('#Scheme_Completed_Date').val()},
				success: function(data){
					if (data=='Saved Successfully' || data=='No Change') {
						$('#msg1').html(data);
						$('#success').show();
						$('#sts').html($('#Current_Status').val());
						window.setTimeout(function() {
					    $(".alert").slideUp(500, function(){
					        	$(this).remove('dismiss'); 
						    });
						}, 2000);
						
					}else{
						$('#msg').html(data);
						$('#warning').show();
					}
				}
			})
		}
	})

	function removeRow(e){
		var row = e.parentNode.parentNode;
		row.parentNode.removeChild(row);
		ben=0;
	}

	
  </script>