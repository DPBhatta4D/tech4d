<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
        <!-- page content -->
        <div class="right_col" role="main" style="min-height: 770px;">
          <div class="" style="margin-top: 40px;">
            <div class="clearfix"></div>
            <div class="row">
              <div class="col-md-12">
                <div class="x_panel">
                  <div class="x_title">
                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target=".bs-example-modal-lg">Add New User</button>                  
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <table id="usertable" class="table table-bordered table-hover" width="760px;">
                      <thead>
                        <tr>
                          <th width="30">#</th>
                          <th width="130">User Type</th>
                          <th width="200">Full Name</th>
                          <th width="300">Username</th>
                          <th width="92">Actions</th>
                        </tr>
                      </thead>
                        <tbody>
                          
                        </tbody>               
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <form id="frmUser" class="form-horizontal form-label-left" novalidate>
          <div class="modal fade bs-example-modal-lg" id="mdlAddUser" tabindex="-1" role="dialog" aria-hidden="true" style="display: none;">
              <div class="modal-dialog modal-lg">
                <div class="modal-content">
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span>
                    </button>
                    <h4 class="modal-title" id="myModalLabel2">Enter User Detail</h4>
                  </div>
                  <div class="modal-body">                    
                        <div class="item form-group">
                          <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">User Type <span class="required">*</span>
                          </label>
                          <div class="col-md-6 col-sm-6 col-xs-12">
                            <input type="hidden" name="id" value="0" id="hiddenid">
                            <select class="select2_single form-control col-md-7 col-xs-12" tabindex="-1" required="required" name="usertype" id="usertype">
                              <option></option>
                              <option>Admin</option>
                              <option>TA-CB</option>
                              <option>District</option>
                              <option>RM</option>
                              <option>User</option>                      
                            </select>
                          </div>
                        </div>
                        <div class="item form-group">
                          <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">District <span class="required">*</span>
                          </label>
                          <div class="col-md-6 col-sm-6 col-xs-12">
                            <select class="select2_single form-control col-md-7 col-xs-12" tabindex="-1" required="required" name="district" id="district">
                              <option></option>
                              <option>Achham</option>
                              <option>Bajhang</option>
                              <option>Baitadi</option>
                              <option>Bajura</option>
                              <option>Darchula</option>
                              <option>Dadeldhura</option>
                              <option>Dailekh</option>
                              <option>Doti</option>                            
                              <option>Humla</option>                   
                              <option>Kailali</option>
                              <option>RVWRMP</option>
                            </select>
                          </div>
                        </div>
                        <div class="item form-group">
                          <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">R/MC <span class="required">*</span>
                          </label>
                          <div class="col-md-6 col-sm-6 col-xs-12">
                            <select class="select2_single form-control col-md-7 col-xs-12" tabindex="-1" required="required" name="rmc" id="rmc">
                              <option></option>
                            </select>
                          </div>
                        </div>
                        <div class="item form-group">
                          <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Full Name <span class="required">*</span>
                          </label>
                          <div class="col-md-6 col-sm-6 col-xs-12">
                            <input id="name" class="form-control col-md-7 col-xs-12" data-validate-length-range="6" data-validate-words="1" name="fullname" placeholder="Enter Full Name" required="required" type="text">
                          </div>
                        </div>
                        <div class="item form-group">
                          <label class="control-label col-md-3 col-sm-3 col-xs-12" for="email">Email <span class="required">*</span>
                          </label>
                          <div class="col-md-6 col-sm-6 col-xs-12">
                            <input type="email" id="email" name="email" required="required" class="form-control col-md-7 col-xs-12">
                          </div>
                        </div>
                        <div class="item form-group">
                          <label for="password" class="control-label col-md-3">Password</label>
                          <div class="col-md-6 col-sm-6 col-xs-12">
                            <input id="password" type="password" name="password" data-validate-length="4,8" class="form-control col-md-7 col-xs-12" required="required">
                          </div>
                        </div>
                        <div class="item form-group">
                          <label for="password2" class="control-label col-md-3 col-sm-3 col-xs-12">Repeat Password</label>
                          <div class="col-md-6 col-sm-6 col-xs-12">
                            <input id="password2" type="password" name="password2" data-validate-linked="password" class="form-control col-md-7 col-xs-12" required="required">
                          </div>
                        </div>                      
                        <div class="ln_solid"></div>
                        <div class="form-group">
                          <div class="col-md-6 col-md-offset-3">
                            <button type="button" id="close" class="btn btn-default">Close</button>
                            <button type="submit" id="submit" class="btn btn-success">Submit</button>
                          </div>
                        </div>
                  </div>
                </div>
              </div>
            </div>          
          </form>

          <!-- Edit Form Here -->

        <!-- /page content -->
<script type="text/javascript">
  $('#close').on('click', function(){
    $('#submit').html('Submit');
    $('#frmUser').trigger("reset");
    $('#mdlAddUser').modal('hide');
  });

  $(document).ready(function(){
    loadUserTable();
    
    $('#submit').on('click', function(e){
      e.preventDefault();
      var userId=$('#usertype').val();
      var usertype=$('#usertype').val();
      var district=$('#district').val();
      var rmc=$('#rmc').val();
      var fullname=$('#name').val();
      var email=$('#email').val();
      var password=$('#password').val();
      if ($('#submit').text()=='Submit') {
        var ajurl = "<?php echo base_url();?>User/addUser";
      }
      else{
        var ajurl = "<?php echo base_url();?>User/updateUser";
      }
        $.ajax({
          url: ajurl,
          method: "POST",
          data: {
            userId:userId,
            usertype:usertype, 
            district:district, 
            rmc:rmc,
            fullname:fullname, 
            email:email, 
            password:password
          },            
          success: function(data){
            $('#submit').html('Submit');
            $('#frmUser').trigger("reset");
            $('#mdlAddUser').modal('hide');
            loadUserTable();
            alert(data);
          }
        })
    });
   });

  $('#district').change(function(){
      var district = $('#district').val();
      if(district != '')
      {
       $.ajax({
        url:"<?php echo base_url();?>User/getRM",
        method:"POST",
        data:{district:district},
        success:function(data)
        {
         $('#rmc').html(data);
        }
       });
      }
      {
        $('#rm').html('<option value="">Select RM</option>');
      }
    });

  function delFunction(x,o){
    var urltext = '<?php echo base_url();?>User/delUser?id='+x;
    var p=o.parentNode.parentNode;
    var c=confirm('Are you sure');
    if(c==true){
      $.ajax({
        url: urltext,
        type: 'POST',
        error: function(){
          alert('Error!! user delete failed');
        },
        success: function(data){
          alert("Record deleted successfull");            
          p.parentNode.removeChild(p);
        }
      });
    }        
  }

  function getById(id){
    var urltext = '<?php echo base_url();?>User/getSingleUser?id='+id;
    $.ajax({
      url: urltext,
      type: 'POST',
      dataType: 'json',
      success: function(response){
        var len = response.length; 
        if (len>0) {
          var rm='<option>'+response[0].RM+'</option>';
          var fnane= response[0].FullName;
          $('#usertype').val(response[0].UserType);
          $('#district').val(response[0].District);
          $('#rmc').html(rm);
          $('#name').val(response[0].FullName);
          $('#email').val(response[0].Username);
          $('#password').val(response[0].Password);
          $('#password2').val(response[0].Password);
          $('#submit').html('Update');
          //alert($('#rmc').val());
          $('#mdlAddUser').modal('show');
        }
        else{
          alert('Data not found');
        }         
      }
    });
  }

  function loadUserTable(){
      $.ajax({
        url:"<?php echo base_url();?>User/userdata",
        method:"POST",
        success: function(data){
          $('#usertable > tbody').html(data);
        }
      });
    }
</script>