<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>HMIS: Login </title>
    <!-- Bootstrap -->
    <link href="<?php echo base_url(); ?>assets/vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="<?php echo base_url(); ?>assets/vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="<?php echo base_url(); ?>assets/vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- Animate.css -->
    <link href="<?php echo base_url(); ?>assets/vendors/animate.css/animate.min.css" rel="stylesheet">
    <!-- Custom Theme Style -->
    <link href="<?php echo base_url(); ?>assets/build/css/custom.min.css" rel="stylesheet">
    <script src="<?php echo base_url(); ?>assets/vendors/jquery/dist/jquery.min.js"></script>
  </head>
  <body class="login">
    <div>
      <div class="login_wrapper">
        <div class="animate form login_form">
          <section class="login_content">
            <form>
              <h1>HMIS Login</h1>
              <div>
                <input type="email" id="Username" class="form-control" placeholder="Username" required="" />
              </div>
              <div>
                <input type="password" id="Password" class="form-control" placeholder="Password" required="" />
              </div>
              <div>
                <a class="btn btn-lg btn-default submit" id="login" href="#">Log in</a>
              </div>
              <div class="clearfix"></div>
              <div class="separator"></div>
            </form>
          </section>
        </div>
      </div>
    </div>
    <script type="text/javascript">
      $('#login').on('click', function(){
        login();
      });

      // Listen for the enter key press.
      document.body.addEventListener( 'keyup', function (e) {
        if ( e.keyCode === 13 ) {
          e.preventDefault();
          $('#login').click();
        }
      });

      function login(){
        var user=$('#Username').val();
        var pass=$('#Password').val();
        $.ajax({
          url:'<?php echo base_url();?>Login/checkLogin',
          method:'POST',
          data:{username:user, password: pass},
          success: function(data){
            if (data=='success') {
              window.location = '<?php echo base_url();?>Home';
            }else{
              alert('Invalid username and/or password');
            }            
          }
        });
      }
    </script>
  </body>
</html>
